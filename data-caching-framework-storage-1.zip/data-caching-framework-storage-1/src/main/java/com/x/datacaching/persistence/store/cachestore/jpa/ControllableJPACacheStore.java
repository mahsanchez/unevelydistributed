package com.bbva.datacaching.persistence.store.cachestore.jpa;

import java.util.Collection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.persistence.store.cachestore.AbstractControllableCacheStore;
import com.tangosol.coherence.jpa.JpaCacheStore;

/**
 * Controllable {@link JpaCacheStore} implementation.
 * 
 * @author amp
 *
 */
// TODO - Check thread-safety for the underlying jpa store class
public class ControllableJPACacheStore extends AbstractControllableCacheStore {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ControllableJPACacheStore.class);

	private final JpaCacheStore jpaCacheStore; // Delegating instance
	
	public ControllableJPACacheStore(String sEntityName, String sEntityClassName, String sUnitName) {
		this.jpaCacheStore = new JpaCacheStore(sEntityName, sEntityClassName, sUnitName);
		LOGGER.info("Created instance of {}", this.getClass().getSimpleName());
	}
	
	public ControllableJPACacheStore(String sEntityName, String sEntityClassName, String sUnitName,
			ClassLoader loader) {
		this.jpaCacheStore = new JpaCacheStore(sEntityName, sEntityClassName, sUnitName, loader);
		LOGGER.info("Created instance of {}", this.getClass().getSimpleName());
	}
	
	// ###### ControllableCacheStore implementations ######
	
	@Override
	public void delete(Object key) {
		this.jpaCacheStore.erase(key);
	}

	@Override
	@SuppressWarnings("rawtypes")
	public void deleteAll(Collection keys) {
		this.jpaCacheStore.eraseAll(keys);
	}

	@Override
	public void persist(Object key, Object value) {
		this.jpaCacheStore.store(key, value);
	}

	@Override
	public void persistAll(Map<?, ?> entries) {
		this.jpaCacheStore.storeAll(entries);
	}
	
	// ###### CacheLoader implementations ######

	@Override
	public Object load(Object key) {
		return this.jpaCacheStore.load(key);
	}
	
	@Override
	@SuppressWarnings("rawtypes")
	public Map loadAll(Collection keys) {
		return this.jpaCacheStore.loadAll(keys);
	}
}