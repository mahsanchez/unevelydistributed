package com.bbva.datacaching.persistence.store.cachestore;

import java.util.Collection;
import java.util.Map;

import com.bbva.datacaching.persistence.store.management.ControllableStoreMBean;

public interface ControllableCacheStore extends ControllableStoreMBean {
	
	/**
	 * 
	 * @param key
	 */
	void delete(Object key);
	
	/**
	 * 
	 * @param keys
	 */
	@SuppressWarnings("rawtypes")
	void deleteAll(Collection keys);
	
	/**
	 * 
	 * @param key
	 * @param value
	 */
	void persist(Object key, Object value);
	
	/**
	 * 
	 * @param entries
	 */
	void persistAll(Map<?, ?> entries);
	
//	/**
//	 * 
//	 * @param key
//	 */
//	void retrieve(Object key);
//	
//	/**
//	 * 
//	 * @param keys
//	 */
//	@SuppressWarnings("rawtypes")
//	void retrieveAll(Collection keys);
}