package com.bbva.datacaching.persistence;

import java.sql.Connection;
import java.sql.ResultSet;

import com.bbva.datacaching.loader.NodeLoadTask;

/**
 * 
 * One instance of an implementation for each cache is needed, the ORM logic is likely not the same.
 * @author amp
 *
 */
public interface BusinessObjectDAO {
	
	/**
	 * In all persistence options, getting a reference to the connection is necessary in order to run the query to find
	 * the ranges.
	 * @return
	 */
	Connection getConnection(); // Needed to execute limits query, makes sense to use the same pool that 
	// accesses the same DB table
	
	void closeConnection(Connection conn);
	
	String selectObjectsRangeQuery();
	
	Object loadKeyFromResultSet(ResultSet resultSet);
	
	Object loadBusinessObjectFromResultSet(ResultSet resultSet);
	
	Class<?> getKeyClass();
}