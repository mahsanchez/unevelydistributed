package com.bbva.datacaching.policy.processor;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.policy.StrategyDelegatorActionPolicy;
import com.bbva.datacaching.policy.StrategyDelegatorActionPolicy.PolicyType;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.InvocableMap.EntryProcessor;

/**
 * The replicated cache must run in all nodes that need ActionPolicy strategy management, it is the synch
 * mechanism. Due to the delays of performing updates on a replicated cache (running this processor),
 * there's a window between it has been set for update and it's finished updating (it keeps the old
 * ActionPolicy standing until it performs the update). 
 * 
 * Only the method for the single key has been implemented since this will be called individually
 * for single keys. 
 * 
 * Meant to be run only in Replicated Caches, will not serialize, ActionPolicy was not thought to
 * serialize.
 * 
 * Switching the ActionPolicy strategy in the replicated cache in one node will have the effect of doing
 * it in all nodes (the replicated cache synchronizes in all nodes where it is configured).  
 * @author amp
 */
public class EstablishPolicyProcessor implements EntryProcessor {
	
	/**
	 * This processor will run on a replicated cache and as such will not serialize
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = LoggerFactory.getLogger(EstablishPolicyProcessor.class);
	
	private PolicyType type;
	
	public EstablishPolicyProcessor(final PolicyType type) {
		this.type = type;
	}
	
	/**
	 * This method and the respective logger will run on the client, since this will run on a
	 * replicated cache.
	 */
	@Override
	public Object process(final Entry entry) {
		// Entry key in the replicated cache should be a string
		final StrategyDelegatorActionPolicy policy = (StrategyDelegatorActionPolicy) entry.getValue();
		/* Instance of StrategyDelegatorActionPolicy should have been placed in the replicated cache
		 * upon loading from configuration
		 */
		if (policy == null) {
			LOGGER.error("{} instance should not be null in the replicated cache for key {}",
					StrategyDelegatorActionPolicy.class.getSimpleName(), entry.getKey());
			throw new IllegalStateException(StrategyDelegatorActionPolicy.class.getSimpleName()
					+ " instance should not be null in the replicated cache for key ["
					+ entry.getKey() + "]");
		}
		if (this.type == PolicyType.LOADING) {
			policy.establishLoadingPolicy();
		} else {
			policy.establishRegularPolicy();
		}
		entry.setValue(policy); // Unnecessary, in a replicated cache it is the same reference
		return null;
	}

	/**
	 * Not called, the processor is called only for single entries.
	 */
	@Override
	public Map processAll(final Set set) {
		// TODO Auto-generated method stub
		return null;
	}

	// ###### No need to ipmplement PortableObject, but just in case
}