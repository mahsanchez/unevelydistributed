package com.bbva.datacaching.persistence;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.NodeLoadLimits;
import com.bbva.datacaching.loader.connection.IConnectionPool;
import com.bbva.datacaching.loader.connection.JMXConnectionPool;
import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.tangosol.net.NamedCache;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.processor.ConditionalPutAll;

/**
 * There is a synchronized block - not a problem since the {@link #load(String, int, NodeLoadLimits)}
 * method will in most cases only run once in a JVM. Only in case of failure or node departure may a
 * node run the {@link #load(String, int, NodeLoadLimits)} more than once, and even in such scenarios
 * it would be a small number of times.
 * 
 * @author amp
 *
 * @param <K>
 * @param <V>
 */
public abstract class AbstractJPALoadable<K, V> extends AbstractCacheParallelLoadable<K, V> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractJPALoadable.class);
	
	private final IConnectionPool connectionPool = JMXConnectionPool.getInstance(); // Singleton, one per JVM classloader
	
	// ###### Methods to be implemented in subclasses ######
	
	/**
	 * Implementations should extract the key K from the JPA entity V and return it. Note that the
	 * JPA entity stored in the database must have means to get the key it will be associated with
	 * in the cache.
	 * 
	 * NOTE: do not mutate the entity - it is only passed as a parameter for the purpose of getting the
	 * entity's key from it.
	 *  
	 * @param databaseEntity	the entity of type V loaded from the database
	 * @return					the key of type K extracted from the given Entity
	 */
	public abstract K loadKeyFromEntity(V entity);
	
	// ###### Supertype implementations ######
	
	/**
	 * 
	 */
	@Override
	public final void saveAll(final NamedCache cache, Map<K, V> batchMap) {
		// Stores only elements that are not already cached
		cache.invokeAll(batchMap.keySet(), new ConditionalPutAll(AlwaysFilter.INSTANCE, batchMap));
	}
	
	@Override
	public Connection getConnection() {
		Connection connection = null;
		try {
			connection = this.connectionPool.getConnection();
		} catch (SQLException e) {
			LOGGER.error("{} thrown when getting connection from pool", SQLException.class.getSimpleName(), e);
			// Throw exception here? An exception would have been thrown if not caught anyway
			throw new LoadingProcessException("Exception thrown when getting connection from pool");
		}
		return connection;
	}

	@Override
	public void closeConnection(Connection connection) {
		try {
			connection.close();
		} catch (SQLException e) {
			LOGGER.error("{} thrown when closing connection", SQLException.class.getSimpleName(), e);
			// Throw exception here? An exception would have been thrown if not caught anyway
			throw new LoadingProcessException("Exception thrown when closing connection", e);
		}
	}
}