package com.bbva.datacaching.persistence;

import java.util.Map;

import com.tangosol.net.NamedCache;

/**
 * Adds method to the hierarchy to perform batch storage of entities to the cache.
 * 
 * @author amp
 *
 */
public abstract class AbstractCacheParallelLoadable<K, V> implements ParallelLoadable<K, V> {

	/**
	 * Saves entities in a batch map to cache.
	 * @param cache
	 * @param batchMap		batch of entities to be inserted in the cache.
	 */
	public abstract void saveAll(final NamedCache cache, Map<K, V> batchMap);
}