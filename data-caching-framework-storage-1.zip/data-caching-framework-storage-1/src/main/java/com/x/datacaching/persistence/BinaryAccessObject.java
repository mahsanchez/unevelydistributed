package com.bbva.datacaching.persistence;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.connection.IConnectionPool;
import com.bbva.datacaching.loader.connection.JMXConnectionPool;
import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.tangosol.util.Binary;

/**
 * {@link ParallelLoadable} implementation for loading all objects from the back-end store using
 * the String-BLOB data model.
 * 
 * NOTE: This model requires that a cache's table be configured with exactly two columns - the ID
 * and the BLOB column - no more, no less.
 * 
 * @author amp
 *
 */
public class BinaryAccessObject extends AbstractJDBCBinaryLoadable<String, Binary> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BinaryAccessObject.class);
	
	private static final int KEY_COLUMN_IDX = 1;
	private static final int VALUE_COLUMN_IDX = 2;
	
	private final IConnectionPool connectionPool;
	private final String selectObjectsQuery;
	
	public BinaryAccessObject(final String tableName, final String keyColumnName) {
		LOGGER.info("Called constructor on {} for table name [{}] and key column name [{}]",
				new Object[]{this.getClass().getSimpleName(), tableName, keyColumnName});
		
		this.selectObjectsQuery = "SELECT * FROM " + tableName + " WHERE " + keyColumnName + " BETWEEN ? AND ?";
		this.connectionPool = JMXConnectionPool.getInstance(); // Singleton, one per JVM classloader
	}
	
	@Override
	public Connection getConnection() {
		Connection connection = null;
		try {
			connection = this.connectionPool.getConnection();
		} catch (SQLException e) {
			LOGGER.error("{} thrown when getting connection from pool", SQLException.class.getSimpleName());
			LOGGER.error("Exception: ", e);
			// TODO - more handling?
		}
		return connection;
	}

	@Override
	public void closeConnection(Connection connection) {
		try {
			connection.close();
		} catch (SQLException e) {
			LOGGER.error("{} thrown when closing connection", SQLException.class.getSimpleName());
			LOGGER.error("Exception: ", e);
			// TODO - more handling?
			throw new LoadingProcessException("Exception thrown when closing connection", e);
		}
	}

	@Override
	public String selectObjectsInRangeQuery() {
		return this.selectObjectsQuery;
	}

	@Override
	public Class<String> getKeyClass() {
		return String.class;
	}

	@Override
	public String loadKeyFromResultSet(ResultSet resultSet) {
		String key = null;
		try {
			key = resultSet.getString(KEY_COLUMN_IDX);
		}
		catch (SQLException e) {
			LOGGER.error("Exception getting key from result set: ", e);
			// TODO - more handling?
		}
		return key;
	}

	@Override
	public Binary loadEntityFromResultSet(ResultSet resultSet) {
		Binary value = null;
		try {
			final Blob blob = resultSet.getBlob(VALUE_COLUMN_IDX);
			value = new Binary(blob.getBytes(1, (int) blob.length()));
		}
		catch (SQLException e) {
			LOGGER.error("Exception getting binary object from result set: ", e);
			// TODO - more handling?
		}
		return value;
	}
}