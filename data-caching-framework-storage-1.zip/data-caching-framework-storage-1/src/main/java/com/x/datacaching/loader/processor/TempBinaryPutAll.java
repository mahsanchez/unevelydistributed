package com.bbva.datacaching.loader.processor;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.tangosol.io.Serializer;
import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.ExternalizableHelper;
import com.tangosol.util.InvocableMap;
import com.tangosol.util.NullImplementation;
import com.tangosol.util.processor.AbstractProcessor;

/**
 * Likely does not need to serialize because it runs on the same node, does not travel through the
 * network, and is not even registered.
 * @author amp
 *
 * @param <K>
 */
// TODO - Class will be deleted, it is in DCF.
public class TempBinaryPutAll<K> extends AbstractProcessor implements PortableObject, Serializable {
	
	/** Defaults serial id. */
	private static final long serialVersionUID = 1L;
	
	protected Map<K, Binary> map;

	public TempBinaryPutAll() {}

	public TempBinaryPutAll(final Map<K, Binary> map) {
		this.map = map;
	}

	// ###### EntryProcessor implementations ######
	
	@Override
	public Object process(final InvocableMap.Entry entry) {
		// Checks if the map contains the key not to have null values
		if (this.map.containsKey(entry.getKey())) {
			// Value is in binary format
			((BinaryEntry) entry).updateBinaryValue(this.map.get(entry.getKey())); 
		}
		return null;
	}

	@Override
	@SuppressWarnings({"unchecked", "rawtypes"})
	public Map processAll(final Set setEntries) {
		for (final InvocableMap.Entry entry : (Set<InvocableMap.Entry>) setEntries) {
			// Checks if the map contains the key not to have null values
			if (this.map.containsKey(entry.getKey())) {
				// Value is in binary format
				((BinaryEntry) entry).updateBinaryValue(this.map.get(entry.getKey())); 
			}
		}
		return NullImplementation.getMap();
	}

	// ###### PortableObject implementations ######
	
	/* Won't be called, as the processor will be running in-node */
	@Override
	@SuppressWarnings("unchecked")
	public void readExternal(final PofReader reader) throws IOException {
		// Direct map deserialization
		this.map = new HashMap<K, Binary>();
		// Reads size of map
		final int mapSize = reader.readInt(0);
		int id = 1;
		for (int i = 0; i < mapSize; i++) {
			final K key = (K) reader.readObject(id++);
			final Binary value = reader.readBinary(id++);
			this.map.put(key, value);
		}
	}
	
	/* Won't be called, as the processor will be running in-node */
	@Override
	public void writeExternal(final PofWriter writer) throws IOException {
		// Writes size of map
		writer.writeInt(0, this.map.size());
		// Serializes values
//		final Serializer serializer = writer.getPofContext();
		int id = 1;
		for (final Map.Entry<K, ?> entry : this.map.entrySet()) {
			writer.writeObject(id++, entry.getKey());
			writer.writeBinary(id++, (Binary) entry.getValue()); // Value is already in binary form
		}
	}

	// ###### Object methods ######

	@Override
	@SuppressWarnings("rawtypes")
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TempBinaryPutAll other = (TempBinaryPutAll) obj;
		if (map == null) {
			if (other.map != null)
				return false;
		} else if (!map.equals(other.map))
			return false;
		return true;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((map == null) ? 0 : map.hashCode());
		return result;
	}
	
	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [Map=" + map + "]";
	}
}
