package com.bbva.datacaching.loader.exception;

/**
 * {@link RuntimeException} wrapper used to indicate problems with the loading
 * process.
 * 
 * @author amp
 */
public class LoadingProcessException extends RuntimeException {
	
	/** Default serial id. */
	private static final long serialVersionUID = 1L;
	
	public LoadingProcessException() {
		super();
	}
	
	public LoadingProcessException(final String message) {
		super(message);
	}
	
	public LoadingProcessException(final Throwable cause) {
		super(cause);
	}
	
	public LoadingProcessException(final String message, final Throwable cause) {
		super(message, cause);
	}
}