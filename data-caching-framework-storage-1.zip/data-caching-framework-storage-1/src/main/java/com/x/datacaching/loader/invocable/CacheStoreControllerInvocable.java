package com.bbva.datacaching.loader.invocable;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.loader.invocable.observer.DistributedExecutionObserver;
import com.bbva.datacaching.loader.util.Utilities;
import com.bbva.datacaching.persistence.store.management.ControllableStoreMBean;
import com.tangosol.net.AbstractInvocable;
import com.tangosol.net.BackingMapContext;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;
import com.tangosol.net.cache.ReadWriteBackingMap;

/**
 * {@link Invocable} sent for execution in nodes carrying the service.
 * 
 * Can be executed from a script.
 * @author amp
 */
public class CacheStoreControllerInvocable extends AbstractInvocable {
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(CacheStoreControllerInvocable.class);
	
	private static final String STATE_ENABLE = "enable";
	private static final String STATE_DISABLE = "disable";
	
	private static final Long EXECUTION_TIMEOUT = 10L; // 10s for executing script
	
	private static final long RETRY_WAIT_TIME = 500; //ms
	private static final int NUMBER_RETRIES = 5;
	
	private final String cacheName;
	private final boolean enableCacheStore;
	
	public CacheStoreControllerInvocable(final String cacheName, final boolean enableCacheStore) {
		this.cacheName = cacheName;
		this.enableCacheStore = enableCacheStore;
	}

	@Override
	// TODO - there might be some null in this chain of calls?
	// Maybe a cache store is not configured, even though it doesn't make much sense
	// TODO - we need some logging here, it is an invocable with no guarantees
	public void run() {
		final String state = this.enableCacheStore ? "enabled" : "disabled";
		// Inside a try-catch because something may fail, and in case it does, the problem is logged
		try {
			ControllableStoreMBean controllableCacheStore = null;
			int count = 1;
			while (count <= NUMBER_RETRIES && controllableCacheStore == null) {
				try {
					final BackingMapContext context = CacheFactory.getCache(this.cacheName).getCacheService()
							.getBackingMapManager().getContext().getBackingMapContext(this.cacheName);
					final ReadWriteBackingMap backingMap = (ReadWriteBackingMap) context.getBackingMap();
					controllableCacheStore = (ControllableStoreMBean) backingMap.getCacheStore().getStore();
				} catch (NullPointerException e) {
					// Ignores the null pointer as this situation is contemplated, unless it is the last retry
					if (count == NUMBER_RETRIES) {
						throw new LoadingProcessException(e);
					}
				}
				// If CacheStore has been set, breaks out of the loop;
				if (controllableCacheStore != null) {
					break;
				}
				// Sleeps for the retry time before checking again if backing map has already been created. 
				Thread.sleep(RETRY_WAIT_TIME);
				count++;
			}
//			
//			final BackingMapContext context = CacheFactory.getCache(this.cacheName).getCacheService()
//					.getBackingMapManager().getContext().getBackingMapContext(this.cacheName);
//			final ReadWriteBackingMap backingMap = (ReadWriteBackingMap) context.getBackingMap();
//			controllableCacheStore = (ControllableStoreMBean) backingMap.getCacheStore().getStore();
			
			/* Enables/disables the AbstractControllableCacheStore for the node on which this instance
			 * is running */
			controllableCacheStore.setEnabled(this.enableCacheStore);
			LOGGER.info("The controllable cache store for cache [{}] has been {} in this node", this.cacheName, state);
		} catch (Exception e) {
			LOGGER.error("{} thrown when trying to get a reference to the CacheStore configured for this node",
					e.getClass().getSimpleName(), e);
			LOGGER.error("Verify if there's an instance of {} configured as a CacheStore for cache [{}] on this node",
					ControllableStoreMBean.class.getSimpleName(), this.cacheName);
			throw new LoadingProcessException("Exception thrown when trying to get a reference to the CacheStore "
					+ "configured for this node");
		} 
	}
	
	/**
	 * Enables this {@link Invocable} to be run from a script.
	 * 
	 * @param args
	 */
	public static void main(String args[]) {
		if (args == null || args.length != 3) {
			LOGGER.error("Usage: {}  <INVOCATION_SERVICE_NAME> <CACHE_NAME> <enable | disable>",
					CacheStoreControllerInvocable.class.getName());
			System.exit(1); // Exits script with error code
		}
		
		for (final String arg : args) {
			if (arg == null || "".equals(arg)) {
				LOGGER.error("Script parameters cannot be null or empty");
				System.exit(1); // Exits script with error code
			}
		}
		
		LOGGER.info("Running {}", CacheStoreControllerInvocable.class.getSimpleName());
		
		final String invocationServiceName = args[0];
		final String cacheName = args[1];
		final String state = args[2];
		
		if (!(STATE_ENABLE.equalsIgnoreCase(state) || STATE_DISABLE.equalsIgnoreCase(state))) {
			LOGGER.error("Third parameter must be one of <enable | disable>");
			System.exit(1); // Exits script with error code
		}
		
		final boolean action = STATE_ENABLE.equalsIgnoreCase(state) ? true : false;
		
		try {
			final Set<Member> serviceStorageMembers = Utilities.getCurrentStorageMemberSetForService(cacheName);
			final InvocationService invocationService = 
					(InvocationService) CacheFactory.getService(invocationServiceName);
			final DistributedExecutionObserver observer = new DistributedExecutionObserver(
					serviceStorageMembers.size(), CacheStoreControllerInvocable.class.getSimpleName());
			invocationService.execute(new CacheStoreControllerInvocable(cacheName, action), serviceStorageMembers,
					observer);
			LOGGER.info("Sent an Invocable for execution in all nodes carrying the service of cache [{}] to {} the "
					+ "{} for this cache", new Object[]{cacheName, state, ControllableStoreMBean.class.getSimpleName()});
			LOGGER.info("Max wait time: {}s ......", EXECUTION_TIMEOUT);
			
			final boolean result = observer.await(EXECUTION_TIMEOUT, TimeUnit.SECONDS);
			// If result is false, there's been a timeout
			if (!result) {
				LOGGER.error("Timeout reached before executing the code in all nodes");
				System.exit(1); // Exits script with error code
			}
		} catch (Exception e) {
			LOGGER.error("Exception thrown when running distributed code", e);
			System.exit(1); // Exits script with error code
		} finally {
			// Shuts down cache factory from this client node
			CacheFactory.shutdown();
		}
		
		// At this point, code has executed correctly in all nodes
		LOGGER.info("Successfully executed the code to {} the ControllableStore in all nodes carrying the "
				+ "service of cache [{}]", state, cacheName);
		System.exit(0); // Signals successful execution
	}
}