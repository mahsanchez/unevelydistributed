package com.bbva.datacaching.persistence.store.cachestore;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.connection.IConnectionPool;
import com.bbva.datacaching.loader.connection.JMXConnectionPool;
import com.oracle.coherence.patterns.eventdistribution.events.DistributableEntry;
import com.oracle.coherence.patterns.eventdistribution.events.DistributableEntryEvent;
import com.oracle.coherence.patterns.messaging.Message;
import com.tangosol.net.BackingMapManagerContext;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.cache.CacheStore;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;


/**
 * This class will only be configured as a {@link CacheStore} in push replication intermediary caches.
 * @author amp
 *
 */
public class PushBinaryStore extends AbstractControllableBinaryEntryStore {
	
	private static final String UNSUPPORTED_OPERATION_MESSAGE = "unsupported operation for "
			+ PushBinaryStore.class.getSimpleName();
	
	private AtomicInteger count = new AtomicInteger(0);
	private final AtomicBoolean hasBeenInitialized = new AtomicBoolean(false);
	
	private BackingMapManagerContext context;

	// Strings
	public static final String WHERE 			= " WHERE ";
	public static final String AND 				= " AND ";
	
	// Statements fijos:
	private final String statement_Load; 
	private final String statement_delete;
	private final String  statement_insert_oracle;
	private final String  statement_insert_mySQL;
	
	
	/** Configuration file name */
	private static final String CONFIG_FILE = "connection-pool-params.xml";
	
	
	/** Logger */
	private static final Logger LOGGER = LoggerFactory.getLogger(PushBinaryStore.class);
	
	
	/** Nombre de la tabla donde se almacenan los datos de esta cache */
	private String cacheName;
	private String tableName;
	private String idColumnName;
	private String binaryColumnName;
	private int jdbcBatchSize;
	
	/** */
	private final IConnectionPool connectionPool;
	
	/** */
//	private final boolean  isOracle;
	private boolean  isOracle;
	
	
	// ---------------------------------------
	
	/**
	 * Constructor.
	 * @param table_name
	 * @throws Exception 
	 */
	public PushBinaryStore(String cacheName, String table_name, String idColumnName, String binaryColumnName,
			int jdbcBatchSize) throws Exception {
		
		LOGGER.info("Starting {}", new Object[]{PushBinaryStore.class.getSimpleName()});
		
		this.cacheName = validateStringParameter(cacheName, BinaryStoreConfigParams.CACHE_NAME.getParamName());
		this.tableName = validateStringParameter(table_name, BinaryStoreConfigParams.TABLE_NAME.getParamName());
		this.idColumnName = validateStringParameter(idColumnName, BinaryStoreConfigParams.ID_COLUMN_NAME.getParamName());
		this.binaryColumnName = validateStringParameter(binaryColumnName, BinaryStoreConfigParams.BINARY_COLUMN_NAME.getParamName());
		this.jdbcBatchSize = validateIntParameter(jdbcBatchSize, BinaryStoreConfigParams.JDBC_BATCH_SIZE.getParamName());
		
//		String configFile = this.getConfigurationFile();
//		LOGGER.info("Reading configuration from file {} ", configFile);
//		
//		config = ConfigReader.readConfiguration(configFile);
//		
//		if (config == null  || (!config.validate()))
//		{
//			LOGGER.error("Error creating DataCachingStore. Errors found in Configuration file {}", configFile);
//			throw new Exception("Error creating DataCachingStore. Errors found in Configuration file");
//		}
//				
//		LOGGER.info("Configuration:\n" + config.toString());
//		
//		if (config.getDriver().contains("oracle")) {
//			isOracle = true;
//		}
//		else if (config.getDriver().contains("mysql")) {
//			isOracle = false;
//		}
//		else {
//			throw new Exception("Configured driver is not compatible!");
//		}
		
		LOGGER.debug("Creating Connection Pool...");
//		this.connectionPool = DataCachingConnectionPool.getInstance();
		this.connectionPool = JMXConnectionPool.getInstance();
		
		
		// Creamos los statements una sola vez para evitar la creación de Strings cada vez que vaya a ejecutarse un statement en base de datos.
		statement_Load = "SELECT * FROM "+ tableName + WHERE + this.idColumnName + " = ?" ;
		
		statement_delete = "DELETE from " + tableName + WHERE + this.idColumnName +  "= ? ";
		
		
//		statement_insert_oracle = "MERGE INTO " + tableName + " a " +
//                "USING (SELECT ? CACHE_KEY, ? BINARY_CONTENT from dual) incoming " +
//                "ON (a.CACHE_KEY = incoming.CACHE_KEY ) " +
//                "WHEN MATCHED THEN " +
//                "UPDATE SET a.BINARY_CONTENT = incoming.BINARY_CONTENT " +
//                "WHEN NOT MATCHED THEN " +
//                "INSERT (a.CACHE_KEY,  a.BINARY_CONTENT) " +
//                "VALUES (incoming.CACHE_KEY, incoming.BINARY_CONTENT)";
		
		statement_insert_oracle = "MERGE INTO " + tableName + " a " +
				"USING (SELECT ? " + this.idColumnName + " , ? " + this.binaryColumnName + " from dual) incoming " +
				"ON (a." + this.idColumnName + " = incoming." + this.idColumnName + ") " +
				"WHEN MATCHED THEN " +
				"UPDATE SET a." + this.binaryColumnName + " = incoming." + this.binaryColumnName + " " +
				"WHEN NOT MATCHED THEN " +
				"INSERT (a." + this.idColumnName + ",  a." + this.binaryColumnName + ") " +
				"VALUES (incoming." + this.idColumnName + ", incoming." + this.binaryColumnName + ")";
		
		statement_insert_mySQL =  "INSERT INTO " + tableName  
                + "(CACHE_KEY, BINARY_CONTENT) values (?, ? ) " 
                + "ON DUPLICATE KEY UPDATE BINARY_CONTENT = ? ";
		
//		try {
//			this.context = CacheFactory.getCache(CACHE_NAME).getCacheService().getBackingMapManager().getContext();
//		} catch (Exception e) {
//			e.printStackTrace(System.out);
//		}
//		if (this.context == null) {
//			System.out.println("#### Context is NULL");
//			throw new IllegalStateException("backingMapManagerContext cannot be null");
//		}
		
		// Cannot initialize BackingMapManagerContext in constructor, it dead locks
	}
	
//	public PushBinaryStore(String cacheName, String tableName, String idColumnName, String binaryColumnName,
//			int jdbcBatchSize) throws Exception {
//		this(tableName);
//		this.cacheName = cacheName;
//		this.idColumnName = idColumnName;
//		this.binaryColumnName = binaryColumnName;
//		this.jdbcBatchSize = jdbcBatchSize;
//	}
	
	 /**
     * 
     * @return
     * @throws Exception
     */
    private String getConfigurationFile() throws Exception
    {
		URL confURL = Thread.currentThread().getContextClassLoader().getResource(CONFIG_FILE);
		if (confURL == null) {
		    confURL = ClassLoader.getSystemResource(CONFIG_FILE);
		} 
		if (confURL == null)
		{
			LOGGER.error("Error creating CachingStore. Configuration file {} is missing.", CONFIG_FILE);
			throw new Exception("Error creating CachingStore. Configuration file "+ CONFIG_FILE+"  is missing.");
		}
		return confURL.getFile();
    }
	
	// ----------------------------------------------------------------------------
	
	/**
	 * 
	 * @param binaryEntry
	 */
    @Override
	public void delete(BinaryEntry binaryEntry) 
	{
		LOGGER.info("Called erase() with single binary entry");
		LOGGER.trace("erase...");
//		delete(binaryEntry.getKey());
		
		/*
		 * No problem in calling the multiple method with a single entry, this single method should not
		 * nevertheless be called by the write behind thread. 
		 */
		deleteAll(Collections.singleton(binaryEntry));
	}

	/**
	 * Remove the specified entries from the underlying store.
	 * 
	 * @param setBinEntries the set entries to be removed from the store
	 * 
	 */
	@Override
	public void deleteAll(Set setBinEntries) {
		initializeContext();
		LOGGER.info("Called eraseAll() with set size: " + setBinEntries.size());
		LOGGER.debug("eraseAll. With {} entries", setBinEntries.size());
		
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = connectionPool.getConnection();
			ps = connection.prepareStatement(this.statement_delete);
			// Disable auto commit
			connection.setAutoCommit(false);
			
			if (setBinEntries.size() <= this.jdbcBatchSize) {
				deleteBatch(setBinEntries, connection, ps);
			} else {
				Set batch = new HashSet(this.jdbcBatchSize);
				
				while (!setBinEntries.isEmpty()) {
					Iterator iterator = setBinEntries.iterator();
					while (iterator.hasNext() && batch.size() < this.jdbcBatchSize) {
						batch.add(iterator.next());
					}
					// Stores objects in batch
					deleteBatch(setBinEntries, connection, ps);
					
					// Clears batch
					setBinEntries.removeAll(batch);
					batch.clear();
				}
			}
			
			// Commits transaction
			connection.commit();
		} catch (SQLException e) {
			LOGGER.error("SQLException thrown when deleting entries in batch", e);
			// TODO - throw exception if some entry fails?
		} finally {
			cleanUpResources(ps, connection);
		}
	}
	
	/**
	 * 
	 * @param binaryKey
	 */
	@Override
	public void retrieve(BinaryEntry binaryEntry) {
		LOGGER.error("Called load(): {}", UNSUPPORTED_OPERATION_MESSAGE);
		throw new UnsupportedOperationException("Called load(): " + UNSUPPORTED_OPERATION_MESSAGE);
	}

	
	/**
	 * 
	 * @param setBinEntries
	 */
	@Override
	public void retrieveAll(Set setBinEntries) {
		LOGGER.error("Called loadAll(): {}", UNSUPPORTED_OPERATION_MESSAGE);
		throw new UnsupportedOperationException("Called loadAll(): " + UNSUPPORTED_OPERATION_MESSAGE);
	}

	
	/**
	 * 
	 * @param binaryEntry
	 */
	@Override
	public void persist(BinaryEntry binaryEntry) 
	{
		LOGGER.info("Called store() with single binary entry");
		LOGGER.trace("store(BinaryEntry binaryEntry)");
		// Get the key:
//		Object id = binaryEntry.getKey();
//				
//		if (! (id instanceof String))
//		{
//			LOGGER.error("key is not a String object");
//			return;
//		}
//		
//		if (true)
//		{
//			this.updsert((String)id, binaryEntry);
//			return;
//		}
		
		/*
		 * No problem in calling the multiple method with a single entry, this single method should not
		 * nevertheless be called by the write behind thread. 
		 */
		persistAll(Collections.singleton(binaryEntry));
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.tangosol.net.cache.BinaryEntryStore#storeAll(java.util.Set)
	 */
//	public void storeAll(Set setBinEntries) 
//	{
//		CacheFactory.log("#### called storeAll() with set size: " + setBinEntries.size());
//		System.out.println("#### called storeAll() with set size: " + setBinEntries.size());
//		LOG.debug("storeAll. With {} entries", setBinEntries.size());
//		if (!setBinEntries.isEmpty()) 
//		{		
//			for (Object entry : setBinEntries)
//			{
//				if (entry instanceof BinaryEntry)
//				{
//					BinaryEntry binEntry = (BinaryEntry) entry;
//					
//					if (this.updsert((String) binEntry.getKey(), binEntry))
//						setBinEntries.remove(entry);
//					
//				}
//			}
//		
//		}
//	}
	
	/**
	 * {@link BinaryEntry} implementation will have to implement equals() and hashCode() to be
	 * used correctly in a hash {@link Set}.
	 * At the moment, implemented to work only with the oracle statement.
	 */
	// TODO - at the moment this is only configured for oracle
	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void persistAll(Set setBinEntries) {
		initializeContext();
		LOGGER.info("#### call to storeAll() with set size: " + setBinEntries.size() + ", count: " + count.getAndIncrement());
		
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = connectionPool.getConnection();
			ps = connection.prepareStatement(this.statement_insert_oracle);
			// Disable auto commit
			connection.setAutoCommit(false);
			
			if (setBinEntries.size() <= this.jdbcBatchSize) {
				storeBatch(setBinEntries, connection, ps);
			} else {
				Set batch = new HashSet(this.jdbcBatchSize);
				
				while (!setBinEntries.isEmpty()) {
					Iterator iterator = setBinEntries.iterator();
					while (iterator.hasNext() && batch.size() < this.jdbcBatchSize) {
						batch.add(iterator.next());
					}
					// Stores objects in batch
					storeBatch(setBinEntries, connection, ps);
					
					// Clears batch
					setBinEntries.removeAll(batch);
					batch.clear();
				}
			}
			
			// Commits transaction
			connection.commit();
		} catch (SQLException e) {
			LOGGER.error("SQLException thrown when storing entries in batch", e);
			// TODO - throw exception if some entry fails?
		} finally {
			cleanUpResources(ps, connection);
		}
	}
	
	// ###### Helper methods ######
	
	private void storeBatch(Set setBinEntries, Connection connection, PreparedStatement ps) {
		try {
			for (BinaryEntry entry : (Set<BinaryEntry>) setBinEntries) {
				final Message messageValue = (Message) entry.getValue();
				final DistributableEntry  distributableEntry = ((DistributableEntryEvent ) messageValue.getPayload()).getEntry();

				distributableEntry.setContext(this.context);
				ps.setString(1, (String) distributableEntry.getKey());
				ps.setBlob(2, distributableEntry.getBinaryValue().getInputStream());

				// Adds parameters to batch
				ps.addBatch();
			}
			
			// Executes all statements in batch
			ps.executeBatch();
			
			// Clears statements and parameters in batch, necessary?
			ps.clearBatch();
			ps.clearParameters();
		} catch (Exception e) {
			LOGGER.error("{} thrown when trying to store entries", e.getClass().getSimpleName());
			LOGGER.error("Exception: ", e);
			// TODO - throw exception here in case a batch fails?
		}
		
	}
	
	private void deleteBatch(Set setBinEntries, Connection connection, PreparedStatement ps) {
		try {
			for (BinaryEntry entry : (Set<BinaryEntry>) setBinEntries) {
				final Message messageValue = (Message) entry.getValue();
				final DistributableEntry  distributableEntry = ((DistributableEntryEvent ) messageValue.getPayload()).getEntry();
				distributableEntry.setContext(this.context);
				ps.setString(1, (String) distributableEntry.getKey());

				// Adds parameters to batch
				ps.addBatch();

			}

			// Executes all statements in batch
			ps.executeBatch();

			// Clears statements and parameters in batch, necessary?
			ps.clearBatch();
			ps.clearParameters();
		} catch (Exception e) {
			LOGGER.error("{} thrown when trying to delete entries", e.getClass().getSimpleName());
			LOGGER.error("Exception: ", e);
			// TODO - throw exception here in case a batch fails?
		}
	}
	
	private void cleanUpResources(PreparedStatement ps, Connection connection) {
        if (ps != null) {
            try {
                ps.close();
            } catch (SQLException e) {
            	LOGGER.error("SQLException thrown when closing statement", e);
            	throw new IllegalStateException(e);
            }
        }

        if (connection != null) {
            try {
            	connection.close();
            } catch (SQLException e) {
            	LOGGER.error("SQLException thrown when closing connection", e);
            	throw new IllegalStateException(e);
            }
        }
	}
	
	private void initializeContext() {
		// Code inside will only run once.
		if (this.hasBeenInitialized.compareAndSet(false, true)) {
			try {
				/* This chain may be somewhat problematic (particularly owing to the possibility
				 * of null pointers), so we wrap it in a try-catch
				 */
				this.context = CacheFactory.getCache(this.cacheName).getCacheService().getBackingMapManager().getContext();
			} catch (Exception e) {
				LOGGER.error("Error while accessing the BackingMapManagerContext", e);
				throw new IllegalStateException("Error while accessing the BackingMapManagerContext", e);
			}
			if (!this.hasBeenInitialized.get()) {
				System.out.println("BackingMapManagerContext cannot be null");
				throw new IllegalStateException("BackingMapManagerContext cannot be null");
			}
		}
	}
	
	
	/**
	 * 	
	 * @param id
	 * @param binaryEntry
	 * @return
	 */
	private boolean updsert(String id, BinaryEntry binaryEntry)
	{
		if (isOracle)
			return this.updsertOracle(id, binaryEntry);
		else
			return this.updsertMySQL(id, binaryEntry);
	}
	
	
	/**
	 * Valido en mySQL
	 * 
	 * @param binaryEntry
	 */
	private boolean updsertMySQL(String id, BinaryEntry binaryEntry) 
	{
		LOGGER.trace("updsertMySQL("+id+",..)");
		boolean ret = true;
		PreparedStatement statement = null;
		Connection con = null;
		try
		{
			con = connectionPool.getConnection ();
			statement = con.prepareStatement(statement_insert_mySQL);
		    statement.setString(1, (String) id);
				     
		     Binary binaryValue = binaryEntry.getBinaryValue();
		     statement.setBlob(2, binaryValue.getInputStream());
			    
			 statement.setBlob(3, binaryValue.getInputStream());
		     ret = statement.execute();
	     }
	     catch (SQLException ex)
	     {
	    	 LOGGER.error("SQLException: {}" , ex.getMessage());
	    	 LOGGER.error("SQLException: SQLState= {} , VendorError= {}",ex.getSQLState(), ex.getErrorCode() );
	    	 ret = false;
	     }		
	    finally 
        {
           // it is a good idea to release resources in a finally{} block, in reverse-order of their creation, if they are no-longer needed
           if (statement != null) {
        	   try {
        		   statement.close();
			   } catch (SQLException sqlEx) { } // ignore
        	   statement = null;
		   }
			            
           if (con != null){
			   try{
				   con.close();
			   } catch (SQLException sqlEx) { } // ignore
           	con = null;
           }
		} 
		return ret;
	}
	
	/**
	 * @param binaryEntry
	 */
	public boolean updsertOracle(String id, BinaryEntry binaryEntry) 
	{
		LOGGER.trace("updsertOracle("+id+",..)");
		boolean ret = true;
		PreparedStatement statement = null;
		Connection con = null;
		try
		{
			con = connectionPool.getConnection ();
			statement = con.prepareStatement(this.statement_insert_oracle);
			statement.setString(1, (String) id);
		    Binary binaryValue = binaryEntry.getBinaryValue();
		    statement.setBlob(2, binaryValue.getInputStream());
			     
		    
//		    System.out.println("### SQL statement: \n" + this.statement_insert_oracle + "\n"
//		    		+ "- string: " + id);
			ret =  statement.execute();
	     }
	     catch (SQLException ex)
	     {
	    	 
	    	 ex.printStackTrace(System.out);
	    	 System.out.println("#### Error code: " + ex.getErrorCode());
	    	LOGGER.error("SQLException: {}" , ex.getMessage());
	    	LOGGER.error("SQLException: SQLState= {} , VendorError= {}",ex.getSQLState(), ex.getErrorCode() );
	    	ret = false;
	     }		
	    finally 
	    {
	        // it is a good idea to release resources in a finally{} block, in reverse-order of their creation, if they are no-longer needed
	        if (statement != null) 
	        {
	        	try {
	                	statement.close();
		                } catch (SQLException sqlEx) { } // ignore
	                statement = null;
		     }
		            
		     if (con != null){
		    	 try{
		    		 con.close();
		         } catch (SQLException sqlEx) { } // ignore
		        con = null;
		     }
		} 
		return ret;
	}
	
	/**
	 * 
	 * @param key
	 * @return 
	 * 
	 */
	private boolean delete(Object key ) 
	{
		LOGGER.trace("delete " + key);
		boolean ret = true;
		if (! (key instanceof String))
		{
			LOGGER.error("key is not a String object");
			ret = false;
		}
		else
		{
			PreparedStatement statement = null;
			Connection con = null;
			try
			{
				con = connectionPool.getConnection();
				statement = con.prepareStatement(statement_delete);
			    statement.setString(1, (String) key);
			    statement.execute();
		     }
		     catch (SQLException ex)
		     {
		    	 LOGGER.error("SQLException: {}" , ex.getMessage());
		    	 LOGGER.error("SQLException: SQLState= {} , VendorError= {}",ex.getSQLState(), ex.getErrorCode() );
		    	 ret = false;
		     }		
		    finally 
	        {
	            // it is a good idea to release resources in a finally{} block, in reverse-order of their creation if they are no-longer needed
	            if (statement != null) 
	            {
	                try {
	                	statement.close();
		                } catch (SQLException sqlEx) { } // ignore
	                statement = null;
		        }
		            
		        if (con != null) {
		        	try{
		            	con.close();
		            	} catch (SQLException sqlEx) { } // ignore
		            con = null;
		        } 
	        }
		}
		return ret;
	}
}