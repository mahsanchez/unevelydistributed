package com.bbva.datacaching.persistence.store.cachestore;

import java.net.URL;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.connection.IConnectionPool;
import com.bbva.datacaching.loader.connection.JMXConnectionPool;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;

/**
 * 
 * @author agr
 *
 */
public class CachingBinaryStore extends AbstractControllableBinaryEntryStore {

//	private AtomicInteger count = new AtomicInteger(0);

	// Strings
	public static final String WHERE 			= " WHERE ";
	public static final String AND 				= " AND ";

	// Statements fijos:
	private final String statement_Load; 
	private final String statement_delete;
	private final String  statement_insert_oracle;
	private final String  statement_insert_mySQL;


	/** Configuration file name */
	private static final String CONFIG_FILE = "connection-pool-params.xml";


	/** Logger */
	private static final Logger LOG = LoggerFactory.getLogger(CachingBinaryStore.class);

	/** Nombre de la tabla donde se almacenan los datos de esta cache */
	private String tableName;
	private String idColumnName;
	private String binaryColumnName;
	private int jdbcBatchSize;

	/** */
	private final IConnectionPool connectionPool;

	/** */
//	private final boolean isOracle;
	private boolean isOracle;


	// ---------------------------------------

	/**
	 * Constructor.
	 * @param table_name
	 * @throws Exception 
	 */
	public CachingBinaryStore(String table_name, String idColumnName, String binaryColumnName,
			int jdbcBatchSize) throws Exception {
		LOG.info("Starting CachingBinaryStore");

		this.tableName = validateStringParameter(table_name, BinaryStoreConfigParams.TABLE_NAME.getParamName());
		this.idColumnName = validateStringParameter(idColumnName, BinaryStoreConfigParams.ID_COLUMN_NAME.getParamName());
		this.binaryColumnName = validateStringParameter(binaryColumnName, BinaryStoreConfigParams.BINARY_COLUMN_NAME.getParamName());
		this.jdbcBatchSize = validateIntParameter(jdbcBatchSize, BinaryStoreConfigParams.JDBC_BATCH_SIZE.getParamName());

//		if (table_name == null || table_name.length() <1) {
//			throw new Exception("Wrong name for table. Check configuration files!");
//		}
//		this.tableName = table_name;
//
//		String configFile = this.getConfigurationFile();
//		LOG.info("Reading configuration from file {} ", configFile);
//
//
//		this.config = ConfigReader.readConfiguration(configFile);
//
//		if (this.config == null  || (!this.config.validate()))
//		{
//			LOG.error("Error creating DataCachingStore. Errors found in Configuration file {}", configFile);
//			throw new Exception("Error creating DataCachingStore. Errors found in Configuration file");
//		}
//
//		LOG.info("Configuration:\n" + this.config.toString());
//
//		if (this.config.getDriver().contains("oracle")) {
//			isOracle = true;
//		}
//		else if (this.config.getDriver().contains("mysql")) {
//			isOracle = false;
//		}
//		else {
//			throw new Exception("Configured driver is not compatible!");
//		}

		LOG.debug("Creating Connection Pool...");
		//		this.connectionPool = new ConnectionPool(config);
//		this.connectionPool = DataCachingConnectionPool.getInstance();
		this.connectionPool = JMXConnectionPool.getInstance();


		// Creamos los statements una sola vez para evitar la creación de Strings cada vez que vaya a ejecutarse un statement en base de datos.
		statement_Load = "SELECT * FROM "+ tableName + WHERE + this.idColumnName + " = ?" ;

		statement_delete = "DELETE from " + tableName + WHERE + this.idColumnName +  "= ? ";


		//		statement_insert_oracle = "MERGE INTO " + tableName + " a " +
		//                "USING (SELECT ? CACHE_KEY, ? BINARY_CONTENT from dual) incoming " +
		//                "ON (a.CACHE_KEY = incoming.CACHE_KEY ) " +
		//                "WHEN MATCHED THEN " +
		//                "UPDATE SET a.BINARY_CONTENT = incoming.BINARY_CONTENT " +
		//                "WHEN NOT MATCHED THEN " +
		//                "INSERT (a.CACHE_KEY,  a.BINARY_CONTENT) " +
		//                "VALUES (incoming.CACHE_KEY, incoming.BINARY_CONTENT)";

		statement_insert_oracle = "MERGE INTO " + tableName + " a " +
				"USING (SELECT ? " + this.idColumnName + " , ? " + this.binaryColumnName + " from dual) incoming " +
				"ON (a." + this.idColumnName + " = incoming." + this.idColumnName + ") " +
				"WHEN MATCHED THEN " +
				"UPDATE SET a." + this.binaryColumnName + " = incoming." + this.binaryColumnName + " " +
				"WHEN NOT MATCHED THEN " +
				"INSERT (a." + this.idColumnName + ",  a." + this.binaryColumnName + ") " +
				"VALUES (incoming." + this.idColumnName + ", incoming." + this.binaryColumnName + ")";

		statement_insert_mySQL =  "INSERT INTO " + tableName  
				+ "(CACHE_KEY, BINARY_CONTENT) values (?, ? ) " 
				+ "ON DUPLICATE KEY UPDATE BINARY_CONTENT = ? ";

		//		try {
		//			this.context = CacheFactory.getCache(CACHE_NAME).getCacheService().getBackingMapManager().getContext();
		//		} catch (Exception e) {
		//			e.printStackTrace(System.out);
		//		}
		//		if (this.context == null) {
		//			System.out.println("#### Context is NULL");
		//			throw new IllegalStateException("backingMapManagerContext cannot be null");
		//		}
	}



	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private String getConfigurationFile() throws Exception
	{
		URL confURL = Thread.currentThread().getContextClassLoader().getResource(CONFIG_FILE);
		if (confURL == null) {
			confURL = ClassLoader.getSystemResource(CONFIG_FILE);
		} 
		if (confURL == null)
		{
			LOG.error("Error creating CachingStore. Configuration file {} is missing.", CONFIG_FILE);
			throw new Exception("Error creating CachingStore. Configuration file "+ CONFIG_FILE+"  is missing.");
		}
		return confURL.getFile();
	}



	// ----------------------------------------------------------------------------

	/**
	 * 
	 * @param binaryEntry
	 */
	@Override
	public void delete(BinaryEntry binaryEntry) 
	{
		LOG.info("Called erase() with single binary entry");
		LOG.trace("erase...");
		delete(binaryEntry.getKey());
	}

	/**
	 * Remove the specified entries from the underlying store.
	 * 
	 * @param setBinEntries the set entries to be removed from the store
	 * 
	 */
	@Override
	public void deleteAll(Set setBinEntries) {
		//		LOG.info("#### called eraseAll() with set size: " + setBinEntries.size());
		//		LOG.debug("eraseAll. With {} entries", setBinEntries.size());
		//		if (!setBinEntries.isEmpty()) 
		//		{		
		//			for (Object entry : setBinEntries)
		//			{
		//				if (entry instanceof BinaryEntry)
		//				{
		//					BinaryEntry binEntry = (BinaryEntry) entry;
		//					if (delete(binEntry.getKey()))
		//						setBinEntries.remove(entry);
		//				}
		//			}
		//		}

		LOG.info("Called eraseAll() with set size: " + setBinEntries.size());
		LOG.debug("eraseAll. With {} entries", setBinEntries.size());

		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = connectionPool.getConnection();
			ps = connection.prepareStatement(this.statement_delete);
			// Disable auto commit
			connection.setAutoCommit(false);

			if (setBinEntries.size() <= this.jdbcBatchSize) {
				deleteBatch(setBinEntries, connection, ps);
			} else {
				Set batch = new HashSet(this.jdbcBatchSize);

				while (!setBinEntries.isEmpty()) {
					Iterator iterator = setBinEntries.iterator();
					while (iterator.hasNext() && batch.size() < this.jdbcBatchSize) {
						batch.add(iterator.next());
					}
					// Deletes objects in batch
					deleteBatch(setBinEntries, connection, ps);

					// Clears batch
					setBinEntries.removeAll(batch);
					batch.clear();
				}
			}

			// Commits transaction
			connection.commit();
		} catch (SQLException e) {
			LOG.error("SQLException thrown when deleting entries in batch", e);
			// TODO - throw exception if some entry fails?
		} finally {
			cleanUpResources(ps, connection);
		}
	}



	/**
	 * 
	 * @param binaryKey
	 */
	@Override
	public void retrieve(BinaryEntry binaryEntry) 
	{
		LOG.info("Called load() for single binary entry");
		LOG.trace("load(BinaryEntry binaryEntry)");

		// Get the key:
		Object id = binaryEntry.getKey();

		if (! (id instanceof String))
		{
			LOG.error("key is not a String object");
			return;
		}

		PreparedStatement stmt = null;

		ResultSet rs = null;
		Connection con = null;
		try
		{
			con = connectionPool.getConnection ();
			stmt = con.prepareStatement(statement_Load);
			stmt.setString(1, (String) id);
			rs = stmt.executeQuery();

			if (rs.next())
			{
				Blob res = rs.getBlob(this.binaryColumnName);

				Binary bin = new Binary(res.getBytes(1, (int)res.length() ) );
				binaryEntry.updateBinaryValue(bin);
			}

		}
		catch (SQLException ex)
		{
			LOG.error("SQLException: {}" , ex.getMessage());
			LOG.error("SQLException: SQLState= {} , VendorError= {}",ex.getSQLState(), ex.getErrorCode() );
		}

		finally 
		{
			// it is a good idea to release resources in a finally{} block in reverse-order of their creation 
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlEx) { } // ignore
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException sqlEx) { } // ignore
				stmt = null;
			}

			if (con != null){
				try{
					con.close();
				} catch (SQLException sqlEx) { } // ignore
				con = null;
			}
		}
	}


	/**
	 * 
	 * @param setBinEntries - a set of entries that needs to be updated with the loaded values 
	 */
	@Override
	public void retrieveAll(Set setBinEntries) 
	{
		LOG.info("Called loadAll() with set size: " + setBinEntries.size());
		LOG.debug("loadAll(Set setBinEntries)");

		if (!setBinEntries.isEmpty()) 
		{		
			HashMap <String, BinaryEntry> hashMap = new HashMap<String, BinaryEntry>();

			StringBuffer where = new StringBuffer();
			for (Object entry : setBinEntries)
			{
				if (entry instanceof BinaryEntry)
				{
					BinaryEntry binEntry = (BinaryEntry) entry;

					String id = (String)  ((BinaryEntry) entry).getKey();

					if (where.length()== 0)
						where.append(WHERE);
					else
						where.append(AND);

					where.append("CACHE_KEY ='");
					where.append(id);
					where.append("' ");

					hashMap.put(id, binEntry);

				}
			}

			Statement stmt = null;
			ResultSet rs = null;
			Connection con = null;
			try
			{
				con = connectionPool.getConnection ();
				stmt = con.createStatement();
				rs = stmt.executeQuery("SELECT * FROM "+ tableName + where);

				if (rs.next())
				{
					String id = rs.getString(this.idColumnName);
					BinaryEntry binaryEntry = hashMap.get(id);
					if (binaryEntry != null)
					{
						Blob res = rs.getBlob(this.binaryColumnName);
						Binary bin = new Binary(res.getBytes(1, (int)res.length() ) );
						binaryEntry.updateBinaryValue(bin);
					}
				}
			}
			catch (SQLException ex)
			{
				LOG.error("SQLException: {}" , ex.getMessage());
				LOG.error("SQLException: SQLState= {} , VendorError= {}",ex.getSQLState(), ex.getErrorCode() );
			}
			finally 
			{
				// it is a good idea to release resources in a finally{} block in reverse-order of their creation if they are no-longer needed
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException sqlEx) { } // ignore
					rs = null;
				}
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException sqlEx) { } // ignore
					stmt = null;
				}
				if (con != null){
					try{
						con.close();
					} catch (SQLException sqlEx) { } // ignore
					con = null;
				}
			}
		}
	}


	/**
	 * 
	 * @param binaryEntry
	 */
	@Override
	public void persist(BinaryEntry binaryEntry) 
	{
		LOG.info("Called store() with single binary entry");
		LOG.trace("store(BinaryEntry binaryEntry)");
//		// Get the key:
//		Object id = binaryEntry.getKey();
//
//		if (! (id instanceof String))
//		{
//			LOG.error("key is not a String object");
//			return;
//		}
//
//		if (true)
//		{
//			this.updsert((String)id, binaryEntry);
//			return;
//		}
		
		/*
		 * No problem in calling the multiple method with a single entry, this single method should not
		 * nevertheless be called by the write behind thread. 
		 */
		persistAll(Collections.singleton(binaryEntry));
	}

	/*
	 * (non-Javadoc)
	 * @see com.tangosol.net.cache.BinaryEntryStore#storeAll(java.util.Set)
	 */
	//	public void storeAll(Set setBinEntries) 
	//	{
	//		CacheFactory.log("#### called storeAll() with set size: " + setBinEntries.size());
	//		System.out.println("#### called storeAll() with set size: " + setBinEntries.size());
	//		LOG.debug("storeAll. With {} entries", setBinEntries.size());
	//		if (!setBinEntries.isEmpty()) 
	//		{		
	//			for (Object entry : setBinEntries)
	//			{
	//				if (entry instanceof BinaryEntry)
	//				{
	//					BinaryEntry binEntry = (BinaryEntry) entry;
	//					
	//					if (this.updsert((String) binEntry.getKey(), binEntry))
	//						setBinEntries.remove(entry);
	//					
	//				}
	//			}
	//		
	//		}
	//	}

	/**
	 * {@link BinaryEntry} implementation will have to implement equals() and hashCode() to be
	 * used correctly in a hash {@link Set}.
	 */
	// TODO - at the moment, configured just for oracle
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void persistAll(Set setBinEntries) {
		LOG.info("Call to storeAll() with set size: " + setBinEntries.size());
//		LOG.info("Call to storeAll() with set size: " + setBinEntries.size() + ", count: " + count.getAndIncrement());

		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = connectionPool.getConnection();
			ps = connection.prepareStatement(this.statement_insert_oracle);
			// Disable auto commit
			connection.setAutoCommit(false);

			if (setBinEntries.size() <= this.jdbcBatchSize) {
				storeBatch(setBinEntries, connection, ps);
			} else {
				Set batch = new HashSet(this.jdbcBatchSize);

				while (!setBinEntries.isEmpty()) {
					Iterator iterator = setBinEntries.iterator();
					while (iterator.hasNext() && batch.size() < this.jdbcBatchSize) {
						batch.add(iterator.next());
					}
					// Stores objects in batch
					storeBatch(setBinEntries, connection, ps);

					// Clears batch
					setBinEntries.removeAll(batch);
					batch.clear();
				}
			}

			// Commits transaction
			connection.commit();
		} catch (SQLException e) {
			LOG.error("SQLException thrown when storing entries in batch", e);
			// TODO - throw exception if some entry fails?
		} finally {
			cleanUpResources(ps, connection);
		}
	}

	// ###### Helper methods ######

	private void storeBatch(Set setBinEntries, Connection connection, PreparedStatement ps) {
		try {
			for (BinaryEntry entry : (Set<BinaryEntry>) setBinEntries) {
				ps.setString(1, (String) entry.getKey());
				ps.setBlob(2, entry.getBinaryValue().getInputStream());

				// Adds parameters to batch
				ps.addBatch();
			}

			// Executes all statements in batch
			ps.executeBatch();

			// Clears statements and parameters in batch, necessary?
			ps.clearBatch();
			ps.clearParameters();
		} catch (Exception e) {
			LOG.error("{} thrown when trying to store entries", e.getClass().getSimpleName());
			LOG.error("Exception: ", e);
			// TODO - throw exception here in case a batch fails?
		}
	}

	private void deleteBatch(Set setBinEntries, Connection connection, PreparedStatement ps) {
		try {
			for (BinaryEntry entry : (Set<BinaryEntry>) setBinEntries) {
				ps.setString(1, (String) entry.getKey());

				// Adds parameters to batch
				ps.addBatch();
			}

			// Executes all statements in batch
			ps.executeBatch();

			// Clears statements and parameters in batch, necessary?
			ps.clearBatch();
			ps.clearParameters();
		} catch (Exception e) {
			LOG.error("{} thrown when trying to delete entries", e.getClass().getSimpleName());
			LOG.error("Exception: ", e);
			// TODO - throw exception here in case a batch fails?
		}
	}

	/**
	 * 
	 * @param key
	 * @return 
	 * 
	 */
	private boolean delete(Object key) 
	{
		LOG.trace("delete " + key);
		boolean ret = true;
		if (! (key instanceof String))
		{
			LOG.error("key is not a String object");
			ret = false;
		}
		else
		{
			PreparedStatement statement = null;
			Connection con = null;
			try
			{
				con = connectionPool.getConnection();
				statement = con.prepareStatement(statement_delete);
				statement.setString(1, (String) key);
				statement.execute();
			}
			catch (SQLException ex)
			{
				LOG.error("SQLException: {}" , ex.getMessage());
				LOG.error("SQLException: SQLState= {} , VendorError= {}",ex.getSQLState(), ex.getErrorCode() );
				ret = false;
			}		
			finally 
			{
				// it is a good idea to release resources in a finally{} block, in reverse-order of their creation if they are no-longer needed
				if (statement != null) 
				{
					try {
						statement.close();
					} catch (SQLException sqlEx) { } // ignore
					statement = null;
				}

				if (con != null) {
					try{
						con.close();
					} catch (SQLException sqlEx) { } // ignore
					con = null;
				} 
			}
		}
		return ret;
	}

	/**
	 * 	
	 * @param id
	 * @param binaryEntry
	 * @return
	 */
	private boolean updsert(String id, BinaryEntry binaryEntry)
	{
		if (isOracle)
			return this.updsertOracle(id, binaryEntry);
		else
			return this.updsertMySQL(id, binaryEntry);
	}


	/**
	 * Valido en mySQL
	 * 
	 * @param binaryEntry
	 */
	private boolean updsertMySQL(String id, BinaryEntry binaryEntry) 
	{
		LOG.trace("updsertMySQL("+id+",..)");
		boolean ret = true;
		PreparedStatement statement = null;
		Connection con = null;
		try
		{
			con = connectionPool.getConnection ();
			statement = con.prepareStatement(statement_insert_mySQL);
			statement.setString(1, (String) id);

			Binary binaryValue = binaryEntry.getBinaryValue();
			statement.setBlob(2, binaryValue.getInputStream());

			statement.setBlob(3, binaryValue.getInputStream());
			ret = statement.execute();
		}
		catch (SQLException ex)
		{
			LOG.error("SQLException: {}" , ex.getMessage());
			LOG.error("SQLException: SQLState= {} , VendorError= {}",ex.getSQLState(), ex.getErrorCode() );
			ret = false;
		}		
		finally 
		{
			// it is a good idea to release resources in a finally{} block, in reverse-order of their creation, if they are no-longer needed
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException sqlEx) { } // ignore
				statement = null;
			}

			if (con != null){
				try{
					con.close();
				} catch (SQLException sqlEx) { } // ignore
				con = null;
			}
		} 
		return ret;
	}

	/**
	 * @param binaryEntry
	 */
	public boolean updsertOracle(String id, BinaryEntry binaryEntry) 
	{
		LOG.trace("updsertOracle("+id+",..)");
		boolean ret = true;
		PreparedStatement statement = null;
		Connection con = null;
		try
		{
			con = connectionPool.getConnection ();
			statement = con.prepareStatement(this.statement_insert_oracle);
			statement.setString(1, (String) id);
			Binary binaryValue = binaryEntry.getBinaryValue();
			statement.setBlob(2, binaryValue.getInputStream());


			//		    System.out.println("### SQL statement: \n" + this.statement_insert_oracle + "\n"
			//		    		+ "- string: " + id);
			ret =  statement.execute();
		}
		catch (SQLException ex)
		{

			LOG.error("SQLException: {}" , ex.getMessage());
			LOG.error("SQLException: SQLState= {} , VendorError= {}",ex.getSQLState(), ex.getErrorCode() );
			ret = false;
		}		
		finally 
		{
			// it is a good idea to release resources in a finally{} block, in reverse-order of their creation, if they are no-longer needed
			if (statement != null) 
			{
				try {
					statement.close();
				} catch (SQLException sqlEx) { } // ignore
				statement = null;
			}

			if (con != null){
				try{
					con.close();
				} catch (SQLException sqlEx) { } // ignore
				con = null;
			}
		} 
		return ret;
	}

	private void cleanUpResources(PreparedStatement ps, Connection connection) {
		if (ps != null) {
			try {
				ps.close();
			} catch (SQLException e) {
				LOG.error("SQLException while closing statement");
				LOG.error("Exception: ", e);
				// TODO - more handling?
			}
		}

		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				LOG.error("SQLException while closing connection");
				LOG.error("Exception: ", e);
				// TODO - more handling?
			}
		}
	}
}