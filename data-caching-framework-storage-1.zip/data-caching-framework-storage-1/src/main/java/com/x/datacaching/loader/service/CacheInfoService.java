package com.bbva.datacaching.loader.service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.LoadingConfigurationParameters;
import com.bbva.datacaching.loader.exception.LoadingProcessException;

/**
 * Service class, one per JVM classloader.
 * 
 * @author amp
 */
public class CacheInfoService {
	private static final ConcurrentMap<String, LoadingConfigurationParameters> CACHE_INFO_MAP =
			new ConcurrentHashMap<String, LoadingConfigurationParameters>();
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CacheInfoService.class);
	
	// ###### Service methods ######
	
	public static void putInCacheInfoMap(final String cacheName, final LoadingConfigurationParameters configParams) {
		if (configParams == null) {
			handleNullConfigParams(cacheName);
		}
		CACHE_INFO_MAP.put(cacheName, configParams);
		LOGGER.info("Registered an entry of {} for cache [{}]", LoadingConfigurationParameters.class.getSimpleName(),
				cacheName);
	}
	
	public static LoadingConfigurationParameters getCacheInfo(final String cacheName) {
		final LoadingConfigurationParameters configParams = CACHE_INFO_MAP.get(cacheName);
		if (configParams == null) {
			handleNullConfigParams(cacheName);
		}
		return configParams;
	}
	
	// ###### Helper methods ######
	
	private static void handleNullConfigParams(final String cacheName) {
		LOGGER.error("Loading configuration parameters for cache [{}] cannot be null", cacheName);
		throw new LoadingProcessException("Loading configuration parameters for cache " + cacheName + " cannot be null");
	}
}