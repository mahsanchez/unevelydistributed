package com.bbva.datacaching.loader.invocable;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.loader.invocable.observer.DistributedExecutionObserver;
import com.bbva.datacaching.loader.util.Utilities;
import com.bbva.datacaching.policy.StrategyDelegatorActionPolicy.PolicyType;
import com.bbva.datacaching.policy.manager.ActionPolicyManager;
import com.tangosol.net.AbstractInvocable;
import com.tangosol.net.ActionPolicy;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;

/**
 * Called from an {@link InvocableService} to set the {@link ActionPolicy} in all
 * cluster nodes through the {@link ActionPolicyManager} service.
 * 
 * Can be executed from a script.
 * @author amp
 */
public class PolicySetterInvocable extends AbstractInvocable {
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(PolicySetterInvocable.class);

	private static final Long EXECUTION_TIMEOUT = 10L; // 10s for executing script
	
	private String policyServiceKey;
	private PolicyType type;
	
	public PolicySetterInvocable(final String policyServiceKey, final PolicyType type) {
		this.policyServiceKey = policyServiceKey;
		this.type = type;
	}
	
	// TODO - more than exception handling, this would need an observer for retrials, the underlying call is not problematic 
	@Override
	public void run() {
		try {
			ActionPolicyManager.setEffectivePolicy(this.policyServiceKey, this.type);
			LOGGER.info("{} policy set for service using key [{}] on this node (runs in all storage nodes for this service)",
					this.type, this.policyServiceKey);
		} catch (Exception e) {
			LOGGER.error("{} thrown when running {} on this node - the policy may not have been correctly set",
					e.getClass().getSimpleName(), this.getClass().getSimpleName());
			throw new LoadingProcessException("Exception thrown when running " + this.getClass().getSimpleName() + " on "
					+ "this node", e);
		}
	}
	
	/**
	 * Enables this {@link Invocable} to be run from a script to set the regular Action Policy
	 * in all nodes carrying the cache's service.
	 * 
	 * NOTE: Requires that {@link ActionPolicy}'s are stored in the {@link ActionPolicyManager} by their
	 * service name.
	 * 
	 * @param args
	 */
	public static void main(String args[]) {
		if (args == null || args.length != 2) {
			LOGGER.error("Usage: {}  <INVOCATION_SERVICE_NAME> <SERVICE_NAME>", PolicySetterInvocable.class.getName());
			System.exit(1); // Exits script with error code
		}
		
		for (final String arg : args) {
			if (arg == null || "".equals(arg)) {
				LOGGER.error("Script parameters cannot be null or empty");
				System.exit(1); // Exits script with error code
			}
		}
		
		LOGGER.info("Running {}" + PolicySetterInvocable.class.getSimpleName());
		
		final String invocationServiceName = args[0];
		final String serviceName = args[1];
		
		try {
			final Set<Member> serviceStorageMembers = Utilities.serviceStorageMembers(serviceName);
			final InvocationService invocationService = 
					(InvocationService) CacheFactory.getService(invocationServiceName);
			final DistributedExecutionObserver observer = new DistributedExecutionObserver(
					serviceStorageMembers.size(), PolicySetterInvocable.class.getSimpleName());
			invocationService.execute(new PolicySetterInvocable(serviceName, PolicyType.REGULAR), serviceStorageMembers, observer);
			LOGGER.info("Sent an Invocable for execution in all nodes carrying service [{}] to set the REGULAR ActionPolicy "
					+ "for this service");
			LOGGER.info("Max wait time: {}s ......", EXECUTION_TIMEOUT);
			
			final boolean result = observer.await(EXECUTION_TIMEOUT, TimeUnit.SECONDS);
			// If result is false, there's been a timeout
			if (!result) {
				LOGGER.error("Timeout reached before executing the code in all nodes");
				throw new IllegalStateException("Timeout reached before executing the code in all nodes");
			}
		} catch (Exception e) {
			LOGGER.error("Exception thrown when running distributed code", e);
			System.exit(1); // Exits script with error code
		} finally {
			// Shuts down cache factory from this client node
			CacheFactory.shutdown();
		}
		
		// At this point, code has executed correctly in all nodes
		LOGGER.info("Successfully executed the code to set the REGULAR ActionPolicy in all nodes carrying the "
				+ "service [{}]", serviceName);
		System.exit(0); // Signals successful execution
	}
}