package com.bbva.datacaching.policy;

import com.tangosol.net.Action;
import com.tangosol.net.ActionPolicy;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.CacheService;
import com.tangosol.net.Service;

/**
 * Singleton per JVM classloader - the policy for loading is the same for al services. 
 * @author amp
 */
public class LoaderActionPolicy implements ActionPolicy {
	
	private static final String STORAGE_SERVER_ROLE_NAME = "CoherenceServer";
	
	// The JVM member will only have a single role
	private static final String ROLE_NAME = CacheFactory.ensureCluster().getLocalMember().getRoleName();

	private LoaderActionPolicy() {}
	
	public static LoaderActionPolicy getInstance() {
		return Holder.INSTANCE;
	}
	
	private static final class Holder {
		private static final LoaderActionPolicy INSTANCE = new LoaderActionPolicy();
	}
	
	@Override
	public void init(final Service service) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Does not allow cache service petitions during loading
	 */
	@Override
	public boolean isAllowed(final Service service, final Action action) {
		/* Only interested in cache service actions - permit all others, redistribution is necessary
		 * when loading a cache
		 */
		if(!(action instanceof CacheService.CacheAction)) {
			return true;
		}
		
		// Server nodes need to write data to the cache
		return STORAGE_SERVER_ROLE_NAME.equals(ROLE_NAME) ? true : false;
	}

	// ###### Object methods ######
	
	@Override
	public String toString() {
		return this.getClass().getSimpleName();
	}
}