package com.bbva.datacaching.loader;

/**
 * 
 * @author amp
 */
public enum RequiredConfigurationElements {
	MINIMUM_NODES("minimum-nodes"),
	INVOCATION_SERVICE_NAME("invocation-service-name"),
	/** Loading cache servers two purposes: loading control and {@link AbstractControllableCacheStore} */
//	INFO_CACHE_NAME("info-cache-name"), // Information for loading, to be accessed from an outside script
//	LOADING_CONTROL_CACHE_NAME("loading-control-cache-name"), // To control if loading should proceed for a cache
//	LOADING_BLOCKED_FLAG_KEY("loading-blocked-flag-key"),
//	POLICY_CACHE_NAME("policy-cache-name"), // For the replicated cache for ActionPolicy instances
	POLICY_SERVICE_KEY("policy-service-key"), // Key in the replicated cache for the created ActionPolicy
//	PETITIONS_ALLOWED_FLAG_KEY("petitions-allowed-flag-key"),
//	DAO_CLASS("dao-class"),
//	QUERY_FILE_PATH("query-file-path"), // Path pointing to the file with the SQL divisions query
	TABLE_NAME("table-name"),
	COLUMN_NAME("column-name"),
	BATCH_SIZE("batch-size");
//	LOADING_TIMEOUT("loading-?timeout"); // In ms
	
	private String name;
	
	private RequiredConfigurationElements(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
}