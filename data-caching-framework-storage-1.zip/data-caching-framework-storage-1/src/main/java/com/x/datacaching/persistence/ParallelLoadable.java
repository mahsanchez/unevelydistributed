package com.bbva.datacaching.persistence;

import java.sql.Connection;
import java.sql.ResultSet;

import com.bbva.datacaching.loader.NodeLoadLimits;

/**
 * Interface with the necessary methods to use the Storage functionality.
 * 
 * Each cached object type should have a corresponding implementation of this interface.
 * 
 * @author amp
 *
 * @param <K>	key class for the cached entity
 * @param <V>	entity class for the cached entity
 */
public interface ParallelLoadable<K, V> {
	
	/**
	 * In all persistence options, getting a reference to the connection is necessary in order to run the query to find
	 * the ranges.
	 * 
	 * @return		a {@link Connection} to the back-end store
	 */
	Connection getConnection(); // Needed to execute limits query, makes sense to use the same pool that 
	// accesses the same DB table
	
	/**
	 * Closes the given {@link Connection}.
	 * 
	 * @param connection	the {@link Connection} to be closed
	 */
	void closeConnection(Connection connection);
	
	/**
	 * This method needs to be declared at this interface's level, in all cases there will be a JDBC
	 * query to calculate ranges, for which there's a call to a JDBC typed method to get the correct
	 * type from the {@link ResultSet}.
	 * 
	 * @return		the {@link Class} of the key used to store the object in the cache
	 */
	Class<K> getKeyClass();
	
	/**
	 * Returns a string query (which should be specified in the underlying data-access
	 * idiom/implementation) to select all entities from the back-end within a given range.
	 * 
	 * NOTE: the returned query should always be parameterized with the upper and lower limit
	 * of the range to be loaded (check the site's documentation for more info on the format
	 * that this parameterization should take, according to the underlying persistence
	 * implementation).
	 * 
	 * @return		parameterized query to select all entities within a range, in string format
	 */
	String selectObjectsInRangeQuery();
	
	/**
	 * Implementations should load entities from the database to a cache within the range specified
	 * by the {@link NodeLoadLimits}.
	 * 
	 * NOTE: in most cases, this implementation will be provided by a class internal to this framework,
	 * so clients will not have to provide their own.
	 * 
	 * @param cacheName		name of the cache to load the entities in
	 * @param batchSize		size of batch for loading to the cache
	 * @param limits		range limits for loading entities in a node
	 */
	void load(String cacheName, int batchSize, NodeLoadLimits<?> limits);
}