package com.bbva.datacaching.loader.connection;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;

import javax.sql.DataSource;

import oracle.ucp.jdbc.PoolDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.kltt.jmxconnpool.wrappers.implementations.PoolWrapperManager;
import com.bbva.kltt.jmxconnpool.wrappers.interfaces.IPoolWrapperManager;


/**
 * This class uses Oracle® Universal Connection Pool for JDBC
 * http://docs.oracle.com/cd/E11882_01/java.112/e12265.pdf
 * 
 * Singleton class, one per classloader in a JVM.
 * 
 * @author AGR
 *
 */
public class JMXConnectionPool implements IConnectionPool  {
	
	/** Logger */
	private static final Logger LOGGER = LoggerFactory.getLogger(JMXConnectionPool.class);
	
	private static final String POOL_CONFIG_FILE = "connection-pool.properties";
	
	private static final int GET_CONNECTION_TRIES = 3;
	
	/** Pool data source */
	private final PoolDataSource pds;
	
	/**
	 * 
	 * @param config
	 * @throws Exception 
	 */
	private JMXConnectionPool() {
		final Properties props = new Properties();
		
		// Gets DB configuration file
		try {
			props.load(this.getPoolConfigurationFile());
		} catch (Exception e) {
			LOGGER.error("Problem loading or reading pool configuration file: {}", POOL_CONFIG_FILE);
			throw new LoadingProcessException("Problem loading or reading pool configuration file: "
					+ POOL_CONFIG_FILE);
		}
		
		
//		// Gets configuration parameters from file
//		final Configuration config = ConfigReader.readConfiguration(configFile);
//		
//		if (config == null  || (!config.validate())) {
//			LOGGER.error("Error creating {}. Errors found in configuration file [{}]",
//					this.getClass().getSimpleName(), configFile);
//			throw new IllegalStateException("Error creating " + this.getClass().getSimpleName() 
//					+ ". Errors found in configuration file");
//		}
//		
//		try {
//			Class.forName(config.getDriver()).newInstance();
//		} catch (InstantiationException e) {
//			LOGGER.error(MESSAGE_LOADING_ERROR, e);
//			throw new IllegalStateException(MESSAGE_LOADING_ERROR, e);
//		} catch (IllegalAccessException e) {
//			LOGGER.error(MESSAGE_LOADING_ERROR, e);
//			throw new IllegalStateException(MESSAGE_LOADING_ERROR, e);
//		} catch (ClassNotFoundException e) {
//			LOGGER.error(MESSAGE_LOADING_ERROR, e);
//			throw new IllegalStateException(MESSAGE_LOADING_ERROR, e);
//		}

		LOGGER.info("Creating PoolDataSource from factory from pool config params in file {}",
				POOL_CONFIG_FILE);
		
		final IPoolWrapperManager managerPoolWrappers = PoolWrapperManager.getInstance();
		
		try {
			pds = managerPoolWrappers.newWrapperPoolDataSource(props);
		} catch (Exception e) {
			LOGGER.error("Exception thrown when obtaining a connection pool", e);
			throw new LoadingProcessException("Exception thrown when obtaining a connection pool", e);
		}

//		try {
//			pds.setConnectionFactoryClassName(config.getConnectionFactory());
//			
//			pds.setURL(config.getUrl());
//			
//			if (config.getUserName() != null)
//				pds.setUser(config.getUserName()); 
//			
//			if (config.getPassword() != null)
//				pds.setPassword (config.getPassword());
//			
//			
//			if (config.getMaxConnectionReuseCount() >= 0)
//				pds.setMaxConnectionReuseCount( config.getMaxConnectionReuseCount());
//			
//			
//			//       if (config.getPort() > 0)
//			//       {
//			//    	   pds.setPortNumber(1530);   
//			//       }
//			
//			pds.setInitialPoolSize(config.getInitialPoolSize());
//			pds.setMinPoolSize(config.getMinPoolSize());
//			pds.setMaxPoolSize(config.getMaxPoolSize());
//			
//			pds.setTimeToLiveConnectionTimeout(config.getTimeToLiveConnectionTimeout());       
//			pds.setAbandonedConnectionTimeout(config.getAbandonedConnectionTimeout());
//			pds.setConnectionWaitTimeout(config.getConnectionWaitTimeout());
//			pds.setInactiveConnectionTimeout(config.getInactiveConnectionTimeout());
//			pds.setMaxStatements(config.getMaxStatements());
			
			// TODO - delete, just for info
			LOGGER.info("---- Connection pool params: connectionWaitTimeout: {}s", pds.getConnectionWaitTimeout());
			LOGGER.info("---- Connection pool params: timeToLiveConnectionTimeout: {}s", pds.getConnectionWaitTimeout());
			LOGGER.info("---- Connection pool params: abandonedConnectionTimeout: {}s", pds.getAbandonedConnectionTimeout());
			LOGGER.info("---- Connection pool params: inactiveConnectionTimeout: {}s", pds.getInactiveConnectionTimeout());
			LOGGER.info("---- Connection pool params: maxStatements: {}", pds.getMaxStatements());
//		} catch (SQLException e) {
//			LOGGER.error("{} thrown when setting PoolDataSource parameters:\n {}", e.getClass().getSimpleName(), e);
//			throw new IllegalStateException("SQLException when setting PoolDataSource parameters");
	}
	
	// Infrastructure for Lazy Singleton initialization.
	private static final class SingletonHolder {
		private static final JMXConnectionPool INSTANCE = new JMXConnectionPool();
	}
	
	/**
	 * Service method to get the single instance of {@link JMXConnectionPool} per JVM.
	 * @return
	 */
	public static final JMXConnectionPool getInstance() {
		return SingletonHolder.INSTANCE;
	}
	
	/**
	 * 
	 * @return
	 * @throws SQLException
	 */
	// TODO - should this synchronize?
	public Connection getConnection() throws SQLException {
		return this.pds.getConnection();
	}
	
	/**
	 * This method is useful in case the {@link DataSource}, rather than the {@link Connection}, is
	 * needed.
	 * 
	 * Do not mutate the returned {@link DataSource}.
	 * 
	 * NOTE: there are no guarantees as to the immutability of the returned {@link DataSource}, as the
	 * provider does not make it clear. Since this method is only for internal use within this
	 * framework, it is deemed acceptable as it's used is controlled and the returned instance is in
	 * no case being mutated.
	 * 
	 * @return	a {@link DataSource} for acquiring {@link Connection}s.
	 */
	public DataSource getPoolDataSource() {
		return this.pds;
	}
	
	// ###### Helper methods ######
	
	private InputStream getPoolConfigurationFile() {
		return Thread.currentThread().getContextClassLoader().getResourceAsStream(POOL_CONFIG_FILE);
	}
}
