package com.bbva.datacaching.policy.manager;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.policy.StrategyDelegatorActionPolicy;
import com.bbva.datacaching.policy.StrategyDelegatorActionPolicy.PolicyType;

/**
 * Service class, one per node, static
 * An update to the internal concurrent map is a rare occurrence, only when starting and finishing loading
 * a cache 
 * 
 * @author amp
 */
public class ActionPolicyManager {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ActionPolicyManager.class);
			
	private static final ConcurrentMap<String, StrategyDelegatorActionPolicy> SERVICE_POLICY_MAP = 
			new ConcurrentHashMap<String, StrategyDelegatorActionPolicy>();
	/*
	 * Will be run by InvocableService to execute in all nodes
	 */
	/**
	 * 
	 * @param serviceName
	 * @param value
	 */
	public static void putInPolicyMap(final String serviceName, final StrategyDelegatorActionPolicy value) {
		/* More than one cache may be configured in the same service (and therefore using the same policy
		 * service key), there's no need to place it in the internal map after the first. */
		SERVICE_POLICY_MAP.putIfAbsent(serviceName, value);
		LOGGER.info("A reference to a {} instance has been stored in {} for service [{}]",
				new Object[]{value.getClass().getSimpleName(), ActionPolicyManager.class.getSimpleName(), serviceName});
	}
	
	/* This method is not fully concurrent, but it is not very relevant, this method runs only
	 * during the loading process and not during regular execution time. This will be called
	 * by an InvocationService to run in all cluster nodes, to update the effective policy
	 * for a given service in all nodes - there is no synchronization mechanism for all the nodes.
	 */
	// TODO - Set up a synchronization mechanism for all the nodes.
	/**
	 * 
	 * @param serviceName
	 * @param type
	 */
	public static void setEffectivePolicy(final String serviceName, final PolicyType type) {
		// Same policy reference as is stored in map and the same that Coherence administers
		StrategyDelegatorActionPolicy policy = SERVICE_POLICY_MAP.get(serviceName);
		if (policy == null) {
			LOGGER.error("{} instance should not be null in {} for service key [{}]",
					new Object[]{StrategyDelegatorActionPolicy.class.getSimpleName(), 
						ActionPolicyManager.class.getSimpleName(), serviceName});
			throw new IllegalStateException(StrategyDelegatorActionPolicy.class.getSimpleName()
					+ " instance should not be null in "
					+ ActionPolicyManager.class.getSimpleName() + " for service key ["
					+ serviceName + "]");
		}
		
		if (type == PolicyType.LOADING) {
			policy.establishLoadingPolicy();
			LOGGER.info("Loading ActionPolicy set for service {}", serviceName);
		} else {
			policy.establishRegularPolicy();
			LOGGER.info("Regular ActionPolicy set for service {}", serviceName);
		}
	}
}