package com.bbva.datacaching.persistence.store.cachestore;

import java.util.Set;

import com.bbva.datacaching.persistence.store.management.ControllableStoreMBean;
import com.tangosol.util.BinaryEntry;

public interface ControllableBinaryEntryStore  extends ControllableStoreMBean {
	
	void delete(BinaryEntry binaryEntry);
	
	void deleteAll(Set setBinEntries);
	
	void persist(BinaryEntry binaryEntry);
	
	void persistAll(Set setBinEntries);
	
	void retrieve(BinaryEntry binaryEntry);
	
	void retrieveAll(Set setBinEntries);
}
