package com.bbva.datacaching.loader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.loader.util.Utilities;
import com.bbva.datacaching.util.processor.RemoveProcessor;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationObserver;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;
import com.tangosol.net.NamedCache;
import com.tangosol.util.InvocableMap.EntryProcessor;

/**
 * <p>
 * This class will only run on the node executing the {@link LoadingProcess} thread.
 * </p>
 * 
 * <p>
 * If the execution of an {@link Invocable} on a {@link Member} fails because
 * of an {@link Exception} thrown or because the {@link Member}, a check will
 * be performed to confirm if the current number of storage members is greater than
 * or equal to the minimum number specified in configuration. If it is not,
 * the loading process will be stopped in the {@link Member} launching the service
 * (the one in which this class runs), by canceling the {@link Future} wrapping
 * the single {@link Thread} executing the {@link LoadingProcess} by calling 
 * {@link Startup}.cancelExecutingThread(). Note that any Invocable sent for
 * execution on a {@link Member} other than the one executing the {@link LoadingProcess}
 * will continue execution on that node.   
 * </p> 
 *  
 * @author amp
 */
public class LoadingTaskObserver implements InvocationObserver {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LoadingTaskObserver.class);
	
//    private final BusinessObjectDAO daoInstance;
    private final CountDownLatch latch;
    private final Lock lock;
    
    private Member localMember;
    
    /* All access to the two following variables should be done within
     * the same lock */
    private final Map<Integer, Member> workingMemberMap;
    private final Map<Integer, Set<NodeLoadTask>> memberTaskMap;
    private final int minimumNodes;
    private final String invocationServiceName;
    private final String cacheName;
    private final String loadingBlockedFlagKey;
    private final NamedCache controlCache = null; // TODO - not used at the moment
//    private final InvocationService invocationService;
   
//    public LoadObserver(int nodes) {
//    	this.numberOfMembers = nodes;
//    	this.latch = new CountDownLatch(nodes);
//        this.workingMemberList = getInitialStorageMembers();
//        this.lock = new ReentrantLock();
//
//        this.lock.lock();
//        try {
//        	if (this.numberOfMembers != this.workingMemberList.size())
//        		throw new IllegalStateException("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//        				"lower number of storage nodes than expected" + " \n" +
//        				"Available storage nodes: " + this.workingMemberList.size() + "\n" +
//        				"Expected number of storage nodes at start-up: " + this.numberOfMembers);
//        } finally {
//        	this.lock.unlock();
//        }
//    }
    
    public LoadingTaskObserver(final Map<Integer, Set<NodeLoadTask>> memberTaskMap,
    		final int minimumNodes, final String invocationServiceName, final String cacheName,
    		final String loadingBlockedFlagKey) {
    	this.memberTaskMap = memberTaskMap;
    	this.minimumNodes = minimumNodes;
    	this.invocationServiceName = invocationServiceName; 
    	this.cacheName = cacheName;
//    	this.controlCache = CacheFactory.getCache(controlCacheName);
    	this.loadingBlockedFlagKey = loadingBlockedFlagKey;
    	/* Sets size of latch to the number of load divisions, which accounts for all loading
    	 * tasks, all of which will have to be completed to release the latch */
    	this.latch = new CountDownLatch(getNumberOfLoadDivisions()); 
    	this.lock = new ReentrantLock();
    	/* Initially it is assumed that all current storage members are working. Note that the
    	 * current number may be more or less than the number used for task division. In case
    	 * it is more, not all nodes will initially be given a task (it may change if one or
    	 * more executing nodes fail or leave). If it is less, one or more nodes will get more
    	 * than a loading task */
    	this.workingMemberMap = Utilities.getCurrentStorageMembersMap(cacheName);
    	this.localMember = CacheFactory.getCluster().getLocalMember();
//    	this.invocationService = (InvocationService) CacheFactory.getService(invocationServiceName);
    	
    	LOGGER.info("On initialization, the observer's countdown latch has been set to {}", this.latch.getCount());
//    	this.lock.lock();
//    	// IS THIS NECESSARY? DELETE
//    	try {
//    		if (this.workingMemberList.size() < this.minimumNodes)
//    			throw new IllegalStateException("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//    					"lower number of storage nodes than expected" + " \n" +
//    					"Available storage nodes: " + this.workingMemberList.size() + "\n" +
//    					"Expected number of storage nodes at start-up: " + this.minimumNodes);
//    	} finally {
//    		this.lock.unlock();
//    	}
    }
    
//    public LoadingProcessObserver(Map<Integer, Set<NodeLoadLimits<Object>>> memberLimitsMap) {
//    	this.minNumberOfMembers = memberLimitsMap.size();
//    	this.workingMemberList = Utilities.getCurrentStorageMembers(); // Should this be a field? 
//    	this.memberLimitsMap = getCopyOfMap(memberLimitsMap);
//    	this.latch = new CountDownLatch(this.minNumberOfMembers); // Fixes size of latch
//    	this.lock = new ReentrantLock();
//    	
//    	log("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//				"INITIAL LATCH SIZE: " + this.latch.getCount());
//    	
//    	this.lock.lock();
////        try {
////        	if (this.minNumberOfMembers < this.workingMemberList.size())
////        		throw new IllegalStateException("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
////        				"lower number of storage nodes than expected" + " \n" +
////        				"Available storage nodes: " + this.workingMemberList.size() + "\n" +
////        				"Expected number of storage nodes at start-up: " + this.minNumberOfMembers);
////        } finally {
////        	this.lock.unlock();
////        }
//        
//        try {
//        	if (this.workingMemberList.size() < this.minNumberOfMembers)
//        		throw new IllegalStateException("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//        				"lower number of storage nodes than expected" + " \n" +
//        				"Available storage nodes: " + this.workingMemberList.size() + "\n" +
//        				"Expected number of storage nodes at start-up: " + this.minNumberOfMembers);
//        } finally {
//        	this.lock.unlock();
//        }
//    }
   
    @Override
    public void invocationCompleted() {
//    	LOGGER.info("[{}] MemberId {}: finished execution of loading Invocable in all service members",
//    			this.cacheName, this.localMember.getId());
	}

    @Override
	public void memberCompleted(final Member member, final Object result) {
//		/* Checks returned object to find whether the given range has been completed
//		 * or not (in which case, an exception would have been thrown) */
//    	final Map<Integer, NodeLoadingTask> taskState = (Map<Integer, NodeLoadingTask>) result;
//		// Verifies task result for conformity
//		if (taskState == null) {
//			log("***** taksState = null *****");
//			throw new IllegalStateException("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//					"invocation results should never be null");
//		}
//		if (taskState.size() != 1) {
//			log("***** taksState != 1 *****");
//			throw new IllegalStateException("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//					"invocation results are not in the expected format");
//		}
//		if (taskState.get(NodeLoadingTask.SUCCESSFUL_COMPLETION) != null) {
//			actForMemberCompleted(member, taskState.get(NodeLoadingTask.SUCCESSFUL_COMPLETION));
//		} else if (taskState.get(NodeLoadingTask.FAILED_COMPLETION) != null) {
//			actForMemberFailed(member, taskState.get(NodeLoadingTask.FAILED_COMPLETION));
//		} else {
//			log("***** taksState != 0 && taskState != 1 *****");
//			throw new IllegalStateException("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//					"invocation results are not in the expected format");
//		}
		
		/* Checks returned NodeLoadingTask to find whether the given range has been completed
		 * or not (in which case, an exception would have been thrown) */
		final NodeLoadTask returnedTask = (NodeLoadTask) result;
		if (returnedTask.isSuccessfulyExecuted()) {
			actForMemberCompleted(member, returnedTask);
		} else {
			actForMemberFailed(member, returnedTask);
		}
	}
	
	private void actForMemberCompleted(final Member completedMember, final NodeLoadTask task) {
//		try {
//			/* Only acts if range completes normally without having left before (in 
//			 * which case memberLeft would have been called, removed the member from
//			 * workingMemberList, and repeated all ranges for the member */
//			if (this.workingMemberList.contains(member)) {
//				/* Range completed successfully for member and the member has not 
//				 * yet left */
//				this.latch.countDown();
//				log("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//						"COUNTDOWN: " + this.latch.getCount());
//				/* Removes range from member, since it has successfully been loaded, to
//				 * prevent range from loading again if the member is used for a re-trial */
//				this.ranges.get(member.getId()).remove(limits);
//				log("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//						"MEMBER COMPLETED --- completed range " + limits.toString() + "on member " +
//						 member.getId());
//			} else {
//				log("***** CODE SHOULD NOT GET HERE: completed member --> " + member.getId() + " *****");
//			}
		this.lock.lock();
		try {
			/* Only acts if range completes normally without having left before (in 
			 * which case the member will no longer be part of the cluster). If member
			 * has left the cluster (as confirmed by the following check), the latch
			 * will not be decremented for the successful range (nothing will be done
			 * in such case); all ranges from the node that left will be repeated in a
			 * different node */
			if (Utilities.getCurrentStorageMembersMap(this.cacheName).containsKey(completedMember.getId())) {
				/* Range completed successfully for member and the member has not 
				 * yet left */
				LOGGER.info("Member completed: finished executing Invocable for range {} "
						+ "on member {}\n"
						+ "Current working members: {}", new Object[]{task.getLoadLimits().toString(),
								completedMember.getId(), this.workingMemberMap.keySet()});
				this.latch.countDown();
				LOGGER.info("Decremented countdown latch (current count: {})",
						new Object[]{this.latch.getCount()});
				/* Removes range from member, since it has successfully been loaded, to
				 * prevent range from loading again if the member is used for a retrial */
				this.memberTaskMap.get(completedMember.getId()).remove(task);
				/* If member has previously been removed from workingMemberList but has
				 * been able to successfully run a range, re-adds the member to the
				 * workingMemberList, as it may be able to load more */
				if (!this.workingMemberMap.containsKey(completedMember.getId()))
					this.workingMemberMap.put(completedMember.getId(), completedMember);
			}
		} finally {
			this.lock.unlock();
		}
	}
	
	/**
	 * Effectively replaces memberFailed(), since the {@link NodeLoadTask}'s run()
	 * method catches any {@link Exception} that may be thrown. This is done so that
	 * memberCompleted() is called even in case of {@link Exception}, to access the
	 * {@link NodeLoadLimits} that failed for that member so they can be retried on
	 * a different node.
	 *  
	 * @param failedMember
	 * @param retrialLimits
	 */
	private void actForMemberFailed(final Member failedMember, final NodeLoadTask retrialTask) {
		this.lock.lock();
		try {
			// Removes task from failed member
			this.memberTaskMap.get(failedMember.getId()).remove(retrialTask);
			// Removes failed member from workingMemberMap
			this.workingMemberMap.remove(failedMember.getId());
			/* Check if the current number of nodes is greater than or equal to the minimum
			 * given by configuration. If not, stops the LoadingProcess on this node */
			if (!checkMinimumNumberOfNodes()) {
				/* Before exiting, sets the flag in the control cache to enable loading from 
				 * any node upon node launch */
				// TODO - hook with mechanism to enable/disable loading
//				enableLoadingOnStartup();
				LOGGER.info("Current number of nodes carrying this cache's service ({}) is less than the "
						+ "configured minimum number ({})\n" 
						+ "The loading process will stop from this point for this cache",
						new Object[]{Utilities.getCurrentStorageMembersListForService(this.cacheName).size(),
								this.minimumNodes});
				// Stops the loading process on this member
				// TODO - Thread interruption mechanism
//				Startup.cancelLoadingExecutingThread();
				return;
			}
			// Picks a member randomly to rerun task
			final Member retrialMember = pickRandomWorkingMember();
//			final NodeLoadingTask retrialTask = new NodeLoadingTask(retrialLimits, retrialMember, this.daoInstance);
			/* Adds the task to the new member, in case the retrial member fails and the
			 * limits have to be retried */
			this.memberTaskMap.get(retrialMember.getId()).add(retrialTask);
//			this.invocationService.execute(
//					retrialTask, Collections.singleton(retrialMember), this);
			final InvocationService service = (InvocationService) CacheFactory.getService(this.invocationServiceName);
			service.execute(retrialTask, Collections.singleton(retrialMember), this);
			LOGGER.info("Member failed: execution of Invocable for range {} on member {} "
					+ "has failed, retrying range on member {}\n"
					+ "Current working members: {}",
					new Object[]{retrialTask.getLoadLimits().toString(), failedMember.getId(),
							retrialMember.getId(), this.workingMemberMap.values()});
		} finally {
			this.lock.unlock();
		}
	}

	/**
	 * Unused, failure cases are handles by {@link #memberCompleted(Member, Object)}.
	 */
	@Override
	public void memberFailed(Member member, Throwable throwable) {
		LOGGER.error("Runtime should never call {}.memberFailed(), failed members "
				+ "are handled by {}.memberCompleted()", new Object[]{this.getClass().getSimpleName(),
						this.getClass().getSimpleName()});
		throw new UnsupportedOperationException("Runtime should never call "
				+ this.getClass().getSimpleName() + ".memberFailed(), failed members are handled by "
				+ this.getClass().getSimpleName() + ".memberCompleted()");
	}

	@Override
	public void memberLeft(final Member departedMember) {
		LOGGER.info("Member left: member {} left the service or the cluster", this.cacheName,
				departedMember.getId());
		this.lock.lock();
		try {
//			// Removes member that has left, if it has not already been removed by a previous memberLeft on the the member
//			if (this.workingMemberMap.containsKey(departedMember.getId())) {
//				this.workingMemberMap.remove(departedMember.getId());
//				/* Repeats all tasks for the node, even though one or more pending tasks may 
//				 * eventually complete successfully, since this node does not know whether
//				 * other members will succeed or fail at this stage */
//				for (NodeLoadTask retrialTask : this.memberTaskMap.get(departedMember.getId())) {
//					/* Check if the current number of nodes is greater than or equal to the minimum
//					 * given by configuration. If not, stops the LoadingProcess on this node */
//					if (!checkMinimumNumberOfNodes()) {
//						LOGGER.info("MemberId {}: current number of nodes ({}) is less than the "
//								+ "configured minimum number ({})\n" 
//								+ "The loading process will stop from this point",
//								new Object[]{localMember.getId(), 
//										Utilities.getCurrentStorageMembers().size(), this.minNumberOfMembers});
//						// Stops the loading process on this member
//						Startup.cancelExecutingThread();
//					}
//					// Picks a member randomly for each task
//					final Member retrialMember = pickRandomWorkingMember();
//					/* Adds task to the new member, in case the retrial member fails and the
//					 * limits have to be retried  */
//					this.memberTaskMap.get(retrialMember.getId()).add(retrialTask);
//					log("|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//							"as member has left, repeating range " + retrialTask.getLoadLimits().toString() + " now on member " + retrialMember.getId());
//					InvocableLauncher.fireInvocable(retrialTask, retrialMember, this);
//					LOGGER.info("Member left: execution of Invocable for range {} on departed "
//							+ "member {} will be retried on member {}", 
//							new Object[]{retrialTask.getLoadLimits().toString(), departedMember.getId(),
//									retrialMember.getId()});
//				}
//			}
			
			/* Removes member that has left (it has may already have been removed by a previous
			 * memberLeft or memberFailed on the the same member) */
			this.workingMemberMap.remove(departedMember.getId());
			/* Repeats all tasks for the node, even though one or more pending tasks may 
			 * eventually complete successfully, since this node does not know whether
			 * other members will succeed or fail at this stage */
			final Set<NodeLoadTask> departedMemberTasks = this.memberTaskMap.get(departedMember.getId());
			for (NodeLoadTask retrialTask : departedMemberTasks) {
				/* Check if the current number of nodes is greater than or equal to the minimum
				 * given by configuration. If not, stops the LoadingProcess on this node */
				if (!checkMinimumNumberOfNodes()) {
					/* Before exiting, sets the flag in the control cache to enable loading from 
					 * any node upon node launch */
					// TODO - hook with mechanism to enable/disable loading
//					enableLoadingOnStartup();
					LOGGER.info("Current number of nodes ({}) is less than the "
							+ "configured minimum number ({})\n" 
							+ "The loading process will stop from this point",
							new Object[]{Utilities.getCurrentStorageMembersListForService(this.cacheName).size(),
									this.minimumNodes});
					// Stops the loading process on this member
					// TODO - Thread interrupting mechanism
//					Startup.cancelLoadingExecutingThread();
					return;
				}
				// Picks a member randomly for each task
				final Member retrialMember = pickRandomWorkingMember();
				/* Adds task to the new member, in case the retrial member fails and the
				 * limits have to be retried  */
				this.memberTaskMap.get(retrialMember.getId()).add(retrialTask);
//				this.invocationService.execute(
//						retrialTask, Collections.singleton(retrialMember), this);
				final InvocationService service = (InvocationService) CacheFactory.getService(this.invocationServiceName);
				service.execute(retrialTask, Collections.singleton(retrialMember), this);
				LOGGER.info("Member left: execution of Invocable for range {} on departed "
						+ "member {} will be retried on member {}\n"
						+ "Current working members: {}", 
						new Object[]{retrialTask.getLoadLimits().toString(), departedMember.getId(),
								retrialMember.getId(), this.workingMemberMap.values()});
			}
			/* Removes the tasks associated to the departed member because they have been added
			 * to, and sent for execution in, other members */
			departedMemberTasks.clear();
		} finally {
			this.lock.unlock();
		}
	}

	/**
	 * 
	 * 
	 * @param timeOut
	 * @param timeUnit
	 */
	public boolean await(final long timeOut, final TimeUnit timeUnit) {
		try {
			LOGGER.info("Timeout for the latch in the {} has been set to {} {}", 
					new Object[]{this.getClass().getSimpleName(), timeOut, timeUnit.toString()});
			
			/* Blocking call, until all loading ranges complete in their respective nodes or
			 * call times out. */
			return this.latch.await(timeOut, timeUnit);
		} catch (InterruptedException e) {
			LOGGER.error("{} thrown during latch waiting in {}", new Object[]{e.getClass().getSimpleName(), 
							this.getClass().getName()});
			// Thread.currentThread().interrupt();
			throw new LoadingProcessException(e.getClass().getSimpleName() + " thrown during latch waiting");
		}
	}

	/**
	 * Checks if the current number of storage {@link Member}s is greater than or equal to
	 * the minimum number specified in configuration.
	 * 
	 * @return true if the current number of storage nodes is greater than or equal to the
	 * 		minimum number defined in configuration, false otherwise
	 */
	private boolean checkMinimumNumberOfNodes() {
		return Utilities.getCurrentStorageMembersListForService(this.cacheName).size() >= this.minimumNodes;
	}
	
	/*
	 * This method is only called from within a locked block
	 * TODO - check for quorum condition here instead of empty workerMemberList and
	 * change methods name to relate to that as well
	 * This runs on the node that is carrying out the loading - an exception
	 * thrown by this method will propagate and not be handled, thus stopping the loader.
	 */
	/**
	 * Logging (i/o) inside lock, probably a single thread will run this.
	 * 
	 * @return
	 */
	private Member pickRandomWorkingMember() {
//		if (!checkQuorumCondition()) {
//			log("\n\n\n\n\n\n****\nSTOPPING STARTUP NODE\n|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//					"there are no sufficient members left for quorum\n****\n\n\n\n\n");
//			/* Sets loadingStarted to false in control cache so the next node that is
//			 * launched - to get quorum again - starts the loading process when quorum is
//			 * recovered - everything again on every node */
//			CacheFactory.getCache(QUORUM_CACHE).remove(LOADING_STARTED_KEY);
//			// Stops loading process (i.e. the executing thread) in this node (the loading node)
//			if (LoadingStarter.getExecutingThread() != null)
//				LoadingStarter.getExecutingThread().cancel(true);
//			throw new IllegalStateException("\n*****\nSTOPPING STARTUP NODE\n|-|-|-|-| " + this.getClass().getSimpleName() + ": " +
//					"there are no sufficient members left for quorum\n*****\n");
//		}
		this.lock.lock();
		try {
			if (this.workingMemberMap.size() == 0) {
				LOGGER.error("Insufficient working members left carrying this cache's service for retrial of tasks",
						this.localMember.getId());
				throw new LoadingProcessException("Insufficient working members left carrying this cache's service for retrial of tasks");
			}
			final List<Integer> listOfKeys = new ArrayList<Integer>(this.workingMemberMap.keySet());
			return this.workingMemberMap.get(listOfKeys.get(new Random().nextInt(listOfKeys.size())));
		} finally {
			this.lock.unlock();
		}
	}
	
	private final int getNumberOfLoadDivisions() {
		int count = 0;
		for (Set<NodeLoadTask> taskSet : this.memberTaskMap.values()) {
			count += taskSet.size();
		}
		return count;
	}
	
	/**
	 * Removes the flag from the control cache so that any node can initiate the loading
	 * process on startup (only one will continue, as each will send an 
	 * {@link EntryProcessor} to set the value in the control cache to indicate that
	 * loading has already started from other node - the first one to get a response
	 * from the {@link EntryProcessor}).
	 */
	private void enableLoadingOnStartup() {
		this.controlCache.invoke(loadingBlockedFlagKey, new RemoveProcessor());
		LOGGER.info("[{}] The distributed loading has been enabled for "
				+ "subsequent nodes to start", this.cacheName);
	}
}