package com.bbva.datacaching.persistence.store.cachestore;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.oracle.coherence.patterns.pushreplication.PublishingCacheStore;
import com.tangosol.util.BinaryEntry;

/**
 * Wrapper for {@link PublishingCacheStore} to work with {@link ControllableStore}.
 * 
 * @author amp
 */
public class ControllablePublishingCacheStore extends AbstractControllableBinaryEntryStore {

	private static final Logger LOGGER = LoggerFactory.getLogger(ControllablePublishingCacheStore.class);
	
	private final PublishingCacheStore publishingCacheStore; // Delegating instance
	
	public ControllablePublishingCacheStore(final String cacheName) {
		this.publishingCacheStore = new PublishingCacheStore(cacheName);
		LOGGER.info("Created instance of {}", this.getClass().getSimpleName());
	}
	
	@Override
	public void delete(BinaryEntry binaryEntry) {
		this.publishingCacheStore.erase(binaryEntry);
	}

	@Override
	public void deleteAll(Set setBinEntries) {
		this.publishingCacheStore.eraseAll(setBinEntries);
	}

	@Override
	public void persist(BinaryEntry binaryEntry) {
		this.publishingCacheStore.store(binaryEntry);
	}

	@Override
	public void persistAll(Set setBinEntries) {
		this.publishingCacheStore.storeAll(setBinEntries);
	}

	@Override
	public void retrieve(BinaryEntry binaryEntry) {
		this.publishingCacheStore.load(binaryEntry);
	}

	@Override
	public void retrieveAll(Set setBinEntries) {
		this.publishingCacheStore.loadAll(setBinEntries);
	}
}