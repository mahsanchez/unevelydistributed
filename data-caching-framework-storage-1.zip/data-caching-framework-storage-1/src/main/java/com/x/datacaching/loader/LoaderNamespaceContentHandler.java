package com.bbva.datacaching.loader;

import java.net.URI;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.environment.extensible.exception.CustomXMLConfigurationException;
import com.bbva.datacaching.loader.configuration.ObjectResolver;
import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.loader.service.BackEndService;
import com.bbva.datacaching.loader.service.CacheInfoService;
import com.bbva.datacaching.persistence.ParallelLoadable;
import com.oracle.coherence.environment.extensible.ConfigurationContext;
import com.oracle.coherence.environment.extensible.ConfigurationException;
import com.oracle.coherence.environment.extensible.ElementContentHandler;
import com.oracle.coherence.environment.extensible.NamespaceContentHandler;
import com.oracle.coherence.environment.extensible.QualifiedName;
import com.oracle.coherence.environment.extensible.namespaces.AbstractNamespaceContentHandler;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.Member;
import com.tangosol.net.NamedCache;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.processor.ConditionalPut;

/**
 * This class loads info from configuration in all nodes where it is specified as a 
 * {@link NamespaceContentHandler}. It executes once per process for each class configured
 * for loading. A single {@link Thread} runs this class on each node (one per JVM) for each
 * cache set for loading.
 * 
 * @author amp
 */
public final class LoaderNamespaceContentHandler extends AbstractNamespaceContentHandler {
	/**
	 * Static logger, one per node. This will be the same for all caches and will only
	 * log when a node starts from configuration (as opposed to the logger in {@link LoadingProcess},
	 * which is launched in a new thread under request and uses a cache-specific loader.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LoaderNamespaceContentHandler.class);
	
	/* This not part of the required configuration elements because it is an object to be instantiated,
	 * not a config param of the loading process.
	 */
	public static final String ACCESS_OBJECT_ELEMENT_NAME = "access-object";
	
	/**
	 * The namespace itself need not be defined, as long as it coincides with the
	 * one that has been specified in the respective xmlns attribute in the root
	 * tag for the intended namespace *by convention, xmlns:loader" is used.
	 */
	private static final String LOADER_ELEMENT_NAME = "process";
	private static final String CACHE_NAME_ATTRIBUTE = "cache-name";
	private static final String LOADING_DISCONTINUED_MESSAGE = "\nThe loading process will not "
			+ "continue for cache [{}]";
	
	private Member localMember = CacheFactory.getCluster().getLocalMember();
	
	public LoaderNamespaceContentHandler() {}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onStartScope(final ConfigurationContext context, final String prefix, final URI uri) {
		registerContentHandler(LOADER_ELEMENT_NAME, new ElementContentHandler() {
			public Object onElement(final ConfigurationContext context,
					final QualifiedName qualifiedName, final XmlElement xmlElement /* LOADER_ELEMENT_NAME */)
							throws ConfigurationException {

				LOGGER.info("Initiating {} from configuration", LoaderNamespaceContentHandler.this.getClass().getSimpleName());
				
				/* To determine which cache this process will be launched for (there may be
				 * multiple configured), gets 'cache-name' attribute from 'distributed-loader'
				 * element, or throws an exception if it is not valid  */
				final String cacheName = xmlElement.getAttribute(CACHE_NAME_ATTRIBUTE).toString();
				validateCacheName(cacheName);
				
				LOGGER.info("Retrieving loading configuration parameters for cache [{}]", cacheName);
				
				// Parses config file for configuration elements
				@SuppressWarnings("unchecked")
				final List<XmlElement> list = xmlElement.getElementList();
				
				// Organizes the information from configuration in a map
				final Map<String, String> configElementsMap = getConfigElementsMap(list);
				
				/* Validates the configuration elements in the map, will throw exception for a 
				 * given cache if its configuration does not validate, discontinuing the loading
				 * process for that cache.
				 */
				validateConfiguration(cacheName, configElementsMap);
				
				LOGGER.info("Validated loading configuration parameters for cache [{}]", cacheName);
				
				final LoadingConfigurationParameters configParams = getLoadingConfigurationParameters(
						cacheName, configElementsMap);
				
				// Registers cache loading info
				registerCacheInfo(cacheName, configParams);
//				new Thread(new SaveToLoadingInfoCache(configElementsMap.get(RequiredConfigurationElements.INFO_CACHE_NAME.getElementName()), cacheName, configParams)).start();
				// Stores the configParams in the info cache, in a different thread
//				executor.submit(new SaveToLoadingInfoCache(configElementsMap.get(RequiredConfigurationElements.INFO_CACHE_NAME), cacheName, configParams));
				
				// Gets and validates data access object from configuration
				final XmlElement accessObjectElement = xmlElement.getElement(ACCESS_OBJECT_ELEMENT_NAME);
				
				final ParallelLoadable<?, ?> accessObject = getValidatedAccessObject(accessObjectElement);
				
				LOGGER.info("Correctly instantiated access object {} for cache [{}]",
						accessObject.getClass().getName(), cacheName);
				
				// Registers access object specified in configuration with BackEndService
				registerDataAccessObjectForCache(cacheName, accessObject);
				
				LOGGER.info("Finished retrieving and storing loading information for cache [{}]", cacheName);
				
				return null; // No need to return anything
			}
		});
	}
	
	private Map<String, String> getConfigElementsMap(final Iterator<XmlElement> iterator) {
		final Map<String, String> configElementsMap = new HashMap<String, String>();
		while(iterator.hasNext()) {
			final XmlElement element = iterator.next();
			if (element != null)
				// Stores all element values as strings
				configElementsMap.put(element.getName(), (String) element.getValue());
		}
		return configElementsMap;
	}
	
	private Map<String, String> getConfigElementsMap(final List<XmlElement> list) {
		final Map<String, String> configElementsMap = new HashMap<String, String>();
		for (XmlElement element : list) {
			if (element != null)
				// Stores all element values as strings
				configElementsMap.put(element.getName(), (String) element.getValue());
		}
		return configElementsMap;
	}
	
	private void validateConfiguration(final String cacheName, final Map<String, String> configElementsMap) {
		// Stores required elements whose tag is missing from configuration
		final Set<String> missingConfigurationElements = new HashSet<String>();
		// Stores required elements whose configuration contains null or empty values
		final Set<String> emptyValues = new HashSet<String>();
		
		for (RequiredConfigurationElements mandatoryElement : RequiredConfigurationElements.values()) {
			// No need to check this parameter, it is validated elsewhere
			if (!configElementsMap.containsKey(mandatoryElement.getName())) {
				missingConfigurationElements.add(mandatoryElement.getName());
			} else {
				final String elementValue = configElementsMap.get(mandatoryElement.getName());
				if (elementValue == null || "".equals(elementValue))
					emptyValues.add(mandatoryElement.getName());
			}
			
			if (missingConfigurationElements.size() != 0) {
				LOGGER.error("Missing required loading configuration element(s) for cache [{}]"
						+ LOADING_DISCONTINUED_MESSAGE, new Object[]{cacheName, cacheName});
				for (final String elementName : missingConfigurationElements) {
					LOGGER.error("\t" + "missing required element <{}>", elementName);
				}
				throw new LoadingProcessException("Missing required loading configuration element(s) for cache " + cacheName);
			}
			
			if (emptyValues.size() != 0) {
				LOGGER.error("Required loading configuration element(s) with null or empty value(s) for cache [{}]"
						+ LOADING_DISCONTINUED_MESSAGE, new Object[] {cacheName, cacheName});
				for (final String elementName : emptyValues) {
					LOGGER.error("\t" + "required element <{}> cannot have a null or empty value",
							elementName);
				}
				throw new LoadingProcessException("Required loading configuration element(s) with null or empty value(s) for "
						+ "cache " + cacheName);
			}
		}
		
		/* At this point, all required configuration elements for a given cache have been specified; the
		 * numerical elements need validation */
		validateIntegerConfigurationElement(RequiredConfigurationElements.MINIMUM_NODES, cacheName,
				configElementsMap);
		validateIntegerConfigurationElement(RequiredConfigurationElements.BATCH_SIZE, cacheName,
				configElementsMap);
//		validateIntegerConfigurationElement(RequiredConfigurationElements.LOADING_TIMEOUT, cacheName,
//				configElementsMap);
	}
	
	private void validateCacheName(final String cacheName) {
		if (cacheName == null || "".equals(cacheName)) {
			LOGGER.error("'{}' attribute in <{}> element cannot be null or empty"
					+ LOADING_DISCONTINUED_MESSAGE, new Object[]{CACHE_NAME_ATTRIBUTE, LOADER_ELEMENT_NAME, cacheName});
			throw new LoadingProcessException("'" + CACHE_NAME_ATTRIBUTE + "' in <"
					+ LOADER_ELEMENT_NAME + "> cannot be null or empty");
		}
	}
	
	// Exception handling and re-throwing is done by the calls within this method
	private ParallelLoadable<?, ?> getValidatedAccessObject(final XmlElement accessObjectElement) {
		if (accessObjectElement == null) {
			LOGGER.error("The <access-object> element is mandatory");
			throw new CustomXMLConfigurationException("The <access-object> element is mandatory");
		}
		return (ParallelLoadable<?, ?>) new ObjectResolver().instantiateObject(accessObjectElement);
	}
 	
	private static final LoadingConfigurationParameters getLoadingConfigurationParameters(String cacheName,
			Map<String, String> configElementsMap) {
		/* Loading params for a given cache, the params have previously been verified */
		/* Only the elements that are necessary for loading from the info cache */
		final String invocationServiceName = 
				configElementsMap.get(RequiredConfigurationElements.INVOCATION_SERVICE_NAME.getName());
//		final String controlCacheName = 
//				configElementsMap.get(RequiredConfigurationElements.LOADING_CONTROL_CACHE_NAME.getName());
//		final String loadingBlockedFlagKey =
//				configElementsMap.get(RequiredConfigurationElements.LOADING_BLOCKED_FLAG_KEY.getElementName());
//		final String policyCacheName = 
//				configElementsMap.get(RequiredConfigurationElements.POLICY_CACHE_NAME.getElementName());
		final String policyServiceKey = 
				configElementsMap.get(RequiredConfigurationElements.POLICY_SERVICE_KEY.getName());
//		final String daoClass =
//				loadingProps.get(RequiredConfigurationElements.DAO_CLASS.getElementName());
//		final String queryFilePath = 
//				loadingProps.get(RequiredConfigurationElements.QUERY_FILE_PATH.getElementName());
		final String tableName =
				configElementsMap.get(RequiredConfigurationElements.TABLE_NAME.getName());
		final String keyColumnName = 
				configElementsMap.get(RequiredConfigurationElements.COLUMN_NAME.getName());
		final int minimumNodes = Integer.parseInt(
				configElementsMap.get(RequiredConfigurationElements.MINIMUM_NODES.getName()));
		final int batchSize = Integer.parseInt(
				configElementsMap.get(RequiredConfigurationElements.BATCH_SIZE.getName()));
//		final int loaderTimeout = Integer.parseInt(
//				configElementsMap.get(RequiredConfigurationElements.LOADING_TIMEOUT.getName()));
		
		// Returns data structure with loading configuration elements for this cache
		return new LoadingConfigurationParameters(invocationServiceName,
				cacheName,
//				controlCacheName,
				policyServiceKey,
				tableName,
				keyColumnName,
				minimumNodes,
				batchSize);
//				loaderTimeout);
	}
	
	// Registers cache loading info in CacheInfoService 
	private void registerCacheInfo(final String cacheName, final LoadingConfigurationParameters configParams) {
		CacheInfoService.putInCacheInfoMap(cacheName, configParams);
	}
	
	// Registers access object with BackEndService
	private void registerDataAccessObjectForCache(final String cacheName, final ParallelLoadable accessObject) { 
		BackEndService.putInDataAccessMap(cacheName, accessObject);
	}
	
	/**
	 * 
	 * @param configElementsMap
	 */
	private void launchLoadingProcess(final String cacheName, final Map<String, String> configElementsMap) {
		// Checks required configuration elements
		final String invocationServiceName = 
				configElementsMap.get(RequiredConfigurationElements.INVOCATION_SERVICE_NAME.getName());
//		final String infoCacheName = 
//				configElementsMap.get(RequiredConfigurationElements.INFO_CACHE_NAME.getName());
//		final String controlCacheName = 
//				configElementsMap.get(RequiredConfigurationElements.LOADING_CONTROL_CACHE_NAME.getName());
//		final String loadingBlockedFlagKey =
//				configElementsMap.get(RequiredConfigurationElements.LOADING_BLOCKED_FLAG_KEY.getName());
//		final String policyCacheName = 
//				configElementsMap.get(RequiredConfigurationElements.POLICY_CACHE_NAME.getName());
//		final String policyCacheKey = 
//				configElementsMap.get(RequiredConfigurationElements.POLICY_CACHE_KEY.getName());
//		final String daoClass =
//				configElementsMap.get(RequiredConfigurationElements.DAO_CLASS.getName());
//		final String queryFilePath = 
//				configElementsMap.get(RequiredConfigurationElements.QUERY_FILE_PATH.getName());
		final String tableName =
				configElementsMap.get(RequiredConfigurationElements.TABLE_NAME.getName());
		final String columnName = 
				configElementsMap.get(RequiredConfigurationElements.COLUMN_NAME.getName());
		final int minimumNodes = 
				validateIntegerConfigurationElement(RequiredConfigurationElements.MINIMUM_NODES, cacheName, configElementsMap);
		final int batchSize = 
				validateIntegerConfigurationElement(RequiredConfigurationElements.BATCH_SIZE, cacheName, configElementsMap);
//		final long observerTimeout =
//				validateIntegerConfigurationElement(RequiredConfigurationElements.LOADING_TIMEOUT, cacheName, configElementsMap);
		
		final ExecutorService executor = Executors.newSingleThreadExecutor();
		/* Launches loading process in a separate thread, accessible from a Future
		 * from outside code so it can be cancelled on the node running the
		 * LoadingProcess if necessary */
//		LoadingStarter.execute(jdbcPoolClass, daoClass, tableName, columnName, policyClass, 
//				objectCacheName, controlCacheName, quorumNodes);
//		loadingExecutingThread = executor.submit(new LoadingProcess(cacheName, controlCacheName,
//				jdbcPoolClass, daoClass, tableName, columnName, policyClass, minimumNodes));
//		loadingExecutingThread = executor.submit(new LoadingProcess(cacheName, controlCacheName,
//				invocationServiceName, loadingBlockedFlagKey,
////				daoClass,
////				queryFilePath,
//				tableName, columnName, minimumNodes, batchSize, observerTimeout,
//				policyCacheName, policyCacheKey));
		LOGGER.info("[{}] MemberId {}: submitted a runnable to execute the loading process on a "
				+ "separate thread", cacheName, this.localMember.getId());
	}
	
	private int validateIntegerConfigurationElement(final RequiredConfigurationElements integerElement,
			final String cacheName, final Map<String, String> configElementsMap) {
		int returnedElement = 0;
		try {
			returnedElement = Integer.parseInt(configElementsMap.get(integerElement.getName()));
			if (returnedElement < 0) {
				LOGGER.error("[{}] Value for element <{}> is not a positive integer"
						+ LOADING_DISCONTINUED_MESSAGE, new Object[]{cacheName, 
								integerElement.getName(), cacheName});
				throw new CustomXMLConfigurationException("Value for element "
						+ integerElement.getName() + " is not a positive integer");	
			}
		} catch (NumberFormatException e)  {
			LOGGER.error("[{}] Value for element <{}> must be a positive integer"
					+ LOADING_DISCONTINUED_MESSAGE, new Object[]{cacheName,
							integerElement.getName(), cacheName});
			throw new CustomXMLConfigurationException("Value for element "
					+ integerElement.getName() + " must be a positive integer", e);
		}
		return returnedElement;
	}
	
	// Runnable to put load information into loading information cache
	private static class SaveToLoadingInfoCache implements Runnable {
		
		private final String infoCacheName;
		private final String cacheName; // Cache name used as key of info cache
		private final LoadingConfigurationParameters configParams;
		
		public SaveToLoadingInfoCache(final String infoCacheName, final String cacheName, 
				final LoadingConfigurationParameters configParams) {
			this.infoCacheName = infoCacheName;
			this.configParams = configParams;
			this.cacheName = cacheName; /* Used as key in info cache */
		}
		
		@Override
		public void run() {
			System.out.println("#### Just before calling getCache for cache " + this.infoCacheName);
			try {
				/* This seems to be a problematic call when usind more than onde node for loading,
				 * there seems to be a problem related to accessing a cache when the config handler
				 * for the main cache has not yet finished execution (even though this is sent in
				 * a separate thread).
				 */
				final NamedCache infoCache = CacheFactory.getCache(this.infoCacheName);
				infoCache.invoke(this.cacheName /* Used as key in info cache */, 
						new ConditionalPut(AlwaysFilter.INSTANCE, this.configParams));
			} catch (Exception e) {
				LOGGER.error("Error while accessing info cache on startup", e);
			}
			LOGGER.info("Stored the loading configuration object for cache [{}] in the info cache",
					this.cacheName);
			System.out.println("#### Stored the loading configuration object for cache " + cacheName +
					" in the info cache");
		}
	}
	
//	private String validateElement(final String elementName, final String elementValue) {
//		if (elementValue == null || "".equals(elementValue)) {
//			LOGGER.error("MemberId {}: configuration element {} cannot be null or empty",
//					this.localMember, elementName);
//			throw new IllegalStateException("Configuration element " + elementName
//					+ " cannot be null or empty");
//		}
//		return elementValue;
//	}
}