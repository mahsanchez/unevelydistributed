package com.bbva.datacaching.persistence.store.management;

import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.management.Registry;

/**
 * MBean implementation.
 * Does not follow the abstract class naming convention due to JMX MBean naming restrictions.
 * 
 * @author amp
 *
 */
public abstract class ControllableStore implements ControllableStoreMBean {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ControllableStore.class);
	
	private final AtomicBoolean enabled = new AtomicBoolean(true); // Enabled by default
	private final AtomicBoolean registerFlag = new AtomicBoolean(false);
	
	private static final String JMX_TYPE = "type=" + ControllableStore.class.getSimpleName();
	private static final String FIELD_SEPARATOR = ",";
	
	// ###### JMX monitorable methods ######
	
	@Override
	public final boolean isEnabled() {
		// Registers as a JMX MBean if not registered before
		registerIfNotRegistered();
		return this.enabled.get();
	}
	
	@Override
	public final void setEnabled(final boolean enabled) {
		// Registers as a JMX MBean if not registered before
		registerIfNotRegistered();
		final String state = enabled ? "enabled" : "disabled";
		this.enabled.set(enabled);
		LOGGER.info("Cache store has been {} on this node", state);
	}
	
	/**
	 * Meant for subclasses to override should they wish to specify a custom JMX registry name
	 * (e.g. "MyCacheStore" would yields the JMX registry name "name=MyCacheStore").
	 * @return
	 */
	public String getJMXName() {
		return this.getClass().getSimpleName();
	}
	
	// ###### Helper methods ######
	
	/*
	 * Registers this class as a JMX MBean through the Coherence Registry framework, only once.
	 */
	private void registerIfNotRegistered() {
		if (registerFlag.compareAndSet(false, true)) {
			final Registry registry = CacheFactory.getCluster().getManagement();
			final StringBuilder nameToRegister = new StringBuilder();
			final String jmxType = JMX_TYPE;
			final String jmxName = "name=" + getJMXName(); // Allows subclasses to specify registry name
			final String fieldSeparator = FIELD_SEPARATOR;
			
			nameToRegister.append(jmxType);
			nameToRegister.append(fieldSeparator);
			nameToRegister.append(jmxName);
			nameToRegister.append(fieldSeparator);
			
			registry.register(registry.ensureGlobalName(nameToRegister.toString()), this);
			LOGGER.info("Registered instance of {} as an MBean", this.getClass().getSimpleName());
		}
	}
}