package com.bbva.datacaching.persistence.store.cachestore;

/**
 * 
 * @author amp
 */
public enum BinaryStoreConfigParams {
	CACHE_NAME("cacheName"),
	TABLE_NAME("tableName"),
	ID_COLUMN_NAME("idColumnName"),
	BINARY_COLUMN_NAME("binaryColumnName"),
	JDBC_BATCH_SIZE("jdbcBatchSize");
	
	private final String paramName;
	
	private BinaryStoreConfigParams(final String paramName) {
		this.paramName = paramName;
	}
	
	public String getParamName() {
		return this.paramName;
	}
}