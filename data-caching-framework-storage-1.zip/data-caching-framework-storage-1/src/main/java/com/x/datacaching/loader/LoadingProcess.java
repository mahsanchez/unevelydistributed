package com.bbva.datacaching.loader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.loader.invocable.CacheStoreControllerInvocable;
import com.bbva.datacaching.loader.invocable.LoadingProcessInvocable;
import com.bbva.datacaching.loader.invocable.PolicySetterInvocable;
import com.bbva.datacaching.loader.invocable.observer.DistributedExecutionObserver;
import com.bbva.datacaching.loader.service.BackEndService;
import com.bbva.datacaching.loader.util.Utilities;
import com.bbva.datacaching.persistence.BusinessObjectDAO;
import com.bbva.datacaching.policy.StrategyDelegatorActionPolicy.PolicyType;
import com.tangosol.net.ActionPolicy;
import com.tangosol.net.BackingMapContext;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;
import com.tangosol.net.NamedCache;
import com.tangosol.net.cache.ReadWriteBackingMap;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.NotFilter;
import com.tangosol.util.filter.PresentFilter;
import com.tangosol.util.processor.ConditionalPut;
import com.tangosol.util.processor.ConditionalRemove;

/**
 * Launched by {@link LoadingProcessInvocable} to run on a thread on a single node carrying
 * the service of the cache that is intended for loading.
 * 
 * Any {@link Exception} that the {@link #run()} may throw will signal the
 * {@link DistributedExecutionObserver} that the node executing this class has failed, to
 * return an appropriate error code to the script client.
 * 
 * @author amp
 */
public final class LoadingProcess implements Callable<Void> {
	private static final Logger LOGGER = LoggerFactory.getLogger(LoadingProcess.class);
	
	private static final String STORAGE_SERVER_ROLE_NAME = "CoherenceServer";
	private static final long WAIT_FOR_MEMBER_ITERATION_PAUSE_MILLIS = 2000;
	private static final double WRITE_BEHIND_TIME_SAFETY_FACTOR = 1.3; // 30% more
	
	// TODO - this should be loaded from file to allow customization.
	private static final String LIMITS_SQL =
	
			"SELECT MIN(refaccount), MAX(refaccount) " +
			"         FROM (SELECT CEIL(linea / div) proceso, refaccount " +
			"                FROM (SELECT ROWNUM linea, refaccount, CEIL(num / num_proc) div " +
			"                         FROM (SELECT DISTINCT COUNT(DISTINCT %2$s) OVER(PARTITION BY NULL) num, " +
			"                                               %2$s refaccount, %3$s num_proc " +
			"                                          FROM %1$s " +
			"                                      ORDER BY %2$s))) " +
			"     GROUP BY proceso";

	
	// Parameters passed by the constructor
	private final String invocationServiceName;
	private final String cacheName;
//	private final String controlCacheName;
	private final String policyServiceKey; // Should be the service name for each cache
	private final String tableName;
	private final String keyColumnName;
	private final int minimumNodes;
	private final int batchSize;
	/**
	 * Uses the same timeout value as {@link LoadingProcessInvocable} - the first code to run governs
	 * the timeout.
	 */
	private final long timeout;
	
	// NamedCache instances
	private NamedCache controlCache;
	private NamedCache mainCache;
	
	/** Map of loading members associated to their respective ids, which will be considered the
	 * effective one for loading. */
	private Map<Integer, Member> loadingMembers;

	public LoadingProcess(final String invocationServiceName, 
			final String cacheName,
//			final String controlCacheName, 
			final String policyServiceKey,
//			final String queryFilePath,
			final String tableName,
			final String keyColumnName,
			final int minimumNodes,
			final int batchSize,
			long timeout
			) {
		
		this.invocationServiceName = invocationServiceName;
		this.cacheName = cacheName;
//		this.controlCacheName = controlCacheName;
		this.policyServiceKey = policyServiceKey;
//		this.queryFilePath = queryFilePath;
		this.tableName = tableName;
		this.keyColumnName = keyColumnName;
		this.minimumNodes = minimumNodes;
		this.batchSize = batchSize;
		this.timeout = timeout;
	}

	@Override
	public Void call() {
		try {
			final long start = System.currentTimeMillis();
			
			// #### STEP 1 ##################################################################
			
			/* Checks if this is a server storage node, otherwise returns (and discontinues
			 * loading process). This would only be sent for execution on a storage node; we
			 * check again here. */
			
			final Member localMember = CacheFactory.getCluster().getLocalMember();
			if (!STORAGE_SERVER_ROLE_NAME.equals(localMember.getRoleName())) {
				LOGGER.info("This member {} is not a storage node. The loading process will stop "
						+ "(no entries have been loaded)", localMember.getId());
				return null; // Ends loading process on the node
			}
			
			// #### STEP 2 ###################################################################
	         		
			// TODO - Loading blocking/unblocking from the control cache is at the moment not
			// being used; this check is not being carried out
			/* Checks if the distributed loading process has already been started by another
			 * storage node (in case it's been launched in succession by more than one run of the
			 * launching script). This is done by checking the value of a flag in a control cache,
			 * set by an entry processor (and therefore guaranteeing concurrency). If loading has
			 * already been processed, returns and discontinues the starting of loading process on
			 * this node. */
			
//			this.controlCache = CacheFactory.getCache(this.controlCacheName);
			
			/* Concurrency isn't a major concern here, this is only a check for a flag
			 * in a control cache to determine if loading will continue from this node. If the
			 * flag has previously been set by another node, loading will not continue from this
			 * one. If loading should continue from a node but the flag from a previous run has
			 * not yet been removed, then the class that removes the flag may be run to delete
			 * the entry and then the distributed loader may be launched again */
//			final Boolean loadingBlocked = isLoadingBlocked();
//			if (loadingBlocked != null && Boolean.TRUE.equals(loadingBlocked)) {
//				LOGGER.info("The control flag '{}' in the control cache [{}] prevents the initialization "
//						+ "of the distributed loading process ofor cache [{}]. This may indicate that the "
//						+ "loading process may have already been started by another node, or that the process "
//						+ "has concluded and the cache is loaded with all the data.\n"
//						+ "The loading process will not continue for this cache [{}] (no entries have "
//						+ "been loaded)",
//						new Object[]{this.cacheName, this.controlCacheName, 
//								this.cacheName});
//				return; // Ends loading process on the node
//			}
			
			LOGGER.info("Starting the loading process for cache [{}]", this.cacheName);

			// #### STEP 3 ###################################################################
			  
			/* Sets a Loading ActionPolicy for this service, which will disable petitions to the cache
			 * from clients whilst the loading process is taking place in all nodes containing this
			 * cache's service (the ActionPolicy will be set back to its Regular value once the loading
			 * process successfully completes). It may also be explicitly toggled between the Loading
			 * and the Regular ActionPolicy by running a script. */
			allowCachePetitions(false);
			
			// #### STEP 4 ###################################################################
			
			/* Disables the Controllable CacheStore for this cache, on each storage node carrying this
			 * cache's service, so that the process does not attempt to persist objects loaded from the
			 * DB back to it whilst the loading process is in progress (the Controllable CacheStores
			 * will be enabled when the loading process ends). */
	        // The invocable is only sent for execution in nodes that have this service.
			allowCacheStorePersistence(false);
			
			// #### STEP 5 ###################################################################
			
			/* Waits for the minimum number of storage members in service to join the cluster
			 * before distributing the data among the nodes */
			
			// TODO - Is this call still necessary, since we're running the process on demand?
			// TODO - refactor this call, maybe stop process with log message instead of waiting
			waitForMinimumNumberOfStorageMembers();

			// #### STEP 6 ###################################################################
			
			/* Finds the current number of storage members for this cache's service - this will
			 * be the effective number used to divide the total data in ranges, if equal to or 
			 * greater than the minimum number determined by configuration. Note that the number
			 * of storage members may suffer changes during the execution of the loading process;
			 * the process will continue as long as the number of nodes is at least equal to the
			 * minimum configured. The effective number will only be used for task division
			 * purposes, because we need a reference number to perform the division. */
			
			this.loadingMembers = Utilities.getCurrentStorageMembersMap(this.cacheName);
			LOGGER.info("Number of storage nodes that will be used for loading in this cache: {}", 
					this.loadingMembers.size());
			
			// #### STEP 7 ###################################################################
			
			/* Generates loading tasks for each storage node. For each 'division' of data (the
			 * original number of storage nodes for this service), an Invocable will be created
			 * to load the respective range of ids from a node). Note that a node may get more
			 * than one task, or no task at all, if the number of storage nodes for the service
			 * changes during process execution in respect to what was originally designated. */
			this.mainCache = CacheFactory.getCache(this.cacheName);
//			LOGGER.info("Returns from CacheFactory.getCache");
			final Map<Integer, Set<NodeLoadTask>> memberTaskMap = getNodeLoadTasks();
			
			// #### STEP 8 ###################################################################
			
			/* Distributes and launches loading tasks among the designated nodes. These tasks
			 * will load data from the DB and store it in the cache. Note that CacheStores should
			 * implement AbstractControllableCacheStore so that storage back to the DB is not
			 * triggered when the elements are placed in the cache - CacheStores in each node
			 * will then be enabled when the loading process finishes. This call waits until
			 * nodes have been loaded or the configured timeout */
			
			launchDistributedTasks(memberTaskMap);
			
			// #### STEP 9 ###################################################################
			
			/* If write-behind has been configured, there may still be entries in the write-behind
			 * queue. Here we wait until the write-behind queue empties out before enabling the
			 * CacheStore again, to avoid that queued entries go back to the DB. */
			
			waitForWriteBehindQueue();
			
			// #### STEP 10 ###################################################################
			
			/* Enables the Controllable CacheStore for this cache on each node carrying the cache's
			 * service, thereby allowing subsequent cache operations to access the DB. */
			
			allowCacheStorePersistence(true);
			
			// #### STEP 11 ###################################################################
			
			/* Sets the Regular ActionPolicy for this service in each of the service's nodes, in
			 * order to allow cache petitions to this service. */
			
			allowCachePetitions(true);
			
			// #### STEP 12 ###################################################################
			
			// TODO - Process blocking/unblocking is at the moment not being used.
			/* Removes the flag from the control cache that determines that the loading process
			 * has already started from a node, so that if the loading process is restarted,
			 * further nodes will be enabled to carry out the loading */
//			unBlockLoading(cacheName);
			
			final long end = System.currentTimeMillis();
			
			LOGGER.info("The loading process has completed successfully for cache [{}]\n"
					+ "There are {} objects in the cache", new Object[]{this.cacheName, this.mainCache.size()});
			LOGGER.info("Total loading time for the complete process: {}ms", ((end - start)));
			
			return null;
		} catch (Exception e) {
			LOGGER.error("{} thrown while running the loading process for cache [{}] on the main loading node.\n"
					+ "The loading process did not complete and the cache may not have loaded all data", 
					new Object[]{e.getClass().getSimpleName(), this.cacheName, e});
			
			/* Enables CacheStores and cache petitions in all service nodes. Note that this is done on a
			 * best-effort basis (this is code that will run distributedly after an exception has been
			 * thrown in the process, so we're not sure of the current status of all service nodes.
			 * 
			 * To enable the CacheStores and/or cache petitions for a given cache, run their respective
			 * script class com.bbva.datacaching.loader.invocable package.
			 * 
			 */
			allowCacheStorePersistence(true);
			allowCachePetitions(true);
			
			/* This will be the unified exception that will be thrown in case any exception is thrown in the
			 * call() method. */
			throw new LoadingProcessException("Exception thrown while running the loading process for cache "
					+ this.cacheName + " on the main loading node", e);
		} 
	}
	
	private Boolean isLoadingBlocked() {
		// Returns null if the key is not in the cache, otherwise returns true
		// There's no logging in Coherence entry processors for us to log errors
		return (Boolean) this.controlCache.invoke(this.cacheName,
				new ConditionalPut(new NotFilter(PresentFilter.INSTANCE), new Boolean(true), true));
	}
	
	private void unBlockLoading(final String cacheName) {
		// There's no logging in Coherence entry processors for us to log errors
		this.controlCache.invoke(cacheName, new ConditionalRemove(AlwaysFilter.INSTANCE));
		LOGGER.info("Removed entry from control cache for cache [{}], loading is now unblocked");
	}

	/**
	 * Sends an {@link Invocable} for execution in all storage nodes to set a cache's {@link ActionPolicy}
	 * in the complete set (does not alter any other caches' {@link ActionPolicy}.
	 * 
	 * @param petitionsAllowed
	 * @param service
	 * @param members
	 */
	private void allowCachePetitions(final boolean petitionsAllowed) {
		final PolicyType policyType = petitionsAllowed ? PolicyType.REGULAR : PolicyType.LOADING;
		final Set<Member> serviceMembers = Utilities.getCurrentStorageMemberSetForService(this.cacheName);
		final InvocationService service = 
        		(InvocationService) CacheFactory.getService(this.invocationServiceName);
		// TODO - invocation service without retries, at least log and stop general process if unsuccessful
		service.execute(new PolicySetterInvocable(this.policyServiceKey, policyType), serviceMembers, null);
		
//		// EntryProcessor in the replicated cache
//		this.policyCache.invoke(this.cacheName, new EstablishPolicyProcessor(policy));
	}
	
	// PREVIOUS CODE FOR THIS METHOD
//	private void allowCachePetitions(final boolean petitionsAllowed) {
//		final String state = petitionsAllowed ? "enabled" : "disabled";
//		this.controlCache.invoke(this.petitionsAllowedFlagKey, 
//				new ConditionalPut(AlwaysFilter.INSTANCE, petitionsAllowed, false));
//		LOGGER.info("[{}] Cache petitions have been " + state + " for all nodes "
//				+ "from this point", this.cacheName, localMember.getId());
//	}
	
	private void waitForMinimumNumberOfStorageMembers() {
		List<Member> storageMembers = Utilities.getCurrentStorageMembersListForService(this.cacheName);
		try {
			while (storageMembers.size() < this.minimumNodes) {
				LOGGER.info("There are currently {} storage members carrying this cache's service" + "\n"
						+ "Waiting for minimum number of storage nodes for this cache to join the cluster...",
						new Object[]{storageMembers.size()});
				Thread.sleep(WAIT_FOR_MEMBER_ITERATION_PAUSE_MILLIS);
				storageMembers = Utilities.getCurrentStorageMembersListForService(this.cacheName);
			}
			LOGGER.info("Reached or surpassed minimum number of storage members carrying this cache's service"
					+ "({} current storage nodes)\n"
					+ "Loading will now proceed", new Object[]{storageMembers.size()});
		} catch (InterruptedException e) {
			LOGGER.error("{} thrown in the thread running the loading process for cache [{}] in the main loading node:\n {}",
					new Object[]{e.getClass().getSimpleName(), this.cacheName, e});
			throw new LoadingProcessException("Exception in the thread running the loading process for cache "
					+ this.cacheName + " in the main loading node");
		}
		return;
	}
	
	/**
	 * 
	 */
	private void initializeDAO() {
		// BusinessObjectDAOInstance is initialized dynamically from configuration
		BusinessObjectDAO daoInstance = null;
//		try {
//			daoInstance = (BusinessObjectDAO) Class.forName(this.daoClass).newInstance();
//		} catch (ClassNotFoundException e) {
//			LOGGER.error("[{}] {} thrown while loading class {}", new Object[]{this.cacheName, 
//					e.getClass().getName(), this.daoClass});
//			throw new IllegalStateException(CLASSLOADING_EXCEPTION_MESSAGE + this.daoClass);
//		} catch (InstantiationException e) {
//			LOGGER.error("[{}] {} thrown while loading class {}", new Object[]{this.cacheName, 
//					e.getClass().getName(), this.daoClass});
//			throw new IllegalStateException(CLASSLOADING_EXCEPTION_MESSAGE + this.daoClass);
//		} catch (IllegalAccessException e) {
//			LOGGER.error("[{}] {} thrown while loading class {}", new Object[]{this.cacheName, 
//					e.getClass().getName(), this.daoClass});
//			throw new IllegalStateException(CLASSLOADING_EXCEPTION_MESSAGE + this.daoClass);
//		}
//		LOGGER.info("[{}] Class {} has been dynamically loaded from configuration",
//				new Object[]{this.cacheName, this.daoClass});
		
//		// TODO - For the moment, this will be initialized directly and not from configuration
//		daoInstance = new BinaryBusinessObjectDAO(this.tableName, this.keyColumnName);
		
		// Allocates a DAOHandler instance
//		this.daoHandler = new DAOHandler(daoInstance, this.cacheName, this.tableName, this.keyColumnName, this.batchSize);
		LOGGER.info("[{}] The key class for this cache's table has been specified as being of type [{}]",
				new Object[]{this.cacheName, daoInstance.getKeyClass().getClass().getName()});
	}
	
	/** 
	 * Distributes tasks throughout the loading members by associating a member
	 * id with a {@link Set} of {@link NodeLoadingTasks}.
	 * 
	 * @return
	 */
	private Map<Integer, Set<NodeLoadTask>> getNodeLoadTasks() {
		// Map that associates member ids with a set of loading tasks for each member
		final Map<Integer, Set<NodeLoadTask>> memberTaskMap = 
				new HashMap<Integer, Set<NodeLoadTask>>();
		/* The effective number of loading members that will be used for task division has 
		 * already been set */
		if (this.loadingMembers.size() < this.minimumNodes) {
			LOGGER.error("Current number of nodes for cache [{}] is {}, less than the "
					+ "configured minimum number ({})\n" 
					+ "The loading process will stop from this point (no entries have been loaded)",
					new Object[]{this.cacheName, this.loadingMembers.size(), this.minimumNodes});
			throw new IllegalStateException("Current number of nodes (" + this.loadingMembers.size()
					+ ") is less than the configured minimum number (" + this.minimumNodes + ")\n"
					+ "The loading process will stop from this point (no entries have been loaded)");
		}
		
		final List<Member> memberList = new ArrayList<Member>(this.loadingMembers.values());
//		LOGGER.info("Before calling daoHandler.getLoadLimits()");
		// This method accesses the DB with the info provided by each project
//		final Set<NodeLoadLimits<Object>> limitsSet = this.daoHandler.getLoadLimits(
//				this.loadingMembers.size(), LIMITS_SQL);
		// Only called from the main loading node
		final Set<NodeLoadLimits<Object>> limitsSet = BackEndService.getLoadLimits(
				this.cacheName, this.tableName, this.keyColumnName, this.loadingMembers.size(), LIMITS_SQL);
//		LOGGER.info("After calling daoHandler.getLoadLimits()");
		int memberCounter = 0;
		for (final NodeLoadLimits<Object> limit : limitsSet) {
			// Controls memberCounter not to be out of bounds
			if (memberCounter >= memberList.size()) {
				// Goes back to the first one and loads new ranges to loaded members
				memberCounter = 0; 
			}
			
			final int currentMemberId = memberList.get(memberCounter).getId();

			// A member may be assigned multiple NodeLoadingTasks
			Set<NodeLoadTask> taskSet = 
					memberTaskMap.get(currentMemberId);
			if (taskSet == null) {
				taskSet = new HashSet<NodeLoadTask>();
			}
//			final NodeLoadTask task = new NodeLoadTask(this.daoHandler, limit);
			final NodeLoadTask task = new NodeLoadTask(this.cacheName, this.batchSize, limit);
			taskSet.add(task);
			/* Associates as member id with a Set of NodeLoadingTasks.
			 * There is a chance of out of bounds in loadingMembers.get() if one or
			 * more nodes leave. NodeLoadLimits parameterized with Object because it 
			 * may be a String or a Number (other types would at the moment constitute
			 * illegal usage */
			memberTaskMap.put(currentMemberId, taskSet);
			LOGGER.info("Member {} has been assigned the range: {}",
					new Object[]{currentMemberId, task.getLoadLimits().toString()});
			memberCounter++;
		}
		return memberTaskMap;
	}
	
	/**
	 * 
	 * @param memberTaskMap
	 */
	private void launchDistributedTasks(final Map<Integer, Set<NodeLoadTask>> memberTaskMap) {
		LOGGER.info("Member task map:\n{}", memberTaskMap);
//		/* Map associating a Member node (through its id) with the set of ranges that
//		 * it has been assigned to load, it will be passed to the InvocationObserver for
//		 * retrial purposes in case of node failure or node departure */
//		final Map<Integer, Set<NodeLoadLimits<Object>>> memberLimitsMap = 
//				new HashMap<Integer, Set<NodeLoadLimits<Object>>>();
//		for (int i = 0; i < taskList.size(); i++) {
//			final int memberId = taskList.get(i).getMember().getId();
//			Set<NodeLoadLimits<Object>> loadLimitsSet = memberLimitsMap.get(memberId);
//			if (loadLimitsSet == null) {
//				loadLimitsSet = new HashSet<NodeLoadLimits<Object>>();
//			}
//			loadLimitsSet.add(taskList.get(i).getLoadLimits());
//			memberLimitsMap.put(memberId, loadLimitsSet);
//		}
//		
//		// Creates observer for loading process
//		final LoadingProcessObserver loadObserver = 
//				new LoadingProcessObserver(memberLimitsMap, this.daoInstance);
		
		// Creates observer for loading process
		final LoadingTaskObserver loadObserver =
				new LoadingTaskObserver(memberTaskMap, this.minimumNodes, this.invocationServiceName,
						this.cacheName, this.cacheName);
		
		// Gets reference to the InvocationService
		final InvocationService invocationService = 
				(InvocationService) CacheFactory.getService(this.invocationServiceName);
		
		for (final Entry<Integer, Set<NodeLoadTask>> entry : memberTaskMap.entrySet()) {
			final Member currentMember = this.loadingMembers.get(entry.getKey());
			// This should never happen
//			if (currentMember == null) {
//				LOGGER.error("[{}] MemberId {}: illegal state - member {}'s reference is null",
//						new Object[]{this.cacheName, localMember.getId(), entry.getKey()});
//				throw new IllegalStateException("Member " + entry.getKey() + "'s reference\n"
//						+ "is null");
//			}
			// For each NodeLoadingTask assigned to this member
			for (final NodeLoadTask task : entry.getValue()) {
				// Launches the task on the node
				invocationService.execute(task, Collections.singleton(currentMember), loadObserver);
//				LOGGER.info("[{}] MemberId {}: launched task for range {} on node {}",
//						new Object[]{this.cacheName, localMember.getId(),
//						task.getLoadLimits().toString(), entry.getKey()});
				LOGGER.info("Launched task for range {} on node {}",
						new Object[]{task.getLoadLimits().toString(), entry.getKey()});
			}
		}
		
		LOGGER.info("Waiting on observer to signal loading completion for cache [{}]", this.cacheName);
		/* Sets the CountdownLatch in the Observer with a timeout for so it doesn't get stuck indefinitely */
		final boolean result = loadObserver.await(this.timeout, TimeUnit.MILLISECONDS);
		
		// If false, there's been a timeout
		if (!result) {
			LOGGER.error("Timeout reached before successfully executing the loading code in all nodes");
			throw new LoadingProcessException("Timeout reached before successfully executing the code in "
					+ "all nodes");
		}
		
//		// Launches tasks on each node
//		for (NodeLoadingTask task : taskList) {
//			System.out.println("### " + this.getClass().getSimpleName() + ": invoking range [" + task.getLoadLimits().getLowerLimit() + ", " + task.getLoadLimits().getUpperLimit() + "] on member " + task.getMember().getId() + ", observer: " + loadObserver);
//			InvocableLauncher.fireInvocable(task, task.getMember(), loadObserver);
//		}
		
	}
	
	private void waitForWriteBehindQueue() {
		final BackingMapContext context = this.mainCache.getCacheService().getBackingMapManager()
				.getContext().getBackingMapContext(this.cacheName);
		long writeBehindWaitTime = 0;
		if (context != null) {
			if (context.getBackingMap() instanceof ReadWriteBackingMap){
				/* Since storage to the DB is configured, this is an instance of
				 * ReadWriteBackingMap */
				writeBehindWaitTime = ((ReadWriteBackingMap) context.getBackingMap())
						.getWriteBehindMillis();
			} else {
//				LOGGER.info("[{}] MemberId {}: the backing map on this node is not an instance " 
//						+ "of {} - there will be no waiting for a write-behind queue",
//						new Object[]{this.cacheName, localMember.getId(), 
//								ReadWriteBackingMap.class.getName()});
				LOGGER.info("The backing map for cache [{}] on this node is not an instance of {} - there will be "
						+ "no waiting for a write-behind queue", new Object[]{this.cacheName, ReadWriteBackingMap.class.getName()});
			}
		} else {
			// TODO - some action if it's not been configured!
//			LOGGER.info("[{}] MemberId {}: could not access {} on this member - there will be no "
//					+ "waiting for a write-behind queue", this.cacheName, localMember.getId());
			LOGGER.warn("Could not access the backing map context on this member - there will be no waiting "
					+ "for a write-behind queue", this.cacheName);
		}
		
		// If write-behind time is configured, sleeps for this period plus the security factor
		if (writeBehindWaitTime > 0) {
			try {
				// Applies a safety factor
				long safeWriteBehindWaitTime = 
						(long) (writeBehindWaitTime * WRITE_BEHIND_TIME_SAFETY_FACTOR);
//				LOGGER.info("[{}] MemberId {}: waiting {} seconds for write-behind queue to "
//						+ "complete", new Object[]{this.cacheName, localMember.getId(),
//								(safeWriteBehindWaitTime / 1000)});
				LOGGER.info("Waiting {} seconds for write-behind queue of cache [{}] to "
						+ "complete", new Object[]{this.cacheName, (safeWriteBehindWaitTime / 1000)});
				
				// Waiting call
				Thread.sleep(safeWriteBehindWaitTime);
			} catch (InterruptedException e) {
//				LOGGER.error("[{}] MemberId {}: {} thrown", new Object[]{this.cacheName, localMember.getId(), 
//						e.getClass().getName()});
				LOGGER.error("{} thrown in thread executing the loading process for cache [{}]:\n {}", new Object[]{e.getClass().getSimpleName(),
						this.cacheName, e});
				throw new LoadingProcessException(e.getClass().getSimpleName()
						+ " thrown in thread executing the loading process for cache " + this.cacheName, e);
			}
		} else {
			LOGGER.info("No write-behind wait time has been configured for cache {}, so the process will "
					+ "enable the CacheStore for this cache without waiting for the write-behind buffer to clear",
					this.cacheName);
		}
	}
	
	/*
	 * The same CacheStore needs to be configured in all member instances that carry the respective
	 * cache, as an invocation service will be sent to shut it down on 
	 * TODO - no mechanism of retrial should this invocation service fail
	 */
	private void allowCacheStorePersistence(final boolean persistenceAllowed) {
		final String action = persistenceAllowed ? "enable" : "disable";
		// Retrieves a reference to storage nodes that carry this cache's service.
		final Set<Member> setMembers = Utilities.getCurrentStorageMemberSetForService(this.cacheName);
		// TODO - invocation service without retries, at least log and stop general process if unsuccessful
        final InvocationService service = 
        		(InvocationService) CacheFactory.getService(this.invocationServiceName);
        // The invocable is only sent for execution in nodes that have this service.
        service.execute(new CacheStoreControllerInvocable(this.cacheName, persistenceAllowed),
        		setMembers, null);
        LOGGER.info("Sent an invocation service to {} the controllable cache store for cache [{}] "
        		+ "in all nodes that carry this cache's service", action, this.cacheName);
	}
	
	/**
	 * At the moment, only instances of {@link String} and {@link Number} (as well as primitive
	 * numeric types) are allowed as keys. 
	 * 
	 * @param key
	 * @return
	 */
	private static Object verifyAcceptedKeyType(Object key) {
		if (!(key instanceof String) || !(key instanceof Number)) {
//			LOGGER.error("MemberId {}: illegal key type\n"
//					+ "Primary keys may only be Strings and/or numeric types",
//					localMember.getId());
			LOGGER.error("MemberId {}: illegal key type\n"
					+ "Primary keys may only be Strings and/or numeric types");
			throw new UnsupportedOperationException("Primary keys may only be Strings and/or "
					+ "numeric types");
		}
		return key;
	}
}