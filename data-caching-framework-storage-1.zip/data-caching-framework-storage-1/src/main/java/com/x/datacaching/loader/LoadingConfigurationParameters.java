package com.bbva.datacaching.loader;

import java.io.Serializable;

/**
 * Holder bean class for loading configuration parameters.
 *  
 * @author amp
 */
public class LoadingConfigurationParameters implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// Parameters passed by the constructor
	private String invocationServiceName;
	private String cacheName;
//	private String controlCacheName;
//	private String loadingBlockedFlagKey;
//	private String policyCacheName;
	private String policyServiceKey;
	// private String daoClass;
	// private String queryFilePath;
	private String tableName;
	private String keyColumnName;
	private int minimumNodes;
	private int batchSize;
//	private long loaderTimeout;

	public LoadingConfigurationParameters() {}
	
	// ###### Getters / setters ######

	public LoadingConfigurationParameters(String invocationServiceName,
			String cacheName,
//			String controlCacheName,
			String policyServiceKey,
			String tableName,
			String keyColumnName,
			int minimumNodes,
			int batchSize) {
//			long loaderTimeout) {
		this.invocationServiceName = invocationServiceName;
		this.cacheName = cacheName;
//		this.controlCacheName = controlCacheName;
		this.policyServiceKey = policyServiceKey;
		this.tableName = tableName;
		this.keyColumnName = keyColumnName;
		this.minimumNodes = minimumNodes;
		this.batchSize = batchSize;
//		this.loaderTimeout = loaderTimeout;
	}

	public String getInvocationServiceName() {
		return invocationServiceName;
	}
	
	public void setInvocationServiceName(final String invocationServiceName) {
		this.invocationServiceName = invocationServiceName;
	}
	
	public String getCacheName() {
		return cacheName;
	}

	public void setCacheName(final String cacheName) {
		this.cacheName = cacheName;
	}

//	public String getControlCacheName() {
//		return controlCacheName;
//	}
//
//	public void setControlCacheName(final String controlCacheName) {
//		this.controlCacheName = controlCacheName;
//	}


//	public String getLoadingBlockedFlagKey() {
//		return loadingBlockedFlagKey;
//	}
//
//	public void setLoadingBlockedFlagKey(final String loadingBlockedFlagKey) {
//		this.loadingBlockedFlagKey = loadingBlockedFlagKey;
//	}

//	public String getPolicyCacheName() {
//		return policyCacheName;
//	}
//
//	public void setPolicyCacheName(final String policyCacheName) {
//		this.policyCacheName = policyCacheName;
//	}
//
	public String getPolicyServiceKey() {
		return policyServiceKey;
	}

	public void setPolicyServiceKey(final String policyServiceKey) {
		this.policyServiceKey = policyServiceKey;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(final String tableName) {
		this.tableName = tableName;
	}

	public String getKeyColumnName() {
		return keyColumnName;
	}

	public void setKeyColumnName(final String keyColumnName) {
		this.keyColumnName = keyColumnName;
	}

	public int getMinimumNodes() {
		return minimumNodes;
	}

	public void setMinimumNodes(final int minimumNodes) {
		this.minimumNodes = minimumNodes;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(final int batchSize) {
		this.batchSize = batchSize;
	}


//	public long getLoaderTimeout() {
//		return loaderTimeout;
//	}
//
//	public void setloaderTimeout(final long loaderTimeout) {
//		this.loaderTimeout = loaderTimeout;
//	}

	// TODO - at the end when all parameters are known
	// ###### Object methods ######
	@Override
	public String toString() {
		return "LoadingConfigurationParameters [invocationServiceName="
				+ invocationServiceName + ", cacheName=" + cacheName
				+ ", policyServiceKey=" + policyServiceKey + ", tableName="
				+ tableName + ", keyColumnName=" + keyColumnName
				+ ", minimumNodes=" + minimumNodes + ", batchSize=" + batchSize
				+ "]";
	}
}