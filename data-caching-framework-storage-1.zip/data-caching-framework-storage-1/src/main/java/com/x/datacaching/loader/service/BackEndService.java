package com.bbva.datacaching.loader.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.NodeLoadLimits;
import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.parallel.processor.BinaryPutAll;
import com.bbva.datacaching.persistence.BusinessObjectDAO;
import com.bbva.datacaching.persistence.ParallelLoadable;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.processor.ConditionalPutAll;

/**
 * Service class, one per jvm
 * 
 * @author amp
 */
public class BackEndService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BackEndService.class);
	
	private static final ConcurrentMap<String, ParallelLoadable> DATA_ACCESS_MAP = 
			new ConcurrentHashMap<String, ParallelLoadable>();
	
	private static final String SQL_BETWEEN_CONDITION = "BETWEEN ? AND ?";
	
	public static final Class<?>[] ALLOWED_KEY_CLASSES = new Class<?>[]{String.class, Integer.class,
		Long.class, BigInteger.class, int.class, long.class};
	private static final int LOWER_LIMIT_QUERY_INDEX = 1;
	private static final int UPPER_LIMIT_QUERY_INDEX = 2;
	private static final int DEFAULT_BATCH_SIZE = 1000;
	
	// ###### Service methods ######
	
	/**
	 * Service method, will be called by Invocable in each of a cache's nodes
	 * @param cacheName
	 * @param accessObject
	 */
	public static void putInDataAccessMap(final String cacheName, final ParallelLoadable<?, ?> accessObject) {
		if (accessObject == null) {
			handleNullAccessObject(cacheName);
		}
		// Runs validations, throws exceptions if something does not conform
		validateKeyClass(cacheName, accessObject.getKeyClass());
//		validateQuery(cacheName, dao.selectObjectsRangeQuery());
		DATA_ACCESS_MAP.put(cacheName, accessObject);
		LOGGER.info("Registered {} for cache [{}]", ParallelLoadable.class.getSimpleName(), cacheName);
	}
	
	/**
	 * Service method, called only from main loading node to get the DB range for each node.
	 * The limits are specified in the column's representation type.
	 * @param numberOfLoadDivisions
	 * @param limitsSQL
	 * @return
	 */
	public static Set<NodeLoadLimits<Object>> getLoadLimits(final String cacheName, final String tableName,
			final String keyColumnName, final int numberOfLoadDivisions, final String limitsSQL) {
		// Sets parameters in string
		// TODO - Not loading limits SQL from file for the moment
		//				final String limitsSQL = String.format(getLimitsSQLFromFile(queryFilePath), 
		//						this.tableName, this.keyColumnName, numberOfLoadDivisions);
		ParallelLoadable<?, ?> accessObject = null;
		Connection conn = null;
		/* PreparedStatement and ResultSet are acquired from this class, from the DAO's connection, and
		 * are therefore closed in this class as well. */
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		accessObject = DATA_ACCESS_MAP.get(cacheName);
		if (accessObject == null) {
			handleNullAccessObject(cacheName);
		}
		
		try {
			
			conn = accessObject.getConnection(); // Only call to outside class in this method

			/* It's OK to set the parameters in a string because the PreparedStatement will only
			 * run once per cache service node for each a loading process so there's no need to compile
			 * the statement.
			 */
			final String findLimitsSQL = 
					String.format(limitsSQL, tableName, keyColumnName, numberOfLoadDivisions);
			LOGGER.info("Query for establishing loading ranges for each node:\n\n\n\n {} \n\n\n\n", findLimitsSQL);
			preparedStatement = conn.prepareStatement(findLimitsSQL);
			//					preparedStatement.setString(1, this.tableName); // Table name
			//					preparedStatement.setString(2, this.keyColumnName); // Key column name
			//					preparedStatement.setInt(3, numberOfLoadDivisions); // Number of nodes
			resultSet = preparedStatement.executeQuery(); // Only one query execution, could there be RS batching
			LOGGER.info("Sent query to the database to find node loading ranges for cache [{}]", cacheName);
			return getCorrectTypeFromResultSet(resultSet, accessObject);
		} catch (SQLException e) {
			LOGGER.error("{} exception thrown when determining loading ranges:\n {}", e.getClass().getSimpleName(), e);
			throw new LoadingProcessException("Exception thrown when determining loading ranges", e);
		} finally {
			try {
				conn.commit();
			} catch (Exception e) {
				LOGGER.error("Exception thrown when commiting the connection for the loading ranges query", e);
				throw new LoadingProcessException(
						"Exception thrown when commiting the connection for the loading ranges query", e); 
			}
			cleanup(conn, preparedStatement, resultSet, accessObject);
		}
	}
	
	/**
	 * Service method, called by Invocable on all jvm nodes of a given cache.
	 * @param limits
	 */
	// Only for queries, does not write to DB, so JDBC batch is not justifiable here, any query may yield a large result set
	public static void loadToCache(final String cacheName, final int batchSize, final NodeLoadLimits<?> limits) {
		final ParallelLoadable<?, ?> accessObject = DATA_ACCESS_MAP.get(cacheName);
		if (accessObject == null) {
			handleNullAccessObject(cacheName);
		}
		
		accessObject.load(cacheName, batchSize, limits);
		
//		final NamedCache cache = CacheFactory.getCache(cacheName);
//		// Validates batch size
//		LOGGER.info("Batch size for storing objects in the cache [{}]: {}",
//				new Object[]{cacheName, batchSize});
//		// Batch map must support any type, which is only known at runtime
//		final Map<Object, Object> batchMap = new HashMap<Object, Object>();
//		
//		final BusinessObjectDAO dao = DATA_ACCESS_MAP.get(cacheName);
//		if (dao == null) {
//			handleNullAccessObject(cacheName);
//		}
//		
//		final String loadObjectsQuery = dao.selectObjectsRangeQuery();
//		Connection conn = null;
//		PreparedStatement preparedStatement = null;
//		ResultSet resultSet = null;
//		int batchCount = 1;
//
//		try {
//			conn = dao.getConnection();
//			preparedStatement = conn.prepareStatement(loadObjectsQuery);
//			//        	/* Default JDBC mapping from Java Object to SQL type */
//			//        	statement.setObject(1, lowerLimit);
//			//        	statement.setObject(2, upperLimit);
//			setStatementWithCorrectType(preparedStatement, dao, limits);
//			resultSet = preparedStatement.executeQuery();
//			
//			// This is the second check on the key class type, this time on what's retrieved from the result set
//			boolean hasKeyBeenValidated = false;
//			while (resultSet.next()) {
//				final Object businessObjectKey = dao.loadKeyFromResultSet(resultSet);
//				// Validates key class, to optimize it will only be validated once per task
//				if (!hasKeyBeenValidated) {
//					validateKeyClass(cacheName, businessObjectKey.getClass());
//					hasKeyBeenValidated = true;
//				}
//				final Object businessObject = dao.loadBusinessObjectFromResultSet(resultSet);
//				// Puts object in batch
//				batchMap.put(businessObjectKey, businessObject);
//				if (batchCount % batchSize == 0) {
//					// Saves all items in batch to in-memory cache
////					saveAll(cache, batchMap);
//					saveAll(cache, batchMap, cacheName);
//					// Clears map for next batch
//					batchMap.clear();
//				}
//				batchCount++;
//			}
//			// Stores any remaining elements
//			if (!batchMap.isEmpty()) {
////				saveAll(cache, batchMap);
//				saveAll(cache, batchMap, cacheName);
//				batchMap.clear();
//			}
//			
//			conn.commit();
//		} catch (SQLException e) {
//			LOGGER.error("Exception thrown when loading range to cache", e);
//			throw new LoadingProcessException(
//					"Exception thrown when when loading range to cache", e); 
//		} finally {
//			cleanup(conn, preparedStatement, resultSet, dao);
//		}
	}
	
	// ######
	
	private static void saveAll(NamedCache cache, Map<?, ?> batchMap) {
		// Stores only elements that are not already cached
		cache.invokeAll(batchMap.keySet(), new ConditionalPutAll(AlwaysFilter.INSTANCE, batchMap));
		// TODO - update this to work for models other than String-BLOB
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static void saveAll(final NamedCache cache, Map<?, ?> batchMap, final String cacheName) {
		// Stores only elements that are not already cached
//		cache.invokeAll(batchMap.keySet(), new ConditionalPutAll(AlwaysFilter.INSTANCE, batchMap));
		// TODO - update this to work for models other than String-BLOB
//		cache.invokeAll(batchMap.keySet(), new BinaryConditionalPutAll(batchMap, AlwaysFilter.INSTANCE, cacheName));
		// No logging in this entry processor not to lose performance
		cache.invokeAll(batchMap.keySet(), new BinaryPutAll(batchMap));
	}
	
	// ###### Typed ResultSet methods ######

	private static Set<NodeLoadLimits<Object>> getCorrectTypeFromResultSet(final ResultSet resultSet,
			final ParallelLoadable<?, ?> accessObject) throws SQLException {
		if (String.class.equals(accessObject.getKeyClass())) {
			return getStringLimits(resultSet);
		} else if (Integer.class.equals(accessObject.getKeyClass()) 
				|| int.class.equals(accessObject.getKeyClass())) {
			return getIntLimits(resultSet);
		} else if (Long.class.equals(accessObject.getKeyClass()) 
				|| long.class.equals(accessObject.getKeyClass())) {
			return getLongLimits(resultSet);
		} else if (BigInteger.class.equals(accessObject.getKeyClass())) {
			return getBigIntegerLimits(resultSet);
		} else {
			LOGGER.error("Invalid key class specified in {}", accessObject.getClass().getSimpleName());
			throw new LoadingProcessException("Invalid key class specified in " + accessObject.getClass().getSimpleName());
		}
	}

	private static Set<NodeLoadLimits<Object>> getStringLimits(final ResultSet resultSet) throws SQLException {
		final Set<NodeLoadLimits<Object>> limitsSet = new HashSet<NodeLoadLimits<Object>>();
		while (resultSet.next()) {
			final String lowerLimit = resultSet.getString(LOWER_LIMIT_QUERY_INDEX);
			final String upperLimit = resultSet.getString(UPPER_LIMIT_QUERY_INDEX);
			limitsSet.add(new NodeLoadLimits<Object>(lowerLimit, upperLimit));
		}
		return limitsSet; 
	}

	private static Set<NodeLoadLimits<Object>> getIntLimits(final ResultSet resultSet) throws SQLException {
		final Set<NodeLoadLimits<Object>> limitsSet = new HashSet<NodeLoadLimits<Object>>();
		while (resultSet.next()) {
			final int lowerLimit = resultSet.getInt(LOWER_LIMIT_QUERY_INDEX);
			final int upperLimit = resultSet.getInt(UPPER_LIMIT_QUERY_INDEX);
			limitsSet.add(new NodeLoadLimits<Object>(lowerLimit, upperLimit));
		}
		return limitsSet; 
	}

	private static Set<NodeLoadLimits<Object>> getLongLimits(final ResultSet resultSet) throws SQLException {
		final Set<NodeLoadLimits<Object>> limitsSet = new HashSet<NodeLoadLimits<Object>>();
		while (resultSet.next()) {
			final long lowerLimit = resultSet.getLong(LOWER_LIMIT_QUERY_INDEX);
			final long upperLimit = resultSet.getLong(UPPER_LIMIT_QUERY_INDEX);
			limitsSet.add(new NodeLoadLimits<Object>(lowerLimit, upperLimit));
		}
		return limitsSet;
	}

	private static Set<NodeLoadLimits<Object>> getBigIntegerLimits(final ResultSet resultSet) throws SQLException {
		final Set<NodeLoadLimits<Object>> limitsSet = new HashSet<NodeLoadLimits<Object>>();
		while (resultSet.next()) {
			final BigDecimal lowerLimit = resultSet.getBigDecimal(LOWER_LIMIT_QUERY_INDEX);
			lowerLimit.setScale(0);
			final BigDecimal upperLimit = resultSet.getBigDecimal(UPPER_LIMIT_QUERY_INDEX);
			upperLimit.setScale(0);
			limitsSet.add(new NodeLoadLimits<Object>(lowerLimit, upperLimit));
		}
		return limitsSet;
	}
	
	// ###### Typed PreparedStatement methods ######

	private static void setStatementWithCorrectType(final PreparedStatement ps, final ParallelLoadable<?, ?> loadable,
			final NodeLoadLimits<?> limits) throws SQLException {
		if (String.class.equals(loadable.getKeyClass())) {
			setString(ps, limits);
		} else if (Integer.class.equals(loadable.getKeyClass()) 
				|| int.class.equals(loadable.getKeyClass())) {
			setInt(ps, limits);
		} else if (Long.class.equals(loadable.getKeyClass()) 
				|| long.class.equals(loadable.getKeyClass())) {
			setLong(ps, limits);
		} else if (BigInteger.class.equals(loadable.getKeyClass())) {
			setBigInteger(ps, limits);
		} else {
			LOGGER.error("Shouldn't get here");
		}
	}

	private static void setString(final PreparedStatement ps, final NodeLoadLimits<?> limits)
			throws SQLException {
		ps.setString(LOWER_LIMIT_QUERY_INDEX, (String) limits.getLowerLimit());
		ps.setString(UPPER_LIMIT_QUERY_INDEX, (String) limits.getUpperLimit());
	}

	private static void setInt(final PreparedStatement ps, final NodeLoadLimits<?> limits)
			throws SQLException {
		ps.setInt(LOWER_LIMIT_QUERY_INDEX, (Integer) limits.getLowerLimit());
		ps.setInt(UPPER_LIMIT_QUERY_INDEX, (Integer) limits.getUpperLimit());
	}

	private static void setLong(final PreparedStatement ps, final NodeLoadLimits<?> limits)
			throws SQLException {
		ps.setLong(LOWER_LIMIT_QUERY_INDEX, (Long) limits.getLowerLimit());
		ps.setLong(UPPER_LIMIT_QUERY_INDEX, (Long) limits.getUpperLimit());
	}

	private static void setBigInteger(final PreparedStatement ps, final NodeLoadLimits<?> limits)
			throws SQLException {
		ps.setBigDecimal(LOWER_LIMIT_QUERY_INDEX,
				new BigDecimal((BigInteger) limits.getLowerLimit(), 0));
		ps.setBigDecimal(LOWER_LIMIT_QUERY_INDEX,
				new BigDecimal((BigInteger) limits.getUpperLimit(), 0));
	}
	
	// ###### Helper methods ######

	private static void cleanup(final Connection conn, final Statement statement, final ResultSet resultSet,
			final ParallelLoadable<?, ?> accessObject) {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (SQLException e) {
				LOGGER.error("{} thrown when closing a {}",
						new Object[]{e.getClass().getSimpleName(), resultSet.getClass().getName()});
				throw new LoadingProcessException("Exception thrown when closing result set", e);
			}
		}
		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException e) {
				LOGGER.error("{} thrown when closing a {}",
						new Object[]{e.getClass().getSimpleName(), statement.getClass().getName()});
				throw new LoadingProcessException("Exception thrown when closing statement", e);
			}
		}
		if (conn != null) {
//			try {
				// Let the subclass decide how to close connections, they provide the connection pool.
			accessObject.closeConnection(conn);
//			} catch (SQLException e) {
//				LOGGER.error("[{}] MemberId {}: {} thrown when returning a {} to the pool",
//						new Object[]{this.cacheName, e.getClass().getSimpleName(), conn.getClass().getName()});
//				throw new IllegalStateException(EXCEPTION_MESSAGE + " when closing connection", e);
//			}
		}
	}
	
	private static void handleNullAccessObject(final String cacheName) {
		LOGGER.error("{} cannot be null for cache [{}]", ParallelLoadable.class.getSimpleName(),
				cacheName);
		throw new LoadingProcessException(ParallelLoadable.class.getSimpleName() + " cannot be null "
				+ "for cache " + cacheName);
	}
	
	public static void validateKeyClass(final String cacheName, final Class<?> keyClass) {
		for (Class<?> allowedClass : ALLOWED_KEY_CLASSES) {
			if (allowedClass != null && allowedClass.equals(keyClass)) {
				return; // Passed keyClass is allowed
			}
		}
		// The key class is not allowed if it's not in the accepted types
		LOGGER.error("The passed key class ({}) for cache [{}] is not allowed", 
				new Object[]{keyClass.getName(), cacheName});
		throw new IllegalArgumentException("The passed key class (" + keyClass.getName()
				+ " for cache " + cacheName + " is not allowed");
	}
	
	/* Throws Exceptions if loading statement is not in accordance with what this needs */
	public static void validateQuery(final String cacheName, final String loadObjectsQuery,
			final SQLCondition condition) {
		if (loadObjectsQuery == null || "".equals(loadObjectsQuery)) {
			LOGGER.error("The query to load objects from the database for cache [{}] cannot be null "
					+ "or empty", cacheName);
			throw new LoadingProcessException("The query to load objects from the database for cache "
					+ cacheName + " cannot be null or empty");
		} else if (loadObjectsQuery.indexOf(condition.getName()) < 0) {
			LOGGER.error("The query to load objects from the database for cache [{}] must contain a "
					+ "parameterized 'BETWEEN' clause, as this must be range query.\n"
					+ "The give query is: [{}]", cacheName, loadObjectsQuery);
			throw new LoadingProcessException("The query to load objects from the database for cache "
					+ cacheName + " must contain a parameterized SQL 'BETWEEN' clause, as this must be "
					+ "range query");
		}
	}
	
	/**
	 * Represents mandatory conditions that must be present in the query language statement for each case.
	 * @author amp
	 *
	 */
	public enum SQLCondition {
		JDBC("BETWEEN ? AND ?"),
		JPA("BETWEEN :lowerLimit AND :upperLimit");
		
		private final String name;
		
		private SQLCondition(final String name) {
			this.name = name;
		}
		
		public String getName() {
			return this.name;
		}
	}
}