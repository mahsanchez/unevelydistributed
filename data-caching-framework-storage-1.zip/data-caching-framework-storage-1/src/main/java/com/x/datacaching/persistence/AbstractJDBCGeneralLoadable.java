package com.bbva.datacaching.persistence;

import java.util.Map;

import com.tangosol.net.NamedCache;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.processor.ConditionalPutAll;

/**
 * Implements the {@link #saveAll(NamedCache, Map)} method for a generic data model
 * (not the String-BLOB data model).
 * 
 * @author amp
 *
 */
public abstract class AbstractJDBCGeneralLoadable<K, V> extends AbstractJDBCLoadable<K, V> {
	
	@Override
	public final void saveAll(final NamedCache cache, Map<K, V> batchMap) {
		cache.invokeAll(batchMap.keySet(), new ConditionalPutAll(AlwaysFilter.INSTANCE, batchMap));
	}
}