package com.bbva.datacaching.persistence.store.management;

/**
 * Interface for AbstractControllableCacheStore and AbstractControllableBinaryEntryStore.
 * 
 * This interface follows the MBean nomenclature so it may be monitored by JMX.
 * @author amp
 *
 */
public interface ControllableStoreMBean {
	
	/** Allows/disallows loading to store */
	void setEnabled(boolean enabled);
	
	/** Checks the status of the store */
	boolean isEnabled();
}