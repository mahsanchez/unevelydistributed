package com.bbva.datacaching.persistence;

import java.util.Map;

import com.bbva.datacaching.loader.processor.TempBinaryPutAll;
import com.tangosol.net.NamedCache;

/**
 * Implements the {@link #saveAll(NamedCache, Map)} method for the String-BLOB data model.
 * 
 * For 'symmetry' with the general class ({@link AbstractJDBCGeneralLoadable}), we could
 * have placed the {@link #saveAll(NamedCache, Map)} method in the concrete implementation
 * an not have this class.
 * 
 * @author amp
 *
 */
public abstract class AbstractJDBCBinaryLoadable<K, V> extends AbstractJDBCLoadable<K, V> {
	
	@Override
	@SuppressWarnings({"unchecked", "rawtypes"})
	public final void saveAll(final NamedCache cache, Map<K, V> batchMap) {
		cache.invokeAll(batchMap.keySet(), new TempBinaryPutAll(batchMap));
	}
}