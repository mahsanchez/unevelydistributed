package com.bbva.datacaching.loader.connection;

import java.sql.Connection;
import java.sql.SQLException;


/**
 * 
 * @author AGR
 *
 */
public interface IConnectionPool {
	
	/**
	 * 
	 * @return
	 */
	Connection getConnection() throws SQLException;

}
