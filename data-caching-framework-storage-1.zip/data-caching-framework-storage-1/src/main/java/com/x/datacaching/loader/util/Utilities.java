package com.bbva.datacaching.loader.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.CacheService;
import com.tangosol.net.Member;

public class Utilities {
	private static final String STORAGE_SERVER_ROLE_NAME = "CoherenceServer";
	
//	public static boolean checkNumberOfStorageNodes(int minimumNumberOfNodes) {
//		return getCurrentStorageMembersList(null).size() >= (minimumNumberOfNodes); 
//	}
	
	public static List<Member> getCurrentStorageMembersListForService(final String cacheName) {
		final List<Member> memberList = new ArrayList<Member>();
		for (Member member : getCurrentMemberSetForService(cacheName)) {
			if (STORAGE_SERVER_ROLE_NAME.equalsIgnoreCase(member.getRoleName())) {
				memberList.add(member);
			}
		}
		return memberList;
	}
	
	/**
	 * {@Map} with the current server storage nodes, keyed by their id.
	 * @param cacheName TODO
	 * 
	 * @return
	 */
	public static Map<Integer, Member> getCurrentStorageMembersMap(final String cacheName) {
		// LinkedHashMap so output shows nodes in order
		final Map<Integer, Member> memberMap = new LinkedHashMap<Integer, Member>();
		for (Member member : getCurrentMemberSetForService(cacheName)) {
			if (STORAGE_SERVER_ROLE_NAME.equalsIgnoreCase(member.getRoleName())) {
				memberMap.put(member.getId(), member);
			}
		}
		return memberMap;
	}
	
	/**
	 * 
	 * @param cacheName
	 * @return
	 */
	public static Set<Member> getCurrentStorageMemberSetForService(final String cacheName) {
		final Set<Member> storageMembers = new HashSet<Member>();
		final Set<Member> serviceMembers = getCurrentMemberSetForService(cacheName);
		for (Member member : serviceMembers) {
			if (STORAGE_SERVER_ROLE_NAME.equals(member.getRoleName())) {
				storageMembers.add(member);
			}
		}
		return storageMembers;
	}
	
	@SuppressWarnings("unchecked")
	public static Set<Member> getAllStorageNodes() {
		final Set<Member> allStorageMembers = new HashSet<Member>();
		final Set<Member> allMembers = CacheFactory.getCluster().getMemberSet();
		for (Member member : allMembers) {
			if (STORAGE_SERVER_ROLE_NAME.equals(member.getRoleName())) {
				allStorageMembers.add(member);
			}
		}
		return allStorageMembers;
	}
	
	/**
	 * 
	 * @param cacheService
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Set<Member> serviceStorageMembers(final String cacheService) {
		final Set<Member> storageMembers = new HashSet<Member>();
		final Set<Member> allMembers = CacheFactory.getService(cacheService).getInfo().getServiceMembers();
		for (Member member : allMembers) {
			if (STORAGE_SERVER_ROLE_NAME.equals(member.getRoleName())) {
				storageMembers.add(member);
			}
		}
		return storageMembers;
	}
	
	@SuppressWarnings("unchecked")
	private static final Set<Member> getCurrentMemberSetForService(final String cacheName) {
		final CacheService service = CacheFactory.getCache(cacheName).getCacheService();
		return service.getInfo().getServiceMembers();
//		final InvocationService serviceInv = (InvocationService) CacheFactory
//				.getService("InvocationService");
//		return serviceInv.getInfo().getServiceMembers();
	}
}