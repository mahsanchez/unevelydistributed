package com.bbva.datacaching.loader;

import java.io.Serializable;

/**
 * Holder class for key limit ranges, as in its DB representation.
 * 
 * Type of limits is the type of the DB column used for loading and not the type of an id field in
 * the objects themselves.
 *  
 * @author amp
 */
public class NodeLoadLimits<T> implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private final T lowerLimit;
	private final T upperLimit;
	
	public NodeLoadLimits(T lowerLimit, T upperLimit) {
		this.lowerLimit = lowerLimit;
		this.upperLimit = upperLimit;
	}

	public T getLowerLimit() {
		return lowerLimit;
	}

	public T getUpperLimit() {
		return upperLimit;
	}

	// ###### Object methods ######
	
	@Override
	@SuppressWarnings("rawtypes")
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NodeLoadLimits other = (NodeLoadLimits) obj;
		if (lowerLimit == null) {
			if (other.lowerLimit != null)
				return false;
		} else if (!lowerLimit.equals(other.lowerLimit))
			return false;
		if (upperLimit == null) {
			if (other.upperLimit != null)
				return false;
		} else if (!upperLimit.equals(other.upperLimit))
			return false;
		return true;
	}
		
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((lowerLimit == null) ? 0 : lowerLimit.hashCode());
		result = prime * result
				+ ((upperLimit == null) ? 0 : upperLimit.hashCode());
		return result;
	}
	
	@Override
	public String toString() {
		return "[lowerLimit = " + this.lowerLimit + ", upperLimit = " + this.upperLimit + "]";
	}
}