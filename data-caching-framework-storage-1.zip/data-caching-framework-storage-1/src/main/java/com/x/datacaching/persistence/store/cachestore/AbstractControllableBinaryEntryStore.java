package com.bbva.datacaching.persistence.store.cachestore;

import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.invocable.CacheStoreControllerInvocable;
import com.bbva.datacaching.persistence.store.management.ControllableStore;
import com.tangosol.net.cache.BinaryEntryStore;
import com.tangosol.util.BinaryEntry;

/**
 * 
 * @author amp
 */
public abstract class AbstractControllableBinaryEntryStore extends ControllableStore implements 
	BinaryEntryStore, ControllableBinaryEntryStore {

	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractControllableBinaryEntryStore.class);
	
//	/**
//	 * During the loading process (if existent for the given project), this property will
//	 * be turned true or false by a {@link CacheStoreControllerInvocable}
//	 * running on each storage node.
//	 */
//	private final AtomicBoolean enabled = new AtomicBoolean(true); // Enabled by default
//	
//	@Override
//	public final boolean isEnabled() {
//		return this.enabled.get();
//	}
//	
//	/**
//	 * @param enabled
//	 */
//	@Override
//	public final void setEnabled(final boolean enabled) {
//		final String state = enabled ? "enabled" : "disabled";
//		this.enabled.set(enabled);
//		LOGGER.info("Cache store has been {} on this node", state);
//	}
	
	// ###### BinaryEntryStore implementations
	
	/*
	 * Check enabled status and then delegate to abstract method which should accomplish
	 * the methods intent.
	 */
	
	@Override
	public void erase(BinaryEntry binaryEntry) {
		if (!isEnabled()) {
			return;
		}
		delete(binaryEntry);
	}
	
	@Override
	@SuppressWarnings("rawtypes")
	public void eraseAll(Set setBinEntries) {
		if (!isEnabled()) {
			return;
		}
		deleteAll(setBinEntries);
	}
	
	@Override
	public void store(BinaryEntry binaryEntry) {
		if (!isEnabled()) {
			return;
		}
		persist(binaryEntry);
	}
	
	@Override
	@SuppressWarnings("rawtypes")
	public void storeAll(Set setBinEntries) {
		if (!isEnabled()) {
			return;
		}
		persistAll(setBinEntries);
	}
	
	@Override
	public void load(BinaryEntry binaryEntry) {
		if (!isEnabled()) {
			return;
		}
		retrieve(binaryEntry);
	}
	
	@Override
	@SuppressWarnings("rawtypes")
	public void loadAll(Set setBinEntries) {
		if (!isEnabled()) {
			return;
		}
		retrieveAll(setBinEntries);
	}
	
	// ###### Helper methods ######
	
	protected String validateStringParameter(final String parameter, final String parameterName) {
		if (parameter == null || "".equals(parameter)) {
			LOGGER.info("{} parameter cannot be null or empty", parameterName);
			throw new IllegalStateException(parameterName + " cannot be null or empty");
		}
		return parameter;
	}
	
	protected int validateIntParameter(final int parameter, final String parameterName) {
		if (parameter <= 0) {
			LOGGER.info("{} parameter must be positive integer", parameterName);
			throw new IllegalStateException(parameterName + " must be more than 0");
		}
		return parameter;
	}
}