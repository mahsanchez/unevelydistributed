package com.bbva.datacaching.persistence;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.NodeLoadLimits;
import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.loader.service.BackEndService;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

/**
 * Implementations should be thread-safe, is not critical (only one call to load() per node in the general
 * case), but may happen more than once in some cases (repeat due to failure).
 * 
 * @author amp
 *
 */
public abstract class AbstractJDBCLoadable<K, V> extends AbstractCacheParallelLoadable<K, V> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractJDBCLoadable.class);
	
	private static final int LOWER_LIMIT_QUERY_INDEX = 1;
	private static final int UPPER_LIMIT_QUERY_INDEX = 2;	

//	@Override
//	public Connection getConnection() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public void closeConnection(Connection conn) {
//		// TODO Auto-generated method stub
//		
//	}
	
	// ###### Methods to be implemented in subclasses ######
	
	/**
	 * Implementations should map an entity's key from the provided {@link ResultSet} and
	 * return it.
	 * 
	 * NOTE: Do not mutate, iterate or in any other way change the provided {@link ResultSet}
	 * instance; use it only for mapping information from the DB. Handling of the
	 * {@link SQLException} should be provided by the implementation. 
	 * 
	 * @param resultSet
	 * @return
	 */
	public abstract K loadKeyFromResultSet(ResultSet resultSet);
	
	/**
	 * Implementations should map a single entity from the provided {@link ResultSet} and
	 * return it.
	 * 
	 * NOTE: Do not mutate, iterate or in any other way change the provided {@link ResultSet}
	 * instance; use it only for mapping information from the DB. Handling of the
	 * {@link SQLException} should be provided by the implementation.
	 * 
	 * @param resultSet
	 * @return
	 */
	public abstract V loadEntityFromResultSet(ResultSet resultSet);
	
	@Override
	public final void load(String cacheName, int batchSize, NodeLoadLimits<?> limits) {
		final NamedCache cache = CacheFactory.getCache(cacheName);
		// Validates batch size
		LOGGER.info("Batch size for storing objects in the cache [{}]: {}",
				new Object[]{cacheName, batchSize});
		// Batch map must support any type, which is only known at runtime
		final Map<K, V> batchMap = new HashMap<K, V>();
		
		final String loadObjectsQuery = selectObjectsInRangeQuery();
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int batchCount = 1;
		
		try {
			conn = getConnection();
			preparedStatement = conn.prepareStatement(loadObjectsQuery);
			//        	/* Default JDBC mapping from Java Object to SQL type */
			//        	statement.setObject(1, lowerLimit);
			//        	statement.setObject(2, upperLimit);
			setStatementWithCorrectType(preparedStatement, this, limits);
			resultSet = preparedStatement.executeQuery();
			
			// This is the second check on the key class type, this time on what's retrieved from the result set
			boolean hasKeyBeenValidated = false;
			while (resultSet.next()) {
				final K businessObjectKey = loadKeyFromResultSet(resultSet);
				// Validates key class, to optimize it will only be validated once per task
				if (!hasKeyBeenValidated) {
					validateKeyClass(cacheName, businessObjectKey.getClass());
					hasKeyBeenValidated = true;
				}
				final V businessObject = loadEntityFromResultSet(resultSet);
				// Puts object in batch
				batchMap.put(businessObjectKey, businessObject);
				if (batchCount % batchSize == 0) {
					// Saves all items in batch to in-memory cache
					saveAll(cache, batchMap);
					// Clears map for next batch
					batchMap.clear();
				}
				batchCount++;
			}
			// Stores any remaining elements
			if (!batchMap.isEmpty()) {
				saveAll(cache, batchMap);
				batchMap.clear();
			}
			
			conn.commit();
		} catch (SQLException e) {
			LOGGER.error("Exception thrown when loading range to cache", e);
			throw new LoadingProcessException(
					"Exception thrown when when loading range to cache", e); 
		} finally {
			cleanup(conn, preparedStatement, resultSet);
		}
	}
	
	// TODO - saveAll should be implementation dependent, an at the same time hidden from client
//	private static void saveAll(NamedCache cache, Map<?, ?> batchMap) {
//		// Stores only elements that are not already cached
//		cache.invokeAll(batchMap.keySet(), new ConditionalPutAll(AlwaysFilter.INSTANCE, batchMap));
//	}
	
	// ###### Internal methods ######
	
	private static void validateKeyClass(final String cacheName, final Class<?> keyClass) {
		for (Class<?> allowedClass : BackEndService.ALLOWED_KEY_CLASSES) {
			if (allowedClass != null && allowedClass.equals(keyClass)) {
				return; // Passed keyClass is allowed
			}
		}
		// The key class is not allowed if it's not in the accepted types
		LOGGER.error("The passed key class ({}) for cache [{}] is not allowed", 
				new Object[]{keyClass.getName(), cacheName});
		throw new IllegalArgumentException("The passed key class (" + keyClass.getName()
				+ " for cache " + cacheName + " is not allowed");
	}
	
	private void cleanup(final Connection conn, final Statement statement, final ResultSet resultSet) {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (SQLException e) {
				LOGGER.error("{} thrown when closing a {}",
						new Object[]{e.getClass().getSimpleName(), resultSet.getClass().getName()});
				throw new LoadingProcessException("Exception thrown when closing result set", e);
			}
		}
		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException e) {
				LOGGER.error("{} thrown when closing a {}",
						new Object[]{e.getClass().getSimpleName(), statement.getClass().getName()});
				throw new LoadingProcessException("Exception thrown when closing statement", e);
			}
		}
		if (conn != null) {
//			try {
			/* Let the implementation decide how to close connections; the connection poll is provided the 
			 * connection pool is provided by the implementation.
			 */
			closeConnection(conn);
//			} catch (SQLException e) {
//				LOGGER.error("[{}] MemberId {}: {} thrown when returning a {} to the pool",
//						new Object[]{this.cacheName, e.getClass().getSimpleName(), conn.getClass().getName()});
//				throw new IllegalStateException(EXCEPTION_MESSAGE + " when closing connection", e);
//			}
		}
	}
	
	// ###### Typed PreparedStatement methods ######

	private void setStatementWithCorrectType(final PreparedStatement ps, @SuppressWarnings("rawtypes") final ParallelLoadable loadable,
			final NodeLoadLimits<?> limits) throws SQLException {
		if (String.class.equals(getKeyClass())) {
			setString(ps, limits);
		} else if (Integer.class.equals(getKeyClass()) 
				|| int.class.equals(getKeyClass())) {
			setInt(ps, limits);
		} else if (Long.class.equals(getKeyClass()) 
				|| long.class.equals(getKeyClass())) {
			setLong(ps, limits);
		} else if (BigInteger.class.equals(getKeyClass())) {
			setBigInteger(ps, limits);
		} else {
			LOGGER.error("Shouldn't get here");
		}
	}

	private static void setString(final PreparedStatement ps, final NodeLoadLimits<?> limits)
			throws SQLException {
		ps.setString(LOWER_LIMIT_QUERY_INDEX, (String) limits.getLowerLimit());
		ps.setString(UPPER_LIMIT_QUERY_INDEX, (String) limits.getUpperLimit());
	}

	private static void setInt(final PreparedStatement ps, final NodeLoadLimits<?> limits)
			throws SQLException {
		ps.setInt(LOWER_LIMIT_QUERY_INDEX, (Integer) limits.getLowerLimit());
		ps.setInt(UPPER_LIMIT_QUERY_INDEX, (Integer) limits.getUpperLimit());
	}

	private static void setLong(final PreparedStatement ps, final NodeLoadLimits<?> limits)
			throws SQLException {
		ps.setLong(LOWER_LIMIT_QUERY_INDEX, (Long) limits.getLowerLimit());
		ps.setLong(UPPER_LIMIT_QUERY_INDEX, (Long) limits.getUpperLimit());
	}

	private static void setBigInteger(final PreparedStatement ps, final NodeLoadLimits<?> limits)
			throws SQLException {
		ps.setBigDecimal(LOWER_LIMIT_QUERY_INDEX,
				new BigDecimal((BigInteger) limits.getLowerLimit(), 0));
		ps.setBigDecimal(LOWER_LIMIT_QUERY_INDEX,
				new BigDecimal((BigInteger) limits.getUpperLimit(), 0));
	}
}