package com.bbva.datacaching.persistence.store.cachestore;

import java.util.Collection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.persistence.store.management.ControllableStore;
import com.tangosol.net.cache.CacheStore;

/**
 * There will be only one of this classes per cache per node,
 * (all nodes with a given cache are set by invocable).
 * 
 * @author amp
 */
public abstract class AbstractControllableCacheStore extends ControllableStore implements CacheStore, ControllableCacheStore {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractControllableCacheStore.class);
	
	private static final String UNIMPLEMENTED_MESSAGE = "Unimplemented";
	
//	/**
//	 * During the loading process (if existent for the given project), this property will
//	 * be turned true or false by a {@link CacheStoreControllerInvocable}
//	 * running on each storage node.
//	 */
//	private final AtomicBoolean enabled = new AtomicBoolean(true); // Enabled by default
//	
//	public final boolean isEnabled() {
//		return this.enabled.get();
//	}
//	
//	/**
//	 * Package-private, cannot be set by clients, will only be set by Invocable
//	 * @param enabled
//	 */
//	@Override
//	public final void setEnabled(final boolean enabled) {
//		final String state = enabled ? "enabled" : "disabled";
//		this.enabled.set(enabled);
//		LOGGER.info("Cache store has been {} on this node", state);
//	}
	
	// ###### CacheStore implementations ######
	
	@Override
	public void erase(Object key) {
		if (!isEnabled()) {
			return;
		}
		delete(key);
	}
	
	@Override
	@SuppressWarnings("rawtypes")
	public void eraseAll(Collection keys) {
		if (!isEnabled()) {
			return;
		}
		deleteAll(keys);
	}
	
	/**
	 * If {@link AbstractControllableCacheStore#enabled} is false, does not store
	 * the entity in the database.
	 * Check-then-act pattern is ok in this situation, this will only be disabled when loading and will be enabled
	 * after loading before the cache starts receiving petitions.
	 */
	@Override
	public void store(final Object key, final Object value) {
		if (!isEnabled()) {
			return;
		}
		persist(key, value);
	}

	/**
	 * If {@link AbstractControllableCacheStore#enabled} is false, does not store
	 * the entities in the database.
	 * Check-then-act pattern is ok in this situation, this will only be disabled when loading and will be enabled
	 * after loading before the cache starts receiving petitions.
	 */
	@Override
	@SuppressWarnings("rawtypes")
	public void storeAll(final Map entries) {
		if (!isEnabled()) {
			return;
		}
		persistAll(entries);
	}
	
//	@Override
//	public Object load(Object key) {
//		if (!isEnabled()) {
//			return;
//		}
//		retrieve(key);
//	}
	
//	@Override
//	public Map loadAll(Collection keys) {
//		if (!isEnabled()) {
//			return;
//		}
//		retrieveAll(keys);
//	}
	
	// ###### The relevant methods should be overriden in subclasses ######
	
//	public Object controllableLoad(Object key) {
//		throw new UnsupportedOperationException(UNIMPLEMENTED_MESSAGE);
//	}
//	
//	public Map<?, ?> controllableLoadAll(Collection<?> keys) {
//		throw new UnsupportedOperationException(UNIMPLEMENTED_MESSAGE);
//	}
//	
//	public void controllableErase(Object key) {
//		throw new UnsupportedOperationException(UNIMPLEMENTED_MESSAGE);
//	}
//	
//	public void controllableEraseAll(Collection<?> keys) {
//		throw new UnsupportedOperationException(UNIMPLEMENTED_MESSAGE);
//	}
}