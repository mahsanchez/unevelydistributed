package com.bbva.datacaching.loader.invocable.observer;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.tangosol.net.InvocationObserver;
import com.tangosol.net.Member;

/**
 * Checks if the execution of code in the distributed nodes has concluded correctly in
 * order to provide a return code to the script launching the code execution.
 * 
 * @author amp
 *
 */
public class DistributedExecutionObserver implements InvocationObserver {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DistributedExecutionObserver.class);
	
	private final CountDownLatch latch;
	
	/**
	 * This param is used for more descriptive logging. In case of failure, we use the class name to
	 * indicate which class' code has failed.
	 */
	private final String invocableClassName;
	
	public DistributedExecutionObserver(final int executingNodes, final String invocableClassName) {
		if (executingNodes <= 0) {
			LOGGER.error("Number of executing nodes must be a positive integer");
			throw new IllegalStateException("Number of executing nodes must be a positive integer");
		}
		this.latch = new CountDownLatch(executingNodes);
		this.invocableClassName = invocableClassName;
	}
	
	// ###### Invocable implementations ######

	@Override
	public void invocationCompleted() {}

	@Override
	public void memberCompleted(Member member, Object result) {
		this.latch.countDown();
	}

	@Override
	public void memberFailed(Member member, Throwable t) {
		LOGGER.error("Member {} failed to execute code sent for execution in invocable [{}]",
				new Object[]{member.getId(), this.invocableClassName, t});
		throw new IllegalStateException("Member " + member.getId() + " failed to execute code "
				+ "sent for execution in invocable " + this.invocableClassName, t);
	}

	@Override
	public void memberLeft(Member member) {
		LOGGER.error("Member {} left while executing code in invocable [{}]", member.getId(),
				this.invocableClassName);
		throw new IllegalStateException("Member " + member.getId() + " left while executing code "
				+ "in invocable " + this.invocableClassName);
	}

	// ###### Class methods ######
	
	public boolean await(final long timeOut, final TimeUnit timeUnit) {
		try {
			LOGGER.info("Timeout for latch in {} for execution of invocable [{}], has been set to {} {}", 
					new Object[]{this.getClass().getSimpleName(), this.invocableClassName, timeOut, 
					timeUnit.toString()});
			return this.latch.await(timeOut, timeUnit);
		} catch (InterruptedException e) {
			LOGGER.error("{} thrown while waiting for latch in {} for invocable [{}]", new Object[]{e.getClass().getSimpleName(), 
							this.getClass().getName(), this.invocableClassName});
			throw new LoadingProcessException(e.getClass().getSimpleName() + " thrown while waiting "
					+ "for latch in " + this.getClass().getName() + " for invocable "
					+ this.invocableClassName);
		}
	}
}