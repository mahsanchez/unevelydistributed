package com.bbva.datacaching.loader.configuration;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.environment.extensible.ConfigurableParameterResolver;
import com.bbva.datacaching.environment.extensible.CustomXmlElement;
import com.bbva.datacaching.environment.extensible.DescribableParameterResolver;
import com.bbva.datacaching.environment.extensible.XmlTags;
import com.bbva.datacaching.environment.extensible.annotation.Adapted;
import com.bbva.datacaching.environment.extensible.exception.CustomXMLConfigurationException;
import com.bbva.datacaching.environment.extensible.processor.AddIndexProcessor;
import com.bbva.datacaching.loader.LoaderNamespaceContentHandler;
import com.bbva.datacaching.loader.RequiredConfigurationElements;
import com.bbva.datacaching.persistence.ParallelLoadable;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.run.xml.XmlHelper;
import com.tangosol.run.xml.XmlValue;
import com.tangosol.util.ClassHelper;
import com.tangosol.util.ValueExtractor;


/**
 * <p>
 * As {@link ObjectResolver} allows converting an xml description of an Object
 * to an actual object based on the existing mechanism using in Coherence for
 * instantiation
 * </p>
 * 
 * <p>
 * Whilst some people depend on third party libraries to perform injection many
 * people do not wish to pay the cost to introduce such flexibility or require
 * the advanced features they provide. Sometimes an extension to what is already
 * provided is enough.
 * </p>
 * 
 * @author amp
 */
// TODO - remove this class when merging this project with data caching.
public class ObjectResolver implements DescribableParameterResolver {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ObjectResolver.class);
	
	/** String that represents the {@link Object} type in configuration. */
	public static final String OBJECT_TYPE = "{object}";
	
	/** String that represents the {@link Object} type in configuration. */
	public static final String EXTRACTOR_TYPE = "{extractor}";
	
	/** Default package for a {@link ValueExtractor}. */
	public static final String DEFAULT_EXTRACTOR_PACKAGE = "com.tangosol.util.extractor";
	/** Default {@link ValueExtractor} class. */
	public static final String DEFAULT_EXTRACTOR_CLASS = DEFAULT_EXTRACTOR_PACKAGE 
			+ ".PofExtractor";
	
	// ----- DescribableParameterResolver interface -------------------------

	/**
	 * <class-name>xx.Xxx</class-name> <init-params> <init-param>
	 * <param-name>{object}</param-name> <param-value>
	 * <class-name>yy.Yyy</class-name> <init-params> <init-param>
	 * <param-name>{class}</param-name> <param-value>zz.Zzz</param-value>
	 * </init-parm> <init-param> <param-name>{int[]}</param-name>
	 * <param-value>1,2,3</param-value> </init-parm> </init-params>
	 * </param-value> </init-param>
	 * 
	 * </init-params>
	 */
	public Object resolveParameter(final String sType, final String sValue) {
		if (sType == null || sValue == null) {
			return null;
		} 
		if (sType.equals(OBJECT_TYPE)) {
			return instantiateObject(XmlHelper.loadXml(sValue));
		}
		else if (sType.equals(EXTRACTOR_TYPE)) {
			return instantiateExtractor(XmlHelper.loadXml(sValue));
		}
		
		return null;
	}

	/**
	 * This {@link DescribableParameterResolver} support {@link #OBJECT_TYPE}
	 */
	public String[] getParamNames() {
		return new String[] { OBJECT_TYPE, EXTRACTOR_TYPE };
	}

	// ----- public helpers -------------------------------------------------

	/**
	 * Convert any Objects expecting primitive arrays from their existing
	 * java.lang.* equivalents.
	 * 
	 * @param <T>
	 *            The java.lang.* type to start with
	 * @param clz
	 *            The class or TYPE describing the java.lang.* type
	 * @param aoParam
	 *            Array of paramters
	 * @return new instance of an object
	 * @throws InstantiationException
	 * @throws InvocationTargetException
	 * @see ClassHelper#newInstance(Class, Object[])
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T> T newInstance(final Class<T> clz, Object[] aoParam)
			throws InstantiationException, InvocationTargetException 
	{
		// prime params by ensuring primitive Object equivalents are auto boxed
		Constructor[] cons = clz.getConstructors();
		for (int i = 0; i < cons.length; ++i) 
		{
			if (cons[i].getParameterTypes() != null
					&& cons[i].getParameterTypes().length == aoParam.length) 
			{
				Class[] aParamTypes = cons[i].getParameterTypes();
				for (int j = 0; j < aParamTypes.length; ++j) {
					// convert aParamTypes[j] to (int[])aParamTypes[j]
					if (aParamTypes[j].isArray()) {
						try {
							if (((Object[]) aoParam[j])[0] instanceof Integer) 
							{
								Integer[] aIntegers = (Integer[]) aoParam[j];
								int[] aInts = new int[((Integer[]) aoParam[j]).length];
								System.arraycopy(aIntegers, 0, aInts, 0, aIntegers.length);
								aoParam[j] = aInts;
							}
						} catch (ClassCastException e) {
							continue; // Means that this is not the expected method
						}
					}

				}
			}
		}
		return (T) ClassHelper.newInstance(clz, aoParam);
	}

	// ----- helpers --------------------------------------------------------

	/**
	 * Uses the default coherence <init-params> tag for class instantiation.
	 * 
	 * @param xObject
	 * @return
	 */
	public Object instantiateObjectWithInitParams(final XmlElement xObject) {
		// Configured only for to read from this type
		Class<?> clazz = ensureClass(xObject, null);
		XmlElement xParams = xObject.getElement(XmlTags.INIT_PARAMS);
		Object[] aoParam = null;
		if (xParams == null){
			aoParam = new Object[]{};
		}
		else 
		{				
			aoParam = XmlHelper.parseInitParams(new CustomXmlElement(xParams), 
					ConfigurableParameterResolver.getInstance());
		}
		try {
			return newInstance(clazz, aoParam);
		} catch (InstantiationException e) {
			throw new CustomXMLConfigurationException("Failed to instantiate Class: "
					+ clazz.getName() + " Params: " + Arrays.toString(aoParam), e);
		} catch (InvocationTargetException e) {
			throw new CustomXMLConfigurationException("Failed to invoke constructor Class: "
					+ clazz.getName() + " Params: " + Arrays.toString(aoParam), e);
		}
	}
	
	/**
	 * Create an Object based on the xml descriptor.
	 * 
	 * @param xObject
	 * @return
	 */
	public Object instantiateObject(final XmlElement xObject) {
		// Configured only for to read from this type
		Class<?> clazz = ensureClass(xObject, ParallelLoadable.class);
		XmlElement xParams = xObject.getElement(XmlTags.PARAMS);
		Object[] aoParam = null;
		if (xParams == null) {
			aoParam = new Object[]{};
		} else {				
			aoParam = XmlHelper.parseInitParams(new CustomXmlElement(xParams), 
					ConfigurableParameterResolver.getInstance());
		}
		
		try {
			return newInstance(clazz, aoParam);
		} catch (InstantiationException e) {
			LOGGER.error("{} thrown - failed to instantiate class. Check configuration for {}",
					e.getClass().getSimpleName(), LoaderNamespaceContentHandler.ACCESS_OBJECT_ELEMENT_NAME);
			throw new CustomXMLConfigurationException("Failed to instantiate Class: "
					+ clazz.getName() + " Params: " + Arrays.toString(aoParam), e);
		} catch (InvocationTargetException e) {
			LOGGER.error("{} thrown - failed to invoke constructor in class to be instantiated. Check "
					+ "configuration for {}",
					e.getClass().getSimpleName(), LoaderNamespaceContentHandler.ACCESS_OBJECT_ELEMENT_NAME);
			throw new CustomXMLConfigurationException("Failed to invoke constructor Class: "
					+ clazz.getName() + " Params: " + Arrays.toString(aoParam), e);
		}
	}
	
	/**
	 * Create an Object based on the xml descriptor.
	 * 
	 * @param xObject
	 * @return
	 */
	private Object instantiateExtractor(final XmlElement xObject) 
	{
		Class<?> clazz = ensureClass(xObject, null);
		XmlElement xParams = xObject.getElement( XmlTags.PARAMS);
		Object[] aoParam = null;
		if (xParams == null)
		{
			// Check: We only allow a <params> element under <extractor>
			if (!xObject.getElementList().isEmpty()) {
				throw new CustomXMLConfigurationException("Unexpected element " + ((XmlElement)xObject.getElementList().get(0)).getName() + " under element <extractor>");
			}
			aoParam = new Object[]{};
		}
		else 
		{				
			if (xParams.getElement(XmlTags.EXTRACTOR) == null && xParams.getElement(XmlTags.ARRAY)== null)
			{
				// It's a simple extractor. We can instantiate like an object
				return instantiateObject(xObject);
			}
			else
			{
				// Complex extractor:
				List<XmlElement> list = xParams.getElementList();
				if (list.size() == 0)
					aoParam = new Object[]{};
				else
				{
					aoParam = new Object [list.size()] ;
					Iterator <XmlElement>  iterator = list.iterator();
					int i= 0;
					while (iterator.hasNext())
					{
						XmlElement element = (XmlElement) iterator.next();
						String name = element.getName();
						if (name.equals(XmlTags.EXTRACTOR))
						{
							AddIndexProcessor.ensureClassName(element);
							aoParam [i++] = instantiateExtractor(element);
						}
						else if (name.equals(XmlTags.ARRAY))
						{
							aoParam [i++] = instantiateArray(element);
						}
						else if (name.equals("init-param"))
						{
							throw new CustomXMLConfigurationException("Invalid index definition. <init-param> elements can't be used with <extractor> or <array> in the same <params> element!");
						}
						else
						{
							throw new CustomXMLConfigurationException("Unexpected element " + name + "! ");
						}
					}
				}
			}
			
		}
		try {
			return newInstance(clazz, aoParam);
		}
		catch (InstantiationException e) {
			throw new CustomXMLConfigurationException("Failed to instantiate Class: " + clazz.getName() 
					+ " Params: " + Arrays.toString(aoParam), e);
		} catch (InvocationTargetException e) {
			throw new CustomXMLConfigurationException("Failed to invoke constructor Class: " + clazz.getName() 
					+ " Params: " + Arrays.toString(aoParam), e);
		}
	}
	

	
	/**
	 * Create a ValueExtractor[] based on the xml descriptor.
	 * 
	 * @param xObject
	 * @return ValueExtractor[] 
	 */
	private ValueExtractor[] instantiateArray(final XmlElement xObject) 
	{
		Iterator<?> iterator = xObject.getElements(XmlTags.EXTRACTOR);
		
		ArrayList<ValueExtractor> array = new ArrayList<ValueExtractor>();
		while (iterator.hasNext())
		{
			XmlElement element = (XmlElement) iterator.next();
			String name = element.getName();
			if (name.equals(XmlTags.EXTRACTOR))
			{
				AddIndexProcessor.ensureClassName(element);
				array.add( (ValueExtractor) instantiateExtractor(element));
			}
		}

		// Creamos el array de ValueExtractor
		ValueExtractor[] ve = new ValueExtractor[array.size()];
		int j=0;
		for (ValueExtractor value : array)
		{
			ve[j++]  = value;
		}
		
		return ve;
		
		
	}
	
	/**
	 * Ensure a class is created
	 * 
	 * @param <C>
	 *            The concrete implementation
	 * @param xmlElement
	 *            XML describing the object
	 * @param assignable
	 *            Validation and type safety class
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private <C> Class<C> ensureClass(final XmlElement xmlElement, final Class<C> assignable) {
		Class<?> clazz = null;
		String sClass = null;
		XmlValue aClassName = xmlElement.getAttribute(XmlTags.CLASSNAME);
		if (aClassName == null) {
			LOGGER.error("A non-empty {} attribute must be given for element <{}>", XmlTags.CLASSNAME, xmlElement.getName());
			throw new CustomXMLConfigurationException("A '"+ XmlTags.CLASSNAME + "' attribute must be specified and cannot be empty");
		}
		
		sClass = aClassName.getString();
		if (sClass == null || sClass.trim().length()== 0) {
			LOGGER.error("The {} attribute for element <{}> cannot be an empty string", XmlTags.CLASSNAME, xmlElement.getName());
			throw new CustomXMLConfigurationException("The '" + XmlTags.CLASSNAME + "' attribute cannot be an empty string:\n" + xmlElement);
		}

		try {
			clazz = Class.forName(sClass);
			if (assignable != null && !assignable.isAssignableFrom(clazz)) {
				LOGGER.error("The provided access object class in element <{}> must be assignable to {}", 
						xmlElement.getName(), assignable.getClass().getName());
				throw new CustomXMLConfigurationException("The provided class must be assignable to "
						+ assignable.getClass().getName());
			}
		} catch (ClassNotFoundException e) {
			LOGGER.error("{} thrown - could not find class {}:\n {}", new Object[]{e.getClass().getSimpleName(), sClass, e});
			throw new CustomXMLConfigurationException("Could not find class " + sClass, e);
		}
		return (Class<C>) clazz;
	}
}
