package com.bbva.datacaching.policy;

import java.util.concurrent.atomic.AtomicReference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.policy.manager.ActionPolicyManager;
import com.tangosol.net.Action;
import com.tangosol.net.ActionPolicy;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.ConfigurableQuorumPolicy;
import com.tangosol.net.ConfigurableQuorumPolicy.MembershipQuorumPolicy.QuorumRule;
import com.tangosol.net.ConfigurableQuorumPolicy.PartitionedCacheQuorumPolicy;
import com.tangosol.net.NamedCache;
import com.tangosol.net.Service;
import com.tangosol.util.NullImplementation.NullActionPolicy;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.processor.ConditionalPut;

/**
 * Implements a Strategy Pattern for ActionPolicies.
 * If not specifying a given operations service members quorum, give 0.
 * 
 * Policy cache must be a replicated cache to exist in every node. ActionPolicies and the entry
 * processors that operate on them have not been made to serialize.
 * Policy cache key may be specified per cache or per service (depending on the policyCacheKey given in configuration, it must be a string key.
 * 
 * This class is thread safe.
 * @author amp
 */
public class StrategyDelegatorActionPolicy implements ActionPolicy {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StrategyDelegatorActionPolicy.class);
	
	private final ActionPolicy loaderPolicy = LoaderActionPolicy.getInstance();
	private final ActionPolicy nullPolicy = NullActionPolicy.INSTANCE; // If none is explicitly configured
	private final ActionPolicy partitionedPolicy; // In case one is explicitly configured
	
	private final String policyServiceKey;
	
	/**
	 * The effective policy at any given time, atomic variable ensures memory visibility from all threads
	 */
	private final AtomicReference<ActionPolicy> effectivePolicy = new AtomicReference<ActionPolicy>();
	
	private final ActionPolicy regularPolicy; // The one to use in the non-loading case
	
	public StrategyDelegatorActionPolicy(final String policyServiceKey) {
		this.partitionedPolicy = null; // Not used in this case, none has been configured
		this.regularPolicy = this.nullPolicy; // The regular case
		this.effectivePolicy.set(this.regularPolicy);
		this.policyServiceKey = policyServiceKey;
	}
	
	public StrategyDelegatorActionPolicy(final String cacheName, final int distributionQuorum, 
			final int restoreQuorum, final int readQuorum, final int writeQuorum) {
		final QuorumRule[] quorumRules = { 
				new QuorumRule(PartitionedCacheQuorumPolicy.MASK_DISTRIBUTION, verifyQuorumIntValue(distributionQuorum)),
				new QuorumRule(PartitionedCacheQuorumPolicy.MASK_RESTORE, verifyQuorumIntValue(distributionQuorum)),
				new QuorumRule(PartitionedCacheQuorumPolicy.MASK_READ, verifyQuorumIntValue(distributionQuorum)),
				new QuorumRule(PartitionedCacheQuorumPolicy.MASK_WRITE, verifyQuorumIntValue(distributionQuorum))
		};
		this.partitionedPolicy = ConfigurableQuorumPolicy.instantiatePartitionedCachePolicy(quorumRules);
		this.regularPolicy = this.partitionedPolicy; // The regular case
		this.effectivePolicy.set(this.partitionedPolicy);
		this.policyServiceKey = cacheName;
	}
	
	/* Only called once, on this object's construction from configuration.
	 * Called from a different thread (maybe there could be service thread problems otherwise).
	 */
//	public void putThisInstanceInPolicyManager(final String policyCacheName, final String policyCacheKey) {
//		// TODO - some delay in the next thread to let the constructor finish?
//		new Thread(new PutInPolicyManager(policyCacheName, policyCacheKey)).start();
//	}
	
	/* Only called once, when the service initializes this object.
	 * Called from a different thread (maybe there could be service thread problems otherwise).
	 */
	public void putThisInstanceInPolicyManager(final String policyServiceKey) {
		new Thread(new PutInPolicyManager(policyServiceKey)).start();
	}
	
	@Override
	public void init(Service service) {
		if (this.policyServiceKey == null) {
			LOGGER.error("{} instance cannot be configured with a null cache name", this.getClass().getSimpleName());
			throw new LoadingProcessException(this.getClass().getSimpleName() + " cannot be configured with a null "
					+ "cache name");
		}
		putThisInstanceInPolicyManager(this.policyServiceKey);
	}

	@Override
	public boolean isAllowed(final Service service, final Action action) {
		return this.effectivePolicy.get().isAllowed(service, action);
	}
	
	public void establishLoadingPolicy() {
		this.effectivePolicy.set(this.loaderPolicy);
		LOGGER.info("Effective policy: {}", this.effectivePolicy.get());
	}
	
	public void establishRegularPolicy() {
		this.effectivePolicy.set(this.regularPolicy);
		LOGGER.info("Effective policy: {}", this.effectivePolicy.get());
	}
	
	private int verifyQuorumIntValue(final int quorumValue) {
		if (quorumValue < 0) {
			throw new IllegalArgumentException("The quorum values must be non-negative");
		}
		return quorumValue;
	}
	
	/**
	 * Enum type representing the possible options to set the {@link ActionPolicy} to 
	 */
	public static enum PolicyType { 
		REGULAR,
		LOADING;
	}
	
	private class PutInPolicyManager implements Runnable {
		
		private final String policyServiceKey;
//		private final String policyCacheName;
//		private final String policyCacheKey;
		
//		public PutInPolicyManager(final String policyCacheName, final String policyCacheKey) {
//			this.policyCacheName = policyCacheName;
//			this.policyCacheKey = policyCacheKey;
//		}
		
		public PutInPolicyManager(final String policyServiceKey) {
			this.policyServiceKey = policyServiceKey;
		}
		
		/**
		 * Makes this instance of {@link StrategyDelegatorActionPolicy} (the outer class) accessible
		 * from {@link ActionPolicyManager}, so the effective {@link ActionPolicy} for a given cache
		 * can be later set in all nodes.
		 */
		@Override
		public void run() {
			ActionPolicyManager.putInPolicyMap(this.policyServiceKey, StrategyDelegatorActionPolicy.this);
//			final NamedCache policyCache = CacheFactory.getCache(this.policyCacheName);
//			policyCache.invoke(this.policyCacheKey,
//					new ConditionalPut(AlwaysFilter.INSTANCE, StrategyDelegatorActionPolicy.this));
//			LOGGER.info("A {} instance has been placed in the policy cache [{}] with the key [{}]",
//					new Object[]{StrategyDelegatorActionPolicy.this, this.policyCacheName, this.policyCacheKey});
		}
	}
}