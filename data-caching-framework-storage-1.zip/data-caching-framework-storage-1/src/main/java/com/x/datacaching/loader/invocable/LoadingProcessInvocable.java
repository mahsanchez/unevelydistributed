package com.bbva.datacaching.loader.invocable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.LoadingConfigurationParameters;
import com.bbva.datacaching.loader.LoadingProcess;
import com.bbva.datacaching.loader.exception.LoadingProcessException;
import com.bbva.datacaching.loader.invocable.observer.DistributedExecutionObserver;
import com.bbva.datacaching.loader.service.CacheInfoService;
import com.bbva.datacaching.loader.util.Utilities;
import com.tangosol.net.AbstractInvocable;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;

/**
 * {@link Invocable} that is sent for execution, from the {@link LoadCache} executable, on one of the 
 * nodes carrying the service of the given cache (will be sent from the start up script to only one
 * node).
 * 
 * Initiates the {@link LoadingProcess} on the executing node from a separate thread.
 *  
 * @author amp
 */
public class LoadingProcessInvocable extends AbstractInvocable {
	
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = LoggerFactory.getLogger(LoadingProcessInvocable.class);
	
	private static final ExecutorService executor = Executors.newCachedThreadPool();
	
//	private String infoCacheName;
	private String cacheName; // Cache name used as info cache key
	private long timeout; // In ms

	public LoadingProcessInvocable() {}
	
	public LoadingProcessInvocable(final String cacheName, final long timeout) {
//		this.infoCacheName = infoCacheName;
		this.cacheName = cacheName;
		if (timeout <= 0) {
			LOGGER.error("<TIMEOUT_MILLIS> parameter must be a positive integer");
			System.exit(1); // Exits script with error code
		}
		this.timeout = timeout;
	}
	
	@Override
	public void run() {
		int localNodeId = 0;
		try {
			localNodeId = CacheFactory.getCluster().getLocalMember().getId();
			LOGGER.info("Running invocable that initiates the loading process execution on node {}", localNodeId);

			final LoadingConfigurationParameters configParams = 
					CacheInfoService.getCacheInfo(cacheName /* Used as key in info cache */) ;
			if (configParams == null) {
				LOGGER.error("{} cannot be null for cache [{}]. Loading will not continue for "
						+ "this cache", LoadingConfigurationParameters.class.getSimpleName(), cacheName);
				// TODO - Exception here? Will stop static class, or thread accessing it? Will not be output
				// in the client since it occurs in a separate thread.
				throw new LoadingProcessException(LoadingConfigurationParameters.class.getSimpleName() + " cannot "
						+ "be null for cache " + cacheName);
			}
			
			/* Runs loading process on the designated node, in this thread so we easily get any exceptions
			 * that the code might throw. */
			final Future<Void> executionResult = executor.submit(new LoadingProcess(
					configParams.getInvocationServiceName(),
					this.cacheName,
//					configParams.getControlCacheName(),
					configParams.getPolicyServiceKey(),
//					configParams.queryFilePath(),
					configParams.getTableName(),
					configParams.getKeyColumnName(),
					configParams.getMinimumNodes(),
					configParams.getBatchSize(),
					this.timeout));
			
			/*
			 * Waiting call. We're not interested in the result, only in the case that an exception has been thrown
			 * while running the Future, so that we can communicate back to the client.
			 */
			executionResult.get();

		} catch (ExecutionException e) {
			// We're interested in the underlying exception that caused the ExecutioException in the Future.
			LOGGER.error("Exception while executing invocable to initiate the loading process on "
					+ "node {}", localNodeId, e.getCause());
			throw new LoadingProcessException("Exception while executing invocable to initiate the loading process "
					+ "on this node", e.getCause());
		} catch (InterruptedException e) {
			LOGGER.error("{} thrown while waiting for the loading initiation code to execute on a separate thread "
					+ "on this node",
					e.getClass().getSimpleName());
			throw new LoadingProcessException("Exception thrown while waiting for the loading initiation code to "
					+ "execute on a separate thread on this node", e.getCause());
		} catch (Exception e) { // For exceptions in the code that accesses Coherence
			LOGGER.error("Exception while executing invocable to initiate the loading process on "
					+ "node ", localNodeId, e);
			throw new LoadingProcessException("Exception while executing invocable to initiate the loading process "
					+ "on this node", e);
		}
//		LOGGER.info("Submitted loading process for cache [{}] for execution from a separate thread on this node",
//				this.mainCacheName);
	}
	
	/**
	 * Enables this {@link Invocable} to be run from a script to initiate the {@link LoadingProcess}
	 * on a node carrying the cache's service.
	 * 
	 * Runs from a script to initiate the loading process in a given cache. Requires that the
	 * cluster be previously started, that the cache service that the given cache refers to be
	 * initialized and that the cache exists. 
	 * 
	 * This executable launches a petition on the cluster - it requires the configuration of an 
	 * {@link InvocationService} that the process will use to initialize the loading process on
	 * one of the service nodes.
	 * 
	 * @param args
	 */
	public static void main(String args[]) {
		if (args == null || args.length != 3) {
			LOGGER.error("Usage: {} <INVOCATION_SERVICE_NAME> <CACHE_NAME> <TIMEOUT_MILLIS>",
					LoadingProcessInvocable.class.getName());
			System.exit(1); // Exits script with error code
		}
		
		for (final String arg : args) {
			if (arg == null || "".equals(arg)) {
				LOGGER.error("Script parameters cannot be null or empty");
				System.exit(1); // Exits script with error code
			}
		}
		
		final String invocationServiceName = args[0];
		final String cacheName = args[1];
		long timeout = 0;
		try {
			timeout = Long.parseLong(args[2]);
		} catch (NumberFormatException e) {
			LOGGER.error("<TIMEOUT_MILLIS> parameter must be numeric");
			System.exit(1); // Exits script with error code
		}
		
		LOGGER.info("Running {}", LoadingProcessInvocable.class.getSimpleName());
		
		try {
			final List<Member> memberList = Utilities.getCurrentStorageMembersListForService(cacheName) ;
			final List<Integer> memberIds = new ArrayList<Integer>();
			for (final Member member : memberList) {
				memberIds.add(member.getId());
			}
			final Member initLoadingMember = memberList.get(new Random().nextInt(memberIds.size()));
			final InvocationService invocationService = 
					(InvocationService) CacheFactory.getService(invocationServiceName);
			
			// Invocable will run on a single node, the main loading node, picked at random from elegible nodes
			final DistributedExecutionObserver observer = new DistributedExecutionObserver(
					1, LoadingProcessInvocable.class.getSimpleName());
			invocationService.execute(new LoadingProcessInvocable(cacheName, timeout),
					Collections.singleton(initLoadingMember), observer);
			LOGGER.info("Sent an Invocable for execution to initiate the loading process for cache [{}] from "
					+ "init service member {}", cacheName, initLoadingMember.getId());
			LOGGER.info("Execution time allowed before timeout: {}ms ......", timeout);
			
			final boolean result = observer.await(timeout, TimeUnit.MILLISECONDS);
			if (!result) {
				LOGGER.error("Timeout reached before finishing executing the loading process. There is "
						+ "no guarantee that the entities have been loaded");
				throw new IllegalStateException("Timeout reached before executing the code in all nodes, "
						+ "there is no guarantee that the entities have been loaded");
			}
		} catch (Exception e) {
			LOGGER.error("Exception thrown when running distributed code for {}",
					LoadingProcessInvocable.class.getSimpleName(), e);
			System.exit(1); // Exits script with error code
		} finally {
			// Shuts down cache factory from this client node after loading
			CacheFactory.shutdown();
		}

		// At this point, code has executed correctly
		LOGGER.info("{} has successfully executed", LoadingProcessInvocable.class.getSimpleName());
		System.exit(0); // Signals successful execution
	}
}