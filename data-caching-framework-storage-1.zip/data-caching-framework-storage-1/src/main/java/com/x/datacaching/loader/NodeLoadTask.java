package com.bbva.datacaching.loader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.datacaching.loader.service.BackEndService;
import com.tangosol.net.AbstractInvocable;
import com.tangosol.net.Invocable;

/**
 * This {@link Invocable} is executed with retrials by means of a {@link LoadingProcessorObserver}, so
 * exception handling is less critical.
 * 
 * An instance of this class is created once per cache service node for each load; in case of retrial,
 * the node(s) chosen for rerun will create a new instance to retry the failed range. 
 * 
 * @author amp
 */
public class NodeLoadTask extends AbstractInvocable {
	private static final Logger LOGGER = LoggerFactory.getLogger(NodeLoadTask.class);
	
	private static final long serialVersionUID = 1L;
//	public static final int SUCCESSFUL_COMPLETION = 0; // Flag to signal sucess
//	public static final int FAILED_COMPLETION = 1; // Flag to signal failure
	
//	private final DAOHandler daoHandler; // Can be transient?
	private final String cacheName;
	private final int batchSize;
	private final NodeLoadLimits<Object> loadLimits;
	/** Flag to signal whether execution of the {@link Invocable} on the node is successful.
	 * Can only be set within this class */
	private boolean successfulyExecuted = false; // When it starts, the task has not been run
//	private transient Member member; // The member node on which this task will run
	
//	public NodeLoadTask(final DAOHandler daoHandler, final NodeLoadLimits<Object> loadLimits) {
////			final Member member) {
//		this.daoHandler = daoHandler;
//		this.loadLimits = loadLimits;
////		this.member = member;
//	}
	
	public NodeLoadTask(final String cacheName, final int batchSize, final NodeLoadLimits<Object> loadLimits) {
		this.cacheName = cacheName;
		this.batchSize = batchSize;
		this.loadLimits = loadLimits;
	}

	/**
	 * Executes the operation that loads data form the DB and stores it in a cache.
	 */
	@Override
	public void run() {
        try {
			/* If there is no exception in this call and the task completes normally, 
			 * InvocationObserver.memberCompleted() will trigger. If there is any
			 * exception, InvocationObserver.memberFailed() will trigger */
        	LOGGER.info("Loading the range: {}", this.loadLimits);
        	// Calls the BackEndService of the JVM where this code is executing
			BackEndService.loadToCache(this.cacheName, this.batchSize, this.loadLimits);
			this.successfulyExecuted = true;
        	setResult(this);
        	LOGGER.info("Successfully loaded the range: {}", this.loadLimits);
        } catch (Throwable t) { // Any exception will signal that the node has failed
        	// One will signal that member has failed with exception (LoadObserver.memberCompleted())
        	this.successfulyExecuted = false;
        	setResult(this);
        	LOGGER.info("Failed loading the range: {}", this.loadLimits);
        	// No need for LOGGER.error here because there are retries.
        	LOGGER.warn("Exception when loading the range {}: {}", this.loadLimits, t);
        }
	}

	/**
     * This will return the result of loading (success or failure) and the respective
     * {@link NodeLoadLimits} accessible in case on {@link LoadObserver}.memberFailed().
     */
    @Override
    protected void setResult(Object result) {
    	super.setResult(result);
    }

	public NodeLoadLimits<Object> getLoadLimits() {
		return this.loadLimits;
	}
	
	public boolean isSuccessfulyExecuted() {
		return this.successfulyExecuted;
	}


//	public Member getMember() {
//		return this.member;
//	}
//	
//	public void setMember(Member member) {
//		this.member = member;
//	}

	// ###### Object methods ######
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NodeLoadTask other = (NodeLoadTask) obj;
		if (batchSize != other.batchSize)
			return false;
		if (cacheName == null) {
			if (other.cacheName != null)
				return false;
		} else if (!cacheName.equals(other.cacheName))
			return false;
		if (loadLimits == null) {
			if (other.loadLimits != null)
				return false;
		} else if (!loadLimits.equals(other.loadLimits))
			return false;
		return true;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + batchSize;
		result = prime * result
				+ ((cacheName == null) ? 0 : cacheName.hashCode());
		result = prime * result
				+ ((loadLimits == null) ? 0 : loadLimits.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "NodeLoadTask [batchSize = " + batchSize + ", loadLimits = "
				+ loadLimits + "]";
	}
}