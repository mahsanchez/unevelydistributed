package es.acme.coherence.index.utils;

import java.util.Collection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.oracle.coherence.common.events.dispatching.EventDispatcher;
import com.oracle.coherence.common.events.lifecycle.NamedCacheStorageRealizedEvent;
import com.oracle.coherence.common.events.processing.EventProcessor;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

import es.acme.coherence.index.bean.IndexDefinition;


public class IndexManager implements EventProcessor<NamedCacheStorageRealizedEvent> {

    private static Log LOG = LogFactory.getLog(IndexManager.class);

    private Collection<IndexDefinition> mListIndexDefinition;

    /**
     * 
     * @param pIndexDefinitions
     */
    public IndexManager(Collection<IndexDefinition> pIndexDefinitions) {
        mListIndexDefinition = pIndexDefinitions;
    }

    /**
     * 
     * @param pIndexDefinitions
     */
    public void createIndexes(Collection<IndexDefinition> pIndexDefinitions) {
        if (pIndexDefinitions != null && pIndexDefinitions.size() > 0) {
            for (IndexDefinition indexDefinition : pIndexDefinitions) {
                if (indexDefinition != null) {
                    if (indexDefinition.getCacheName() != null && !"".equals(indexDefinition.getCacheName())) {
                        NamedCache cache = CacheFactory.getCache(indexDefinition.getCacheName());
                        CacheFactory.log("Adding index " + indexDefinition.getMethodName() + " to cache [" + indexDefinition.getCacheName() + "]");
                        cache.addIndex(indexDefinition.getExtractor(), indexDefinition.isOrdered(), indexDefinition.getComparator());
                    }
                }
            }
        }
    }

    /**
     * 
     * @param pEventDispatcher
     * @param pEvent
     */
    @Override
    public void process(EventDispatcher pEventDispatcher,
                        final NamedCacheStorageRealizedEvent pEvent) {
        if (pEvent instanceof NamedCacheStorageRealizedEvent) {
            ExecutorService exec = Executors.newSingleThreadExecutor();
            exec.execute(new Runnable() {
                @Override
                public void run() {
                    createIndexes(mListIndexDefinition);
                }
            });
        }
    }
}

