package es.acme.coherence.index.utils;

import com.oracle.coherence.common.events.lifecycle.LifecycleEvent;
import com.oracle.coherence.common.events.lifecycle.NamedCacheStorageRealizedEvent;
import com.tangosol.util.Filter;



public class NamedCacheStorageRealizedEventFilter implements Filter {
	public static final NamedCacheStorageRealizedEventFilter INSTANCE = new NamedCacheStorageRealizedEventFilter();

	public boolean evaluate(Object object) {
		return (object != null)
				&& ((object instanceof NamedCacheStorageRealizedEvent));
	}
}