package es.acme.coherence.index.schemes.namespace;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.oracle.coherence.common.events.dispatching.EventDispatcher;
import com.oracle.coherence.environment.extensible.ConfigurationContext;
import com.oracle.coherence.environment.extensible.ConfigurationException;
import com.oracle.coherence.environment.extensible.ElementContentHandler;
import com.oracle.coherence.environment.extensible.NamespaceContentHandler;
import com.oracle.coherence.environment.extensible.QualifiedName;
import com.tangosol.net.CacheFactory;
import com.tangosol.run.xml.XmlElement;

import es.acme.coherence.index.bean.IndexDefinition;
import es.acme.coherence.index.utils.IndexManager;
import es.acme.coherence.index.utils.NamedCacheStorageRealizedEventFilter;

/**
 * This class is responsible for reading the decarations of index settings in the cache-config.xml
 * 
 * @author JFG
 */
public class ListenerIndexNamespaceContentHandler implements NamespaceContentHandler, ElementContentHandler {

    /**
     * 
     * @param pContext
     * @param the pPrefix
     * @param the pUri
     */
    public void onStartScope(ConfigurationContext pContext,
                             String pPrefix,
                             URI pUri) {
        CacheFactory.log("ListenerIndexspaceContentHandler.onStartScope", CacheFactory.LOG_DEBUG);

    }

    /**
     * 
     * @param pContext
     * @param prefix
     * @param uri
     */
    public void onEndScope(ConfigurationContext pContext,
                           String pPrefix,
                           URI pUri) {
    }

    /**
     * 
     * @param pContext
     * @param pQualifiedName
     * @param pXmlElement
     * @throws ConfigurationException
     * @return the object
     */
    public Object onElement(ConfigurationContext pContext,
                            QualifiedName pQualifiedName,
                            XmlElement pXmlElement)
        throws ConfigurationException {

        if (pQualifiedName.getLocalName().equals("indexes")) {
            CacheFactory.log("Parsing the indexes", CacheFactory.LOG_DEBUG);

            List<IndexDefinition> listIndexDefinition = new ArrayList<IndexDefinition>();
            if (pXmlElement != null) {
                for (Iterator<?> ite1 = pXmlElement.getElementList().iterator(); ite1.hasNext();) {
                    XmlElement xmlElementChild = (XmlElement) ite1.next();
                    if ("indexesConfig:cache".equals(xmlElementChild.getName())) {
                        IndexDefinition indexDefinition = new IndexDefinition();
                        for (Iterator<?> ite2 = xmlElementChild.getElementList().iterator(); ite2.hasNext();) {
                            XmlElement xmlElementChild2 = (XmlElement) ite2.next();
                            String nameNode = xmlElementChild2.getName();
                            if ("indexesConfig:name".equals(nameNode)) {
                                indexDefinition.setCacheName((String) xmlElementChild2.getValue());
                            }
                            else if ("indexesConfig:methodlist".equals(nameNode)) {
                                for (Iterator<?> ite3 = xmlElementChild2.getElementList().iterator(); ite3.hasNext();) {
                                    XmlElement xmlElementChild3 = (XmlElement) ite3.next();
                                    String nameNode1 = xmlElementChild3.getName();
                                    if ("indexesConfig:index".equals(nameNode1)) {
                                        for (Iterator<?> ite4 = xmlElementChild3.getElementList().iterator(); ite4.hasNext();) {
                                            XmlElement xmlElementChild4 = (XmlElement) ite4.next();
                                            String nameNode4 = xmlElementChild4.getName();
                                            if ("indexesConfig:methodName".equals(nameNode4)) {
                                                indexDefinition.setMethodName(((String) xmlElementChild4.getValue()));
                                            }
                                            else if ("indexesConfig:ordered".equals(nameNode4)) {
                                                String orderedAux = (String) xmlElementChild4.getValue();
                                                if (orderedAux == null || "".equals(orderedAux) || "false".equals(orderedAux) || "null".equals(orderedAux))
                                                    indexDefinition.setOrdered(false);
                                                else
                                                    indexDefinition.setOrdered(true);
                                            }
                                            else if ("indexesConfig:extractor".equals(nameNode4)) {
                                                try {
                                                    indexDefinition.setExtractor(((String) xmlElementChild4.getValue()), indexDefinition.getMethodName());
                                                }
                                                catch (Exception e) {
                                                    throw new ConfigurationException("Error to extractor definition", "ERROR");
                                                }
                                            }
                                            else if ("indexesConfig:comparator".equals(nameNode4)) {
                                                try {
                                                    indexDefinition.setComparator(((String) xmlElementChild4.getValue()), indexDefinition.getMethodName());
                                                }
                                                catch (Exception e) {
                                                    throw new ConfigurationException("Error to comparator definition", "ERROR");
                                                }
                                            }
                                        }
                                        listIndexDefinition.add(indexDefinition);
                                    }
                                }
                            }
                            else {
                                // Error, expected another Stickers
                                throw new ConfigurationException("Expected one valid label for indexedesConfig scheme", "ERROR");
                            }
                        }
                    }
                    else {
                        // Error, the listener tag is expected.
                        throw new ConfigurationException("Expected a label listenerJob:class-listener and found a label " + xmlElementChild.getName(), "ERROR");
                    }
                }
            }
            try {
                createIndexes(pContext, listIndexDefinition);
            }
            catch (Exception e) {
                throw new ConfigurationException("Error creating indexes " + e.getMessage(), "ERROR");
            }
        }
        return null;
    }

    /**
     * 
     * @param pIndexDefinition
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws IllegalArgumentException
     * @throws InvocationTargetException
     * @throws NoSuchMethodException
     * @throws SecurityException
     * @throws ClassNotFoundException
     */
    private void createIndexes(ConfigurationContext pContext,
                               List<IndexDefinition> pListIndexDefinition)
        throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException {

        CacheFactory.log("Register the Event for Index Processor", CacheFactory.LOG_DEBUG);

        EventDispatcher eventDispatcher = pContext.getEnvironment().getResource(EventDispatcher.class);
        eventDispatcher.registerEventProcessor(NamedCacheStorageRealizedEventFilter.INSTANCE, new IndexManager(pListIndexDefinition));

    }
}

