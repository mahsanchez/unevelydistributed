package com.oracle.coherence.singlehop;

import com.oracle.common.internal.net.MultiplexedSocketProvider;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.ExtensibleConfigurableCacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.net.cache.ContinuousQueryCache;
import com.tangosol.net.cache.WrapperNamedCache;

import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.run.xml.XmlHelper;

import com.tangosol.util.ExternalizableHelper;
import com.tangosol.util.SafeHashMap;
import com.tangosol.util.filter.AlwaysFilter;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * A NamedCache implementation that routes key based requests directly to the
 * proxy service running on the same JVM as the owner of that data. The implementation
 * assumes that each storage node has a proxy service running and that the server-
 * side uses an appropriate namespace such as:
 *    xmlns:hop="class://com.oracle.coherence.singlehop.config.SingleHopNamespaceHandler"
 * <p>
 * The namespace wires together sufficient supporting artifacts to ensure a cache
 * of partition-id -&gt; ProxyEndPoint is kept in-sync with the current state of
 * partition assignments. This routing table allows the RoutingNamedCache to
 * be aware of the proxy server end point (host:port) that can be connected to
 * directly and the request be served locally.
 * <p>
 * The RoutingNamedCache also works with the name service and with the proxy
 * service using sub-ports.
 *
 * @author hr/dr
 */
public class RoutingNamedCache
        extends WrapperNamedCache
        implements SingleHopConstants
    {
    // ----- constructors ---------------------------------------------------

    /**
     * Construct a RoutingNamedCache with the provided 'real' cache name.
     *
     * @param sCacheName  the name of the 'real' cache
     */
    public RoutingNamedCache(String sCacheName)
        {
        this(CacheFactory.getCache(sCacheName));
        }

    /**
     * Construct a RoutingNamedCache with the provided 'real' cache.
     *
     * @param cacheReal  the 'real' cache
     */
    public RoutingNamedCache(NamedCache cacheReal)
        {
        super(cacheReal, cacheReal.getCacheName());

        init();
        }

    // ----- NamedCache methods ---------------------------------------------

    @Override
    public Object get(Object oKey)
        {
        try
            {
            return ensureNamedCache(oKey).get(oKey);
            }
        catch (Throwable e)
            {
            err(e);
            return super.get(oKey);
            }
        }

    @Override
    public Object put(Object oKey, Object oValue)
        {
        try
            {
            return ensureNamedCache(oKey).put(oKey, oValue);
            }
        catch (Throwable e)
            {
            err(e);
            return super.put(oKey, oValue);
            }
        }

    @Override
    public Object put(Object oKey, Object oValue, long cMillis)
        {
        try
            {
            return ensureNamedCache(oKey).put(oKey, oValue, cMillis);
            }
        catch (Throwable e)
            {
            err(e);
            return super.put(oKey, oValue, cMillis);
            }
        }

    @Override
    public Object remove(Object oKey)
        {
        try
            {
            return ensureNamedCache(oKey).remove(oKey);
            }
        catch (Throwable e)
            {
            return super.remove(oKey);
            }
        }

    @Override
    public Object invoke(Object oKey, EntryProcessor agent)
        {
        try
            {
            return ensureNamedCache(oKey).invoke(oKey, agent);
            }
        catch (Exception e)
            {
            err(e);
            return super.invoke(oKey, agent);
            }
        }

    // ----- helper methods -------------------------------------------------

    /**
     * Initialize routing cache.
     */
    protected void init()
        {
        m_cacheRoutes = new ContinuousQueryCache(CacheFactory.getCache(getCacheName() + PARTITION_ROUTING_CACHE_NAME),
                AlwaysFilter.INSTANCE, true);
        }

    /**
     * Ensure a NamedCache that is backed by a remote connection to the owner
     * of the given key.
     *
     * @param oKey  the key the request will be targeted to
     *
     * @return a NamedCache that is backed by a remote connection to the owner
     *         of the given key
     */
    protected NamedCache ensureNamedCache(Object oKey)
        {
        Map<Integer, String> mapRoutes = m_cacheRoutes;

        int nPartition = ExternalizableHelper.toBinary(oKey, getCacheService().getSerializer())
                .calculateNaturalPartition(mapRoutes.size());

        return ensureConnection(mapRoutes.get(nPartition));
        }

    /**
     * Ensure a connection to the given end point.
     *
     * @param sEndPoint  the endpoint (proxy-host:proxy-port) the request will
     *                   be targeted to
     *
     * @return a NamedCache that is backed by a remote connection to the owner
     *         of the given key
     */
    protected NamedCache ensureConnection(String sEndPoint)
        {
        Map        mapConnections = m_mapConnections;
        NamedCache cache          = (NamedCache) mapConnections.get(sEndPoint);

        if (cache == null)
            {
            String[] asAddr = sEndPoint.split(":");
            assert asAddr.length == 2;

            String  sAddr     = asAddr[0];
            int     nPort     = Integer.valueOf(asAddr[1]);
            boolean fExtended = MultiplexedSocketProvider.isPortExtended(nPort);

            ExtensibleConfigurableCacheFactory eccf;

            XmlElement xmlFactory = CacheFactory.getConfigurableCacheFactoryConfig();
            Object []  aoParam    = XmlHelper.parseInitParams(xmlFactory.getSafeElement("init-params"));
            String     sURI       = aoParam.length > 0 && aoParam[0] instanceof String
                                    ? (String) aoParam[0] : ExtensibleConfigurableCacheFactory.FILE_CFG_CACHE;

            XmlElement xmlConfig = XmlHelper.loadFileOrResource(sURI, "default cache configuration");

            // change the service name to ensure a unique service name per connection;
            // in addition add a proxy-service-name allowing the name service to function
            XmlElement xmlRemote    = xmlConfig.findElement("caching-schemes/remote-cache-scheme");
            List       listElements = xmlRemote.getElementList();

            for (int i = 0; i < listElements.size(); i++)
                {
                XmlElement xmlServiceName = (XmlElement) listElements.get(i);
                if ("service-name".equals(xmlServiceName.getName()))
                    {
                    listElements.add(i + 1, new SimpleElement("proxy-service-name", xmlServiceName.getValue()));
                    xmlServiceName.setString(xmlServiceName.getString() + "-" + sAddr + ":" + nPort);
                    break;
                    }
                }

            XmlElement xmlAddr = xmlRemote.findElement("initiator-config/tcp-initiator/remote-addresses");
            if (xmlAddr == null)
                {
                xmlAddr = xmlRemote.findElement("initiator-config/tcp-initiator/name-service-addresses");
                }

            assert xmlAddr != null;

            xmlAddr.getElementList().clear();

            // this is an extended port - use name service and base port number
            if (fExtended)
                {
                xmlAddr.setName("name-service-addresses");
                nPort = MultiplexedSocketProvider.getBasePort(nPort);
                }
            else
                {
                xmlAddr.setName("remote-addresses");
                }

            XmlElement xmlSocket = xmlAddr.addElement("socket-address");

            xmlSocket.addElement("address").setString(sAddr);
            xmlSocket.addElement("port").setInt(nPort);

            ExtensibleConfigurableCacheFactory.Dependencies dependencies
                    = ExtensibleConfigurableCacheFactory.DependenciesHelper.newInstance(xmlConfig);

            eccf = new ExtensibleConfigurableCacheFactory(dependencies);

            cache = eccf.ensureCache(getCacheName(), null);

            mapConnections.put(sEndPoint, cache);

            // something changed - clean up inactive connections
            purgeConnections();
            }
        return cache;
        }

    /**
     * Remove any inactive connections from the local registry.
     */
    protected void purgeConnections()
        {
        for (Iterator iter = m_mapConnections.values().iterator(); iter.hasNext(); )
            {
            NamedCache connection = (NamedCache) iter.next();
            if (!connection.isActive())
                {
                connection.release();
                iter.remove();
                }
            }
        }

    // ----- data members ---------------------------------------------------

    /**
     * A map of connections (end point -&gt; NamedCache).
     */
    protected Map<Integer, String> m_cacheRoutes;

    /**
     * A ContinuousQueryCache of routes (partition-id -&gt; end point).
     */
    protected Map                  m_mapConnections = new SafeHashMap();
    }
