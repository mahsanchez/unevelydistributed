package com.oracle.coherence.singlehop;

import com.tangosol.io.ClassLoaderAware;
import com.tangosol.net.CacheService;
import com.tangosol.net.NamedCache;
import com.tangosol.net.WrapperCacheService;
import com.tangosol.util.NullImplementation;

/**
 * This {@link CacheService} allows synthetic caches (not defined in the cache
 * configuration) to be realized based on a cache name conforming to a certain
 * syntax. This syntax should take the form below:
 * <pre><code>
 *     REAL_CACHE_NAME$SYNTHETIC_CACHE_NAME
 * </code></pre>
 * The {@code REAL_CACHE_NAME} acts as a locator to find the correct service
 * to ensure the synthetic cache. This implementation assumes that the provided
 * CacheService is capable of using a CCF, or some other mechanism, to locate
 * the correct service.
 *
 * @author hr/jk
 */
public class SingleHopCacheServiceProxy
        extends WrapperCacheService
    {
    // ----- constructors ---------------------------------------------------

    /**
     * Create a SingleHopCacheServiceProxy that wraps the specified
     * {@link CacheService}.
     *
     * @param service  the CacheService being wrapped
     */
    public SingleHopCacheServiceProxy(CacheService service)
        {
        super(service);
        }

    // ----- WrapperCacheService methods ------------------------------------

    @Override
    public NamedCache ensureCache(String sName, ClassLoader loader)
        {
        int iDelim = sName.lastIndexOf('$');
        if (iDelim >= 0)
            {
            String sRealName = sName.substring(0, iDelim);

            // assume that the provided CacheService is a 'proxy' that is capable
            // of finding the appropriate service via a CCF using the real cache name
            NamedCache cache = super.ensureCache(sRealName, loader);

            // this CacheService is expected to be a CacheServiceProxy used by
            // the ProxyService; the proxy generally operates in a pass-through
            // mode skipping unnecessary deserialization and serialization, hence
            // we attempt to use the same class loader as the NamedCache; in the
            // rare instance of a non-ClassLoaderAware NamedCache we assume the
            // serializer for the proxy and PartitionedService are the same

            loader = cache instanceof ClassLoaderAware
                    ? ((ClassLoaderAware) cache).getContextClassLoader()
                    : NullImplementation.getClassLoader();

            return cache.getCacheService().ensureCache(sName.substring(iDelim), loader);
            }

        return super.ensureCache(sName, loader);
        }
    }
