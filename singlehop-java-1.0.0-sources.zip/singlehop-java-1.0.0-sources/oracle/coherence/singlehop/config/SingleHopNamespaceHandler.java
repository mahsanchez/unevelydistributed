package com.oracle.coherence.singlehop.config;

import com.oracle.coherence.singlehop.SingleHopConstants;

import com.tangosol.coherence.config.CacheConfig;
import com.tangosol.coherence.config.CacheMapping;
import com.tangosol.coherence.config.CacheMappingRegistry;
import com.tangosol.coherence.config.ServiceSchemeRegistry;
import com.tangosol.coherence.config.scheme.BackingMapScheme;
import com.tangosol.coherence.config.scheme.DistributedScheme;
import com.tangosol.coherence.config.scheme.LocalScheme;

import com.tangosol.config.ConfigurationException;
import com.tangosol.config.xml.AbstractNamespaceHandler;
import com.tangosol.config.xml.DocumentElementPreprocessor;
import com.tangosol.config.xml.ElementProcessor;
import com.tangosol.config.xml.ProcessingContext;

import com.tangosol.run.xml.XmlElement;

import java.net.URI;

/**
 * An implementation of a {@link com.tangosol.config.xml.NamespaceHandler} that
 * adds configuration for the Coherence Single Hop functionality.
 *
 * @author jk 2014.11.11
 */
public class SingleHopNamespaceHandler
        extends AbstractNamespaceHandler
        implements SingleHopConstants
    {
    // ----- constructors ---------------------------------------------------

    public SingleHopNamespaceHandler()
        {
        DocumentElementPreprocessor dep = new DocumentElementPreprocessor();
        dep.addElementPreprocessor(new SingleHopElementPreprocessor());

        registerProcessor(XML_ELEMENT_ENABLED, new HopElementProcessor());
        registerProcessor(XML_ELEMENT_PROXY_SERVICE, new HopElementProcessor());

        setDocumentPreprocessor(dep);
        }

    // ----- AbstractNamespaceHandler methods -------------------------------

    @Override
    public void onStartNamespace(ProcessingContext context, XmlElement element, String sPrefix, URI uri)
        {
        super.onStartNamespace(context, element, sPrefix, uri);
        m_sPrefix = sPrefix;
        }

    @Override
    public void onEndNamespace(ProcessingContext context, XmlElement element, String prefix, URI uri)
        {
        super.onEndNamespace(context, element, prefix, uri);

        CacheConfig cacheConfig = context.getCookie(CacheConfig.class);
        if (cacheConfig == null)
            {
            throw new ConfigurationException("Can't locate the Coherence Configuration.  This only occurs when the "
                + uri + " namespace is used outside of a Coherence Cache Configuration", "Please ensure that the "
                    + uri + " is defined with in the scope of a Coherence Cache Configuration");
            }

        ServiceSchemeRegistry registryServices      = cacheConfig.getServiceSchemeRegistry();
        CacheMappingRegistry  registryCacheMappings = cacheConfig.getCacheMappingRegistry();
        DistributedScheme     distributedScheme     = new DistributedScheme();
        BackingMapScheme      backingMapScheme      = new BackingMapScheme();
        CacheMapping          mapping               = new CacheMapping(PARTITION_ROUTING_CACHE_NAME,
                                                                       PARTITION_ROUTING_CACHE_SCHEME);

        distributedScheme.setSchemeName(PARTITION_ROUTING_CACHE_SCHEME);
        backingMapScheme.setInnerScheme(new LocalScheme());
        distributedScheme.setBackingMapScheme(backingMapScheme);

        registryCacheMappings.register(mapping);
        registryServices.register(distributedScheme);
        }

    // ----- accessor methods -----------------------------------------------

    /**
     * Return the prefix used for this namespace in the xml configuration.
     *
     * @return the prefix used for this namespace in the xml configuration
     */
    public String getPrefix()
        {
        return m_sPrefix;
        }

    // ----- inner class: EnabledElementProcessor ---------------------------

    public static class HopElementProcessor
            implements ElementProcessor
        {
        // ----- ElementProcessor methods -----------------------------------

        @Override
        public Object process(ProcessingContext processingContext, XmlElement xmlElement)
                throws ConfigurationException
            {
            return null;
            }
        }

    // ----- data members ---------------------------------------------------

    /**
     * The prefix used for this namespace in the xml configuration
     */
    protected String m_sPrefix;
    }
