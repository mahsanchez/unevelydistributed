package com.oracle.coherence.singlehop.config;

import com.oracle.coherence.singlehop.SingleHopConstants;

import com.tangosol.config.ConfigurationException;
import com.tangosol.config.xml.DocumentElementPreprocessor;
import com.tangosol.config.xml.ProcessingContext;

import com.tangosol.run.xml.XmlElement;
import com.tangosol.util.Base;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * An implementation of a {@link DocumentElementPreprocessor.ElementPreprocessor}
 * that will add a partition-listener to each distributed-scheme element that does
 * not contain a scheme-ref element or does contain a service-name element.
 *
 * @author jk 2014.11.11
 */
public class SingleHopElementPreprocessor
        implements DocumentElementPreprocessor.ElementPreprocessor, SingleHopConstants
    {
    public SingleHopElementPreprocessor()
        {
        try
            {
            f_uri = new URI(SINGLE_HOP_NAMESPACE_URI);
            }
        catch (URISyntaxException e)
            {
            throw Base.ensureRuntimeException(e);
            }
        }

    // ----- DocumentElementPreprocessor.ElementPreprocessor methods --------

    @Override
    public boolean preprocess(ProcessingContext context, XmlElement element)
            throws ConfigurationException
        {
        boolean fUpdated = false;

        switch (element.getName())
            {
            case "cache-config" :
                fUpdated = processCacheConfigElement(context, element);
                break;

            case "distributed-scheme" :
                fUpdated = processDistributedSchemeElement(context, element);
                break;

            case "proxy-scheme" :
                fUpdated = processProxyScheme(context, element);
                break;
            }

        return fUpdated;
        }

    // ----- helper methods -------------------------------------------------

    /**
     * Process the cache-configuration element.
     *
     * @param context  the {@link ProcessingContext} in which the pre-processing is occurring
     * @param element  the {@link XmlElement} to pre-process
     *
     * @return  <code>true</code> if the specified {@link XmlElement} has been modified.
     */
    @SuppressWarnings("unchecked")
    protected boolean processCacheConfigElement(ProcessingContext context, XmlElement element)
        {
        boolean                   fUpdated = false;
        SingleHopNamespaceHandler handler  = (SingleHopNamespaceHandler) context.getNamespaceHandler(f_uri);

        m_sPrefix             = handler.getPrefix();
        m_sEnabledElementName = m_sPrefix + ":" + XML_ELEMENT_ENABLED;
        m_sProxyElementName   = m_sPrefix + ":" + XML_ELEMENT_PROXY_SERVICE;

        XmlElement xmlDefault = element.getSafeElement("defaults");
        XmlElement xmlEnabled = xmlDefault.getElement(m_sEnabledElementName);

        m_fDefaultEnabled          = xmlEnabled == null || xmlEnabled.getBoolean();
        m_sDefaultProxyServiceName = getDefaultProxyServiceName(element, m_sProxyElementName);

        if (m_sDefaultProxyServiceName == null)
            {
            m_sDefaultProxyServiceName = SINGLE_HOP_PROXY_SERVICE_NAME;

            XmlElement xmlSchemes = element.getElement("caching-schemes");

            if (xmlSchemes == null)
                {
                xmlSchemes = element.addElement("caching-schemes");
                }

            XmlElement xmlProxy = xmlSchemes.addElement("proxy-scheme");

            xmlProxy.addElement("scheme-name").setString(m_sDefaultProxyServiceName + "-scheme");
            xmlProxy.addElement("service-name").setString(m_sDefaultProxyServiceName);
            xmlProxy.addElement("acceptor-config").addElement("tcp-acceptor");
            fUpdated = true;
            }

        XmlElement xmlSchemes = element.getElement("caching-schemes");
        if (xmlSchemes != null)
            {
            for (XmlElement child : (List<XmlElement>) xmlSchemes.getElementList())
                {
                if ("distributed-scheme".equals(child.getName()))
                    {
                    XmlElement xmlProxy = child.getElement(m_sProxyElementName);
                    if (xmlProxy != null)
                        {
                        f_setProxyServices.add(xmlProxy.getString());
                        }
                    }
                }
            }
        return fUpdated;
        }

    /**
     * Process a distributed-scheme element.
     *
     * @param context  the {@link ProcessingContext} in which the pre-processing is occurring
     * @param element  the {@link XmlElement} to pre-process
     *
     * @return  <code>true</code> if the specified {@link XmlElement} has been modified.
     */
    protected boolean processDistributedSchemeElement(ProcessingContext context, XmlElement element)
        {
        boolean    fUpdated    = false;
        XmlElement xmlService  = element.getElement("service-name");
        XmlElement xmlRef      = element.getElement("scheme-ref");
        XmlElement xmlListener = element.getElement("partition-listener");

        if (xmlService == null || xmlRef != null || xmlListener != null)
            {
            return false;
            }

        boolean fEnabled = element.getSafeElement(m_sEnabledElementName).getBoolean(m_fDefaultEnabled);

        if (fEnabled)
            {
            xmlListener = element.addElement("partition-listener");

            XmlElement xmlInstance = xmlListener.addElement("instance");

            xmlInstance.addElement("class-name").setString(LISTENER_CLASS);

            XmlElement xmlParams     = xmlInstance.addElement("init-params");
            XmlElement xmlProxyParam = xmlParams.addElement("init-param");

            xmlProxyParam.addElement("param-type").setString("java.lang.String");

            XmlElement xmlProxyElement = element.getSafeElement(m_sProxyElementName);

            String     sProxyName      = xmlProxyElement.getString(m_sDefaultProxyServiceName);

            xmlProxyParam.addElement("param-value").setString(sProxyName);
            f_setProxyServices.add(sProxyName);

            fUpdated = true;
            }

        return fUpdated;
        }

    /**
     * Process a proxy-scheme element.
     *
     * @param context  the {@link ProcessingContext} in which the pre-processing is occurring
     * @param element  the {@link XmlElement} to pre-process
     *
     * @return  <code>true</code> if the specified {@link XmlElement} has been modified.
     */
    protected boolean processProxyScheme(ProcessingContext context, XmlElement element)
        {
        String sName = element.getSafeElement("service-name").getString("");

        if (!f_setProxyServices.contains(sName))
            {
            return false;
            }

        boolean    fUpdated        = false;
        XmlElement xmlLoadBalancer = element.getElement("load-balancer");

        if (xmlLoadBalancer == null)
            {
            xmlLoadBalancer = element.addElement("load-balancer");
            }

        if (!"client".equalsIgnoreCase(xmlLoadBalancer.getString()))
            {
            xmlLoadBalancer.setString("client");
            fUpdated = true;
            }

        XmlElement xmlProxyConfig = element.getElement("proxy-config");

        if (xmlProxyConfig == null)
            {
            xmlProxyConfig = element.addElement("proxy-config");
            }

        XmlElement xmlCacheService = xmlProxyConfig.getElement("cache-service-proxy");

        if (xmlCacheService == null)
            {
            xmlCacheService = xmlProxyConfig.addElement("cache-service-proxy");
            }

        XmlElement xmlClassName = xmlCacheService.getElement("class-name");

        if (xmlClassName == null)
            {
            xmlCacheService.addElement("class-name").setString(CACHE_SERVICE_PROXY_CLASS);
            }
        else if (!CACHE_SERVICE_PROXY_CLASS.equals(xmlClassName.getString()))
            {
            throw new ConfigurationException("Single Hop cannot be used with a proxy-scheme that has a "
                                             + "cache-service-proxy that is not a "
                                             + CACHE_SERVICE_PROXY_CLASS, "Remove the cache-service-proxy from\n"
                                                 + element);
            }

        return fUpdated;
        }

    /**
     * Obtain the name of the proxy service to use for single hop functionality.
     *
     * @param element  the cache-configuration XML element
     * @param sProxy   then qualified name of the proxy-service element
     *
     * @return the name of the proxy service to use or null if no proxy is configured
     */
    protected String getDefaultProxyServiceName(XmlElement element, String sProxy)
        {
        XmlElement xmlDefault        = element.getElement("defaults");
        XmlElement xmlSchemes        = element.findElement("caching-schemes");
        XmlElement xmlProxy          = xmlDefault != null
                                       ? xmlDefault.getElement(sProxy)
                                       : null;

        String     sDefaultProxyName = null;

        if (xmlProxy == null)
            {
            XmlElement xmlProxyScheme = xmlSchemes != null
                                        ? xmlSchemes.findElement("proxy-scheme")
                                        : null;

            if (xmlProxyScheme != null)
                {
                sDefaultProxyName = xmlProxyScheme.getSafeElement("service-name").getString();

                if (sDefaultProxyName == null || sDefaultProxyName.isEmpty())
                    {
                    throw new ConfigurationException("Proxy service name cannot be blank",
                                                     "Set a value for the service-name element in\n" + xmlProxyScheme);
                    }
                }
            }
        else
            {
            sDefaultProxyName = xmlProxy.getString();

            if (sDefaultProxyName == null || sDefaultProxyName.isEmpty())
                {
                throw new ConfigurationException("Proxy service name cannot be blank",
                                                 "Set a value for the " + sProxy + " element in\n" + xmlDefault);
                }
            }

        return sDefaultProxyName;
        }

    // ----- data members ---------------------------------------------------

    /**
     * The URI of the Single Hop namespace.
     */
    protected final URI f_uri;

    /**
     * The prefix assigned to the namespace in the cache configuration.
     */
    protected String m_sPrefix;

    /**
     * The fully qualified name of the enabled XML element.
     */
    protected String m_sEnabledElementName;

    /**
     * The fully qualified name of the proxy service element.
     */
    protected String m_sProxyElementName;

    /**
     * The name of the default proxy service to be used.
     */
    protected String m_sDefaultProxyServiceName;

    /**
     * Flag to determine whether single hop is enabled or disabled by default.
     */
    protected boolean m_fDefaultEnabled;

    /**
     * A set of proxy service names that should be configured for use by single hop.
     */
    protected final Set<String> f_setProxyServices = new HashSet<>();
    }
