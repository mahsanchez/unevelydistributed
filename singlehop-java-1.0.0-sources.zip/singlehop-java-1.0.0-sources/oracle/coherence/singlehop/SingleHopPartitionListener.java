package com.oracle.coherence.singlehop;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.Cluster;
import com.tangosol.net.DistributedCacheService;
import com.tangosol.net.Member;
import com.tangosol.net.NameService;
import com.tangosol.net.NamedCache;
import com.tangosol.net.Service;

import com.tangosol.net.partition.PartitionEvent;
import com.tangosol.net.partition.PartitionListener;
import com.tangosol.net.partition.PartitionSet;

import com.tangosol.util.Base;

import java.util.HashMap;
import java.util.Map;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import javax.naming.NamingException;

/**
 * A {@link PartitionListener} implementation that ensures a routing cache (
 * {@code '$route'}) is kept in sync with partition assignments. This allows
 * others to query the routing cache to determine a proxy endpoint for a given
 * partition.
 *
 * @author hr/jk
 */
public class SingleHopPartitionListener
        implements PartitionListener, SingleHopConstants
    {
    // ----- constructors ---------------------------------------------------

    /**
     * Construct a new SingleHopPartitionListener that will assign the
     * listen address of the specified proxy service to the partitions
     * owned by the service that this listener is listening to.
     *
     * @param sProxyServiceName  the proxy service to assign to partitions
     *                           in the partition table
     */
    public SingleHopPartitionListener(String sProxyServiceName)
        {
        this(sProxyServiceName, Executors.newSingleThreadExecutor(
                new ThreadFactory()
                    {
                    public Thread newThread(Runnable r)
                        {
                        Thread t = Base.makeThread(null, r, "RoutingTableUpdater");
                        t.setDaemon(true);
                        return t;
                        }
                    }));
        }

    /**
     * This constructor is used for testing to allow the executor to be injected.
     *
     * @param sProxyServiceName  the proxy service to assign to partitions
     *                           in the partition table
     * @param executor           the executor to use to submit the update runnable
     */
    public SingleHopPartitionListener(String sProxyServiceName, ExecutorService executor)
        {
        f_sProxyServiceName = sProxyServiceName;
        f_executor          = executor;
        }

    // ----- PartitionListener methods --------------------------------------

    @Override
    public void onPartitionEvent(PartitionEvent evt)
        {
        switch (evt.getId())
            {
            case PartitionEvent.PARTITION_ASSIGNED:
            case PartitionEvent.PARTITION_RECEIVE_COMMIT:
            case PartitionEvent.PARTITION_RECOVERED:

                if (evt.getPartitionSet().contains(0))
                    {
                    CacheFactory.log("Partition 0 has moved: " + evt);
                    }
                f_executor.submit(instantiateTableUpdater(
                        (DistributedCacheService) evt.getService(),
                        evt.getPartitionSet()));
                break;
            }
        }

    // ----- accessor methods -----------------------------------------------

    /**
     * Return the name of the proxy service that will have its connection endpoint
     * stored in the route cache.
     *
     * @return the name of the proxy service that will have its connection endpoint
     *         stored in the route cache
     */
    public String getProxyServiceName()
        {
        return f_sProxyServiceName;
        }

    // ----- helper methods -------------------------------------------------

    /**
     * Return a new instance of a {@link PartitionTableUpdate} that will operate
     * against the given service and partition set.
     *
     * @param service  the service that should have its routing table updated
     * @param parts    the partition set being updated
     *
     * @return a new instance of a {@link PartitionTableUpdate} that will operate
     *         against the given service and partition set
     */
    protected PartitionTableUpdate instantiateTableUpdater(DistributedCacheService service, PartitionSet parts)
        {
        return new PartitionTableUpdate(service, parts);
        }

    // ----- inner class: PartitionTableUpdate ------------------------------

    /**
     * A Runnable that can asynchronously update the routing table for the
     * given service.
     */
    protected class PartitionTableUpdate
            implements Runnable
        {
        // ----- constructors -----------------------------------------------

        /**
         * Construct a PartitionTableUpdate for the given service and partition
         * set.
         *
         * @param service  the service that should have its routing table updated
         * @param parts    the partition set that should be updated
         */
        public PartitionTableUpdate(DistributedCacheService service, PartitionSet parts)
            {
            f_service = service;
            f_parts   = parts;
            }

        // ----- Runnable methods -------------------------------------------

        @Override
        public void run()
            {
            try
                {
                Cluster    cluster      = f_service.getCluster();
                Member     memberLocal  = cluster.getLocalMember();
                NamedCache cache        = f_service.ensureCache(PARTITION_ROUTING_CACHE_NAME,
                        f_service.getContextClassLoader());
                Service    serviceProxy = getProxyService();

                while (!serviceProxy.isRunning())
                    {
                    try
                        {
                        Thread.sleep(100);
                        }
                    catch (InterruptedException e)
                        {
                        // ignore
                        }
                    }

                NameService          nameService = cluster.getResourceRegistry().getResource(NameService.class);
                Object[]             aoProxy     = (Object[]) nameService.lookup(f_sProxyServiceName);
                String               sAddress    = aoProxy[0] + ":" + aoProxy[1];
                Map<Integer, String> mapRoutes   = new HashMap<>(f_parts.cardinality());

                for (int nPart = f_parts.next(0); nPart >= 0; nPart = f_parts.next(nPart + 1))
                    {
                    if (memberLocal == f_service.getPartitionOwner(nPart))
                        {
                        if (nPart == 0)
                            {
                            CacheFactory.log(nPart + " being updated to: " + sAddress);
                            }
                        mapRoutes.put(Integer.valueOf(nPart), sAddress);
                        }
                    }

                cache.putAll(mapRoutes);
                }
            catch (NamingException e)
                {
                CacheFactory.log("Error updating partition table", CacheFactory.LOG_ERR);
                CacheFactory.log(e);
                }
            }

        // ----- data members -----------------------------------------------

        /**
         * The set of partitions to update.
         */
        protected final PartitionSet f_parts;

        /**
         * The service that should have its routing table updated.
         */
        protected final DistributedCacheService f_service;
        }

    // ----- helper methods -------------------------------------------------

    /**
     * Return the proxy service.
     *
     * @return the proxy service
     */
    protected Service getProxyService()
        {
        return CacheFactory.getService(f_sProxyServiceName);
        }

    // ----- data members ---------------------------------------------------

    /**
     * The ExecutorService used to run the {@link PartitionTableUpdate routing
     * table updater} asynchronously.
     */
    protected final ExecutorService f_executor;

    /**
     * The name of the proxy service to be used for end point information in
     * the routing table.
     */
    protected final String f_sProxyServiceName;
    }
