package com.oracle.coherence.singlehop;

import com.oracle.coherence.singlehop.config.SingleHopNamespaceHandler;

/**
 * Constant values used in the Coherence Single
 * Hop functionality.
 *
 * @author jk 2014.11.13
 */
public interface SingleHopConstants
    {
    /**
     * The name of the partition routing information cache.
     */
    public String PARTITION_ROUTING_CACHE_NAME = "$route";

    /**
     * The name of the distributed scheme that will be injected into
     * server side configuration as a dummy mapping for the partition
     * routing information cache.
     */
    public String PARTITION_ROUTING_CACHE_SCHEME = "$route-scheme";

    /**
     * The name of the Proxy Service that will be injected into a server
     * side configuration if no proxy-scheme is configured.
     */
    public String SINGLE_HOP_PROXY_SERVICE_NAME = "$SingleHopProxyService";

    /**
     * The XML element name used to enable or disable single hop functionality
     * for services.
     */
    public String XML_ELEMENT_ENABLED = "enabled";

    /**
     * The XML element name used to specify a proxy service name.
     */
    public String XML_ELEMENT_PROXY_SERVICE = "proxy-service";

    /**
     * The name of the Single Hop namespace handler class.
     */
    public String NAMESPACE_CLASS = SingleHopNamespaceHandler.class.getCanonicalName();

    /**
     * The name of the Single Hop partition listener class.
     */
    public String LISTENER_CLASS = SingleHopPartitionListener.class.getCanonicalName();

    /**
     * The name of the Single Hop CacheServiceProxy class.
     */
    public String CACHE_SERVICE_PROXY_CLASS = SingleHopCacheServiceProxy.class.getCanonicalName();

    /**
     * The URI of the Single Hop Namespace in an XML configuration
     */
    public String SINGLE_HOP_NAMESPACE_URI = "class://" + NAMESPACE_CLASS;
    }
