package org.cohbook.persistence.binarystore;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

public class CoalesceTest {

    @SuppressWarnings("unused")
    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(1)
                .setCacheConfiguration("org/cohbook/persistence/binarystore/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();
    }
    @Test
    public void checkPreviousValue() throws InterruptedException {
        NamedCache cache = CacheFactory.getCache("test");
        cache.put("1", "a");
        cache.put("1", "b");
        
        Thread.sleep(200);
        
        Assert.assertNull(cache.get("1"));
    }
}
