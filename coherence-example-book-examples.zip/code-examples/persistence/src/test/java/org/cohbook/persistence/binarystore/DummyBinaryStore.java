package org.cohbook.persistence.binarystore;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.cache.BinaryEntryStore;
import com.tangosol.util.BinaryEntry;

public class DummyBinaryStore implements BinaryEntryStore {
    
    private static final Logger LOG = LoggerFactory.getLogger(DummyBinaryStore.class);

    private Map<Object,Object> map = new HashMap<>();

    @Override
    public void load(BinaryEntry binaryentry) {
        binaryentry.setValue(map.get(binaryentry.getKey()));
    }

    @Override
    public void loadAll(@SuppressWarnings("rawtypes") Set set) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void store(BinaryEntry binaryentry) {
        LOG.info("key={}, value={}, originalValue={}",
                binaryentry.getKey(), binaryentry.getValue(), binaryentry.getOriginalValue());
        
        map.put(binaryentry.getKey(), binaryentry.getOriginalValue());
    }

    @SuppressWarnings("unchecked")
    @Override
    public void storeAll(@SuppressWarnings("rawtypes") Set set) {
        for (BinaryEntry  binaryentry : (Set<BinaryEntry>) set) {
            store(binaryentry);
        }
    }

    @Override
    public void erase(BinaryEntry binaryentry) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void eraseAll(@SuppressWarnings("rawtypes") Set set) {
        throw new UnsupportedOperationException("not yet implemented");
    }


}
