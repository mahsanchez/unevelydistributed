package org.cohbook.persistence.modelcachestore;

import static org.junit.Assert.assertEquals;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.h2.tools.Server;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.tangosol.net.cache.CacheStore;

public class SpringJdbcCacheStoreTest {

    private static final String DBURL = "jdbc:h2:tcp://localhost/mem:test;DB_CLOSE_DELAY=-1";
    private static final String TABLESQL = "CREATE TABLE EXAMPLE_TABLE ("
            + "KEY VARCHAR(10) NOT NULL PRIMARY KEY,"
            + "VALUE VARCHAR(100) NOT NULL"
            + ");";
    private static final String CLEANSQL = "DELETE FROM EXAMPLE_TABLE";
    private static final String INSERT_STATEMENT = "INSERT INTO EXAMPLE_TABLE VALUES (?, ?);";
    
    private CacheStore cacheStore;
    private JdbcOperations jdbcop;
    
    @SuppressWarnings("unused")
    private static Server h2Server;
    
    @BeforeClass
    public static void setupTable() throws SQLException {
        
        h2Server = Server.createTcpServer().start();
        
        DataSource dataSource = new DriverManagerDataSource(DBURL);
        
        JdbcOperations jdbcop = new JdbcTemplate(dataSource);
        jdbcop.execute(TABLESQL);
    }
    
    @Before
    public void setUp() throws SQLException {
        DataSource dataSource = new DriverManagerDataSource(DBURL);
        
        jdbcop = new JdbcTemplate(dataSource);
        jdbcop.execute(CLEANSQL);
        
        jdbcop.update(INSERT_STATEMENT, "1", "A");
        jdbcop.update(INSERT_STATEMENT, "2", "B");
        jdbcop.update(INSERT_STATEMENT, "3", "C");
        
        cacheStore = new SpringJdbcCacheStore(dataSource);
        
    }
    
    @Test
    public void testLoad() {
        assertEquals("A", cacheStore.load("1"));
    }
    
    @Test
    public void testLoadAll() {
        List<String> keys = new ArrayList<>(2);
        keys.add("1");
        keys.add("2");
        @SuppressWarnings("unchecked")
        Map<String,String> result = cacheStore.loadAll(keys);
        assertEquals(2, result.size());
        assertEquals("A", result.get("1"));
        assertEquals("B", result.get("2"));
    }
    
    @Test
    public void testStoreNew() {
        cacheStore.store("4", "D");
        Map<String,String> expected = new HashMap<>();
        expected.put("1", "A");
        expected.put("2", "B");
        expected.put("3", "C");
        expected.put("4", "D");
        
        assertTableContents(expected);
    }
    
    @Test
    public void testStoreReplace() {
        cacheStore.store("3", "c");
        Map<String,String> expected = new HashMap<>();
        expected.put("1", "A");
        expected.put("2", "B");
        expected.put("3", "c");
        
        assertTableContents(expected);
    }
    
    @Test
    public void testStoreAll() {
        Map<String,String> changes = new HashMap<>();
        changes.put("3", "c");
        changes.put("4", "D");
        cacheStore.storeAll(changes);
        Map<String,String> expected = new HashMap<>();
        expected.put("1", "A");
        expected.put("2", "B");
        expected.put("3", "c");
        expected.put("4", "D");
        
        assertTableContents(expected);
    }
    
    @Test
    public void testErase() {
        cacheStore.erase("2");
        Map<String,String> expected = new HashMap<>();
        expected.put("1", "A");
        expected.put("3", "C");
        
        assertTableContents(expected);
        
    }
    
    @Test
    public void testEraseAll() {
        List<String> keys = new ArrayList<>();
        
        keys.add("1");
        keys.add("3");
        
        cacheStore.eraseAll(keys);

        Map<String,String> expected = new HashMap<>();
        expected.put("2", "B");
        
        assertTableContents(expected);
    }
    private void assertTableContents(Map<String,String> expected) {
        
        final Map<String,String> actual = new HashMap<>();
        jdbcop.query("SELECT * FROM EXAMPLE_TABLE", new RowMapper<Object>() {

            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                actual.put(rs.getString(1), rs.getString(2));
                return null;
            }
        });
        
        assertEquals(expected.size(), actual.size());
        for (Map.Entry<String, String> entry: expected.entrySet()) {
            assertEquals(entry.getValue(), actual.get(entry.getKey()));
        }
        
    }
}
