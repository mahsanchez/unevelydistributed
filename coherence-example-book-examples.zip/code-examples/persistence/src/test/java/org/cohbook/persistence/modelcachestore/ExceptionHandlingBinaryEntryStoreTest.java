package org.cohbook.persistence.modelcachestore;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.NonTransientDataAccessResourceException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.dao.TransientDataAccessResourceException;

import com.tangosol.net.cache.BinaryEntryStore;
import com.tangosol.util.BinaryEntry;


public class ExceptionHandlingBinaryEntryStoreTest {
	
	private Mockery context;
	private BinaryEntryStore delegate;
	private ExceptionHandlingBinaryEntryStore theStore;
    private final Set<Object> nonTransientFailedKeys = new HashSet<>();
	
	@Before
	public void setup() {
		context = new Mockery();
		delegate = context.mock(BinaryEntryStore.class);
		theStore = new ExceptionHandlingBinaryEntryStore(delegate){
            @Override
            protected void handleNonTransientFailure(Object key, Object value,
                    Exception exception) {
                nonTransientFailedKeys.add(key);
                super.handleNonTransientFailure(key, value, exception);
            }
        };
	}
	
	@Test
	public void testStoreOk() {
		
	    final BinaryEntry binaryEntry = context.mock(BinaryEntry.class);
		
		context.checking(new Expectations() {{
			oneOf(delegate).store(binaryEntry);
		}});
		
		theStore.store(binaryEntry);
		
	}
	
	@Test
	public void testStoreOneTransientError() {
		
        final BinaryEntry binaryEntry = context.mock(BinaryEntry.class);
		
		context.checking(new Expectations() {{
            oneOf(delegate).store(binaryEntry);
			will(throwException(new TransientDataAccessResourceException("transient")));
            oneOf(delegate).store(binaryEntry);
		}});
		
        theStore.store(binaryEntry);
		
	}
	
	@Test(expected=TransientDataAccessException.class)
	public void testStoreRepeatedTransientError() {
		
        final BinaryEntry binaryEntry = context.mock(BinaryEntry.class);
		
		context.checking(new Expectations() {{
			atLeast(1).of(delegate).store(binaryEntry);
			will(throwException(new TransientDataAccessResourceException("transient")));
		}});
		
        theStore.store(binaryEntry);
		
	}

	@Test
	public void testStoreNonTransientError() {
		
        final BinaryEntry binaryEntry = context.mock(BinaryEntry.class);
		
		context.checking(new Expectations() {{
		    ignoring(binaryEntry).getKey();
		    ignoring(binaryEntry).getValue();
            oneOf(delegate).store(binaryEntry);
			will(throwException(new NonTransientDataAccessResourceException("not transient")));
		}});
		
        theStore.store(binaryEntry);
		
	}
	
	@Test
	public void testStoreAllOk() {

	    @SuppressWarnings("unchecked")
        final Set<BinaryEntry> set = context.mock(Set.class);
		
		context.checking(new Expectations() {{
			oneOf(delegate).storeAll(set);
		}});
		
		theStore.storeAll(set);
		
	}
	
	@Test
	public void testStoreAllOneTransient() {
		
        @SuppressWarnings("unchecked")
        final Set<BinaryEntry> set = context.mock(Set.class);
		
		context.checking(new Expectations() {{
            oneOf(delegate).storeAll(set);
			will(throwException(new TransientDataAccessResourceException("")));
            oneOf(delegate).storeAll(set);
		}});
		
        theStore.storeAll(set);
		
	}
	
	@Test(expected=TransientDataAccessException.class)
	public void testStoreAllRepeatedTransient() {
		
        @SuppressWarnings("unchecked")
        final Set<BinaryEntry> set = context.mock(Set.class);
        @SuppressWarnings("unchecked")
        final Iterator<BinaryEntry> iter = context.mock(Iterator.class);
        final BinaryEntry bin1 = context.mock(BinaryEntry.class, "bin1");
        final BinaryEntry bin2 = context.mock(BinaryEntry.class, "bin2");
        final BinaryEntry bin3 = context.mock(BinaryEntry.class, "bin3");
        
        context.checking(new Expectations() {{
            allowing(bin2).getKey();
            will(returnValue(2));
            ignoring(bin2).getValue();
            allowing(set).size();
            will(returnValue(3));

            atLeast(1).of(delegate).storeAll(set);
            will(throwException(new TransientDataAccessResourceException("")));

            oneOf(set).iterator();
            will(returnValue(iter));

            oneOf(iter).hasNext();
            will(returnValue(true));
            oneOf(iter).next();
            will(returnValue(bin1));
            oneOf(delegate).store(bin1);
            oneOf(iter).remove();

            oneOf(iter).hasNext();
            will(returnValue(true));
            oneOf(iter).next();
            will(returnValue(bin2));
            atLeast(1).of(delegate).store(bin2);
            will(throwException(new TransientDataAccessResourceException("")));

            oneOf(iter).hasNext();
            will(returnValue(true));
            oneOf(iter).next();
            will(returnValue(bin3));
            oneOf(delegate).store(bin3);
            oneOf(iter).remove();

            oneOf(iter).hasNext();
            will(returnValue(false));
        }});

        try {
            theStore.storeAll(set);
        } catch (RuntimeException ex) {
            Assert.assertTrue(nonTransientFailedKeys.isEmpty());
            throw ex;
        }
	}
	
	@Test
	public void testStoreAllNonTransient() {
		
        @SuppressWarnings("unchecked")
        final Set<BinaryEntry> set = context.mock(Set.class);
        @SuppressWarnings("unchecked")
        final Iterator<BinaryEntry> iter = context.mock(Iterator.class);
        final BinaryEntry bin1 = context.mock(BinaryEntry.class, "bin1");
        final BinaryEntry bin2 = context.mock(BinaryEntry.class, "bin2");
        final BinaryEntry bin3 = context.mock(BinaryEntry.class, "bin3");
		
		context.checking(new Expectations() {{
            allowing(bin2).getKey();
            will(returnValue(2));
            ignoring(bin2).getValue();
		    allowing(set).size();
		    will(returnValue(3));
            allowing(bin2).getKey();
			oneOf(delegate).storeAll(set);
			will(throwException(new NonTransientDataAccessResourceException("")));
			oneOf(set).iterator();
			will(returnValue(iter));

			oneOf(iter).hasNext();
			will(returnValue(true));
			oneOf(iter).next();
			will(returnValue(bin1));
			oneOf(delegate).store(bin1);
			oneOf(iter).remove();

            oneOf(iter).hasNext();
            will(returnValue(true));
            oneOf(iter).next();
            will(returnValue(bin2));
            oneOf(delegate).store(bin2);
            will(throwException(new NonTransientDataAccessResourceException("")));
            oneOf(iter).remove();

            oneOf(iter).hasNext();
            will(returnValue(true));
            oneOf(iter).next();
            will(returnValue(bin3));
            oneOf(delegate).store(bin3);
            oneOf(iter).remove();

            oneOf(iter).hasNext();
            will(returnValue(false));
		}});
		
		theStore.storeAll(set);
		Assert.assertEquals(1, nonTransientFailedKeys.size());
		Assert.assertTrue(nonTransientFailedKeys.contains(2));
	}

}
