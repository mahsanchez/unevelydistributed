package org.cohbook.persistence.storebinary;

import static org.junit.Assert.assertEquals;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.h2.tools.Server;
import org.jmock.Expectations;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.tangosol.net.BackingMapManagerContext;
import com.tangosol.net.DistributedCacheService;
import com.tangosol.net.cache.BinaryEntryStore;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;

public class ExampleBinaryStoreTest {

    private static final String DBURL = "jdbc:h2:tcp://localhost/mem:test;DB_CLOSE_DELAY=-1";
    private static final String TABLESQL = "CREATE TABLE BINTABLE ("
            + "KEY BINARY(10) NOT NULL PRIMARY KEY, "
            + "VALUE BINARY(100) NOT NULL, "
            + "PARTITION INT NOT NULL"
            + ");";
    private static final String CLEANSQL = "DELETE FROM BINTABLE";
    private static final String INSERT_STATEMENT = "INSERT INTO BINTABLE VALUES (?, ?, ?);";
    private static final byte[] KEY1 = new byte[] { 0x01, 0x01, 0x01, 0x01 };
    private static final byte[] KEY2 = new byte[] { 0x02, 0x02, 0x02, 0x02 };
    private static final byte[] KEY3 = new byte[] { 0x03, 0x03, 0x03, 0x03 };
    private static final byte[] KEY4 = new byte[] { 0x04, 0x04, 0x04, 0x04 };
    private static final byte[] VALUEA = new byte[] { 0x0a, 0x0a, 0x0a, 0x0a, 0x0a, 0x0a, 0x0a, 0x0a };
    private static final byte[] VALUEB = new byte[] { 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b };
    private static final byte[] VALUEC = new byte[] { 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c };
    private static final byte[] VALUED = new byte[] { 0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d };
    private static final byte[] VALUECD = new byte[] { 0x0c, 0x0d, 0x0c, 0x0d, 0x0c, 0x0d, 0x0c, 0x0d };
    private static final Binary BINKEY1 = new Binary(KEY1);
    private static final Binary BINKEY2 = new Binary(KEY2);
    private static final Binary BINKEY3 = new Binary(KEY3);
    private static final Binary BINKEY4 = new Binary(KEY4);
    private static final Binary BINVALA = new Binary(VALUEA);
    private static final Binary BINVALB = new Binary(VALUEB);
    private static final Binary BINVALC = new Binary(VALUEC);
    private static final Binary BINVALD = new Binary(VALUED);
    private static final Binary BINVALCD = new Binary(VALUECD);
    private static final int PARTITIONS = 13;
    
    private BinaryEntryStore entryStore;
    private JdbcOperations jdbcop;
    
    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();
    
    @SuppressWarnings("unused")
    private static Server h2Server;
    
    @BeforeClass
    public static void setupTable() throws SQLException {
        
        h2Server = Server.createTcpServer().start();
        
        DataSource dataSource = new DriverManagerDataSource(DBURL);
        
        JdbcOperations jdbcop = new JdbcTemplate(dataSource);
        jdbcop.execute(TABLESQL);
    }
    
    @Before
    public void setUp() throws SQLException {
        DataSource dataSource = new DriverManagerDataSource(DBURL);
        
        jdbcop = new JdbcTemplate(dataSource);
        jdbcop.execute(CLEANSQL);
        
        jdbcop.update(INSERT_STATEMENT, KEY1, VALUEA, BINKEY1.calculateNaturalPartition(PARTITIONS));
        jdbcop.update(INSERT_STATEMENT, KEY2, VALUEB, BINKEY2.calculateNaturalPartition(PARTITIONS));
        jdbcop.update(INSERT_STATEMENT, KEY3, VALUEC, BINKEY3.calculateNaturalPartition(PARTITIONS));
        
        entryStore = new ExampleBinaryStore(dataSource);
        
    }
    
    @Test
    public void testLoad() {
        
        final BinaryEntry binaryentry = context.mock(BinaryEntry.class);
        context.checking(new Expectations() {{
            allowing(binaryentry).getBinaryKey();
            will(returnValue(BINKEY1));
            oneOf(binaryentry).updateBinaryValue(BINVALA);
        }});
        entryStore.load(binaryentry);
    }
    
    @Test
    public void testLoadAll() {
        
        final BinaryEntry e1 = context.mock(BinaryEntry.class, "e1");
        final BinaryEntry e2 = context.mock(BinaryEntry.class, "e2");
        final Set<BinaryEntry> set = new HashSet<>();
        
        context.checking(new Expectations() {{
            allowing(e1).getBinaryKey();
            will(returnValue(BINKEY1));
            allowing(e2).getBinaryKey();
            will(returnValue(BINKEY2));
            
            oneOf(e1).updateBinaryValue(BINVALA);
            oneOf(e2).updateBinaryValue(BINVALB);
            
        }});
        
        set.add(e1);
        set.add(e2);
        entryStore.loadAll(set);
    }
    
    @Test
    public void testStoreNew() {
        
        final BinaryEntry e4 = context.mock(BinaryEntry.class);
        final BackingMapManagerContext bmmc = context.mock(BackingMapManagerContext.class);
        final DistributedCacheService service = context.mock(DistributedCacheService.class);
        
        context.checking(new Expectations() {{
            allowing(e4).getBinaryKey();
            will(returnValue(BINKEY4));
            allowing(e4).getBinaryValue();
            will(returnValue(BINVALD));
            allowing(e4).getContext();
            will(returnValue(bmmc));
            allowing(bmmc).getCacheService();
            will(returnValue(service));
            allowing(service).getPartitionCount();
            will(returnValue(PARTITIONS));
        }});
        
        entryStore.store(e4);
        Map<Binary, Binary> expected = new HashMap<>();
        expected.put(BINKEY1, BINVALA);
        expected.put(BINKEY2, BINVALB);
        expected.put(BINKEY3, BINVALC);
        expected.put(BINKEY4, BINVALD);
        
        assertTableContents(expected);
    }
    
    @Test
    public void testStoreReplace() {
        final BinaryEntry e3 = context.mock(BinaryEntry.class);
        final BackingMapManagerContext bmmc = context.mock(BackingMapManagerContext.class);
        final DistributedCacheService service = context.mock(DistributedCacheService.class);
        
        context.checking(new Expectations() {{
            allowing(e3).getBinaryKey();
            will(returnValue(BINKEY3));
            allowing(e3).getBinaryValue();
            will(returnValue(BINVALCD));
            allowing(e3).getContext();
            will(returnValue(bmmc));
            allowing(bmmc).getCacheService();
            will(returnValue(service));
            allowing(service).getPartitionCount();
            will(returnValue(PARTITIONS));
        }});
        
        entryStore.store(e3);
        Map<Binary, Binary> expected = new HashMap<>();
        expected.put(BINKEY1, BINVALA);
        expected.put(BINKEY2, BINVALB);
        expected.put(BINKEY3, BINVALCD);
        
        assertTableContents(expected);
    }
    
    @Test
    public void testStoreAll() {

        final BinaryEntry e3 = context.mock(BinaryEntry.class, "e3");
        final BinaryEntry e4 = context.mock(BinaryEntry.class, "e4");
        final BackingMapManagerContext bmmc = context.mock(BackingMapManagerContext.class);
        final DistributedCacheService service = context.mock(DistributedCacheService.class);
        
        context.checking(new Expectations() {{
            allowing(e3).getBinaryKey();
            will(returnValue(BINKEY3));
            allowing(e3).getBinaryValue();
            will(returnValue(BINVALCD));
            allowing(e3).getContext();
            will(returnValue(bmmc));

            allowing(e4).getBinaryKey();
            will(returnValue(BINKEY4));
            allowing(e4).getBinaryValue();
            will(returnValue(BINVALD));
            allowing(e4).getContext();
            will(returnValue(bmmc));
            allowing(bmmc).getCacheService();
            will(returnValue(service));

            allowing(bmmc).getCacheService();
            will(returnValue(service));
            allowing(service).getPartitionCount();
            will(returnValue(PARTITIONS));
        }});

        Set<BinaryEntry> set = new HashSet<>();
        set.add(e3);
        set.add(e4);
        entryStore.storeAll(set);
        Map<Binary, Binary> expected = new HashMap<>();
        expected.put(BINKEY1, BINVALA);
        expected.put(BINKEY2, BINVALB);
        expected.put(BINKEY3, BINVALCD);
        expected.put(BINKEY4, BINVALD);
        
        assertTableContents(expected);
    }
    
    @Test
    public void testErase() {
        
        final BinaryEntry e2 = context.mock(BinaryEntry.class);
        context.checking(new Expectations() {{
            allowing(e2).getBinaryKey();
            will(returnValue(BINKEY2));
        }});
        entryStore.erase(e2);
        Map<Binary, Binary> expected = new HashMap<>();
        expected.put(BINKEY1, BINVALA);
        expected.put(BINKEY3, BINVALC);
        
        assertTableContents(expected);
    }
    
    @Test
    public void testEraseAll() {
        final BinaryEntry e3 = context.mock(BinaryEntry.class, "e3");
        final BinaryEntry e1 = context.mock(BinaryEntry.class, "e1");
        
        context.checking(new Expectations() {{
            allowing(e3).getBinaryKey();
            will(returnValue(BINKEY3));

            allowing(e1).getBinaryKey();
            will(returnValue(BINKEY1));
        }});

        Set<BinaryEntry> set = new HashSet<>();
        set.add(e3);
        set.add(e1);
        entryStore.eraseAll(set);
        Map<Binary, Binary> expected = new HashMap<>();
        expected.put(BINKEY2, BINVALB);
        
        assertTableContents(expected);
    }

    private void assertTableContents(Map<Binary, Binary> expected) {
        
        final Map<Binary, Binary> actual = new HashMap<>();
        jdbcop.query("SELECT * FROM BINTABLE", new RowMapper<Object>() {

            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                byte[] key = rs.getBytes(1);
                Binary binkey = new Binary(key);
                assertEquals(binkey.calculateNaturalPartition(PARTITIONS), rs.getInt(3));
                actual.put(binkey, new Binary(rs.getBytes(2)));
                return null;
            }
        });
        
        assertEquals(expected.size(), actual.size());
        for (Map.Entry<Binary, Binary> entry: expected.entrySet()) {
            assertEquals(entry.getValue(), actual.get(entry.getKey()));
        }
    }
}
