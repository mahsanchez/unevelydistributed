package org.cohbook.persistence.distprime;

import java.sql.SQLException;
import java.util.Map;

import javax.sql.DataSource;

import org.cohbook.persistence.distprime.CachePrimeInvocable;
import org.h2.tools.Server;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.tangosol.io.Serializer;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.util.ExternalizableHelper;

public class CachePrimeInvocableTest {

    private static final String DBURL = "jdbc:h2:tcp://localhost/mem:test;DB_CLOSE_DELAY=-1";
    private static final String TABLESQL = "CREATE TABLE EXAMPLE_TABLE ("
            + "PARTITION INTEGER NOT NULL,"
            + "KEY VARCHAR(10) NOT NULL PRIMARY KEY,"
            + "VALUE VARCHAR(100) NOT NULL"
            + ");";
    private static final String DROPTABLESQL = "DROP TABLE EXAMPLE_TABLE;";
    private static final String INSERT_STATEMENT = "INSERT INTO EXAMPLE_TABLE VALUES (?, ?, ?);";
    private static final Logger LOG = LoggerFactory.getLogger(CachePrimeInvocableTest.class);
    
    private JdbcOperations jdbcop;
    private ClusterMemberGroup memberGroup;
    private Server h2Server;
    
    @Before
    public void setUp() throws SQLException {
        h2Server = Server.createTcpServer().start();
        
        DataSource dataSource = new DriverManagerDataSource(DBURL);
        
        jdbcop = new JdbcTemplate(dataSource);
        jdbcop.execute(TABLESQL);
        
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(4)
                .setCacheConfiguration("org/cohbook/persistence/distributedprime/cache-config.xml")
                .setAdditionalSystemProperty("tangosol.coherence.log.level", 6)
                .setAdditionalSystemProperty("database.url", DBURL)
                .setJarsToExcludeFromClassPath("h2-1.3.172.jar")
                .buildAndConfigureForStorageDisabledClient();

        NamedCache cache = CacheFactory.getCache("testCache");
        PartitionedService cacheService = (PartitionedService) cache.getCacheService();
        int partitionCount = cacheService.getPartitionCount();
        Serializer serialiser = cacheService.getSerializer();
        
        for (int i = 0; i < 100; i++) {
            String key = Integer.valueOf(i).toString();
            String value = "value-" + key;
            int part = ExternalizableHelper.toBinary(key, serialiser).calculateNaturalPartition(partitionCount);
            LOG.info("saving key " + key + " as partition " + part);
            jdbcop.update(INSERT_STATEMENT, part, key, value);
        }
    }
    
    @After
    public void tearDown() {
        CacheFactory.shutdown();
        memberGroup.stopAll();
        jdbcop.execute(DROPTABLESQL);
        h2Server.shutdown();
    }
    

    @Test
    public void testRun() throws Exception {
        
        CachePrimeInvocable primer = new CachePrimeInvocable();
        InvocationService invocationService = (InvocationService) CacheFactory.getService("invocationService");
        
        NamedCache cache = CacheFactory.getCache("testCache");
        PartitionedService cacheService = (PartitionedService) cache.getCacheService();
        
        @SuppressWarnings("unchecked")
        Map<Member, Object> results = invocationService.query(primer, cacheService.getOwnershipEnabledMembers());
        for (Object result : results.values()) {
            Assert.assertNotNull(result);
        }
        
        Assert.assertEquals(100, cache.size());
    }

}
