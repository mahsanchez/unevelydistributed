package org.cohbook.persistence.controllablecachestore;

import static org.junit.Assert.assertEquals;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.h2.tools.Server;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.tangosol.coherence.component.util.safeService.safeCacheService.SafeDistributedCacheService;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.InvocationService;
import com.tangosol.net.NamedCache;

public class ControllableCacheStoreTest {

    private static final String DBURL = "jdbc:h2:tcp://localhost/mem:test;DB_CLOSE_DELAY=-1";
    private static final String TABLESQL = "CREATE TABLE EXAMPLE_TABLE ("
            + "KEY VARCHAR(10) NOT NULL PRIMARY KEY,"
            + "VALUE VARCHAR(100) NOT NULL"
            + ");";
    private static final String DROPTABLESQL = "DROP TABLE EXAMPLE_TABLE;";
    private static final String INSERT_STATEMENT = "INSERT INTO EXAMPLE_TABLE VALUES (?, ?);";
    
    private JdbcOperations jdbcop;
    private ClusterMemberGroup memberGroup;
    private Server h2Server;
    
    @Before
    public void setUp() throws SQLException {
        h2Server = Server.createTcpServer().start();
        
        DataSource dataSource = new DriverManagerDataSource(DBURL);
        
        jdbcop = new JdbcTemplate(dataSource);
        jdbcop.execute(TABLESQL);
        
        jdbcop.update(INSERT_STATEMENT, "1", "A");
        jdbcop.update(INSERT_STATEMENT, "2", "B");
        jdbcop.update(INSERT_STATEMENT, "3", "C");
        
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(1)
                .setCacheConfiguration("org/cohbook/persistence/controllablecachestore/cache-config.xml")
                .setAdditionalSystemProperty("tangosol.coherence.log.level", 6)
                .setAdditionalSystemProperty("database.url", DBURL)
                .setJarsToExcludeFromClassPath("h2-1.3.172.jar")
                .buildAndConfigureForStorageDisabledClient();
    }
    
    @After
    public void tearDown() {
        CacheFactory.shutdown();
        memberGroup.stopAll();
        jdbcop.execute(DROPTABLESQL);
        h2Server.shutdown();
    }
    
    @Test
    public void insertWhileDisabled() {
        
        NamedCache cache = CacheFactory.getCache("test");
        cache.put("1", "a");
        cache.put("4", "D");
        
        Map<String,String> expected = new HashMap<>();
        expected.put("1", "A");
        expected.put("2", "B");
        expected.put("3", "C");
        
        assertTableContents(expected);

    }

    @Test
    public void insertWhileEnabled() {
        
        NamedCache cache = CacheFactory.getCache("test");

        CacheStoreSwitcher switcher = new CacheStoreSwitcher("testcachestore", true);
        
        InvocationService invocationService =
                (InvocationService) CacheFactory.getService("invocationService");
        
        invocationService.query(switcher,
                ((SafeDistributedCacheService)cache.getCacheService()).getOwnershipEnabledMembers());
        
        cache.put("1", "a");
        cache.put("4", "D");
        
        Map<String,String> expected = new HashMap<>();
        expected.put("1", "a");
        expected.put("2", "B");
        expected.put("3", "C");
        expected.put("4", "D");
        
        assertTableContents(expected);

    }
    
    private void assertTableContents(Map<String,String> expected) {
        
        final Map<String,String> actual = new HashMap<>();
        jdbcop.query("SELECT * FROM EXAMPLE_TABLE", new RowMapper<Object>() {

            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                actual.put(rs.getString(1), rs.getString(2));
                return null;
            }
        });
        
        assertEquals(expected.size(), actual.size());
        for (Map.Entry<String, String> entry: expected.entrySet()) {
            assertEquals(entry.getValue(), actual.get(entry.getKey()));
        }
        
    }
}