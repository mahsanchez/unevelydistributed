package org.cohbook.persistence.modelcachestore;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.NonTransientDataAccessResourceException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.dao.TransientDataAccessResourceException;

import com.tangosol.net.cache.CacheStore;

public class ExceptionHandlingCacheStoreTest {
	
	private Mockery context;
	private CacheStore delegate;
	private ExceptionHandlingCacheStore cacheStore;
	private final Set<Object> nonTransientFailedKeys = new HashSet<>();
	
	@Before
	public void setup() {
		context = new Mockery();
		delegate = context.mock(CacheStore.class);
		nonTransientFailedKeys.clear();
		cacheStore = new ExceptionHandlingCacheStore(delegate) {
            @Override
            protected void handleNonTransientFailure(Object key, Object value,
                    Exception exception) {
                nonTransientFailedKeys.add(key);
                super.handleNonTransientFailure(key, value, exception);
            }
		};
	}
	
	@Test
	public void testStoreOk() {
		
		final Object key = Integer.valueOf(1);
		final Object value = "testValue";
		
		context.checking(new Expectations() {{
			oneOf(delegate).store(key, value);
		}});
		
		cacheStore.store(key, value);
		Assert.assertTrue(nonTransientFailedKeys.isEmpty());
		
	}
	
	@Test
	public void testStoreOneTransientError() {
		
		final Object key = Integer.valueOf(1);
		final Object value = "testValue";
		
		context.checking(new Expectations() {{
			oneOf(delegate).store(key, value);
			will(throwException(new TransientDataAccessResourceException("transient")));
			oneOf(delegate).store(key, value);
		}});
		
		cacheStore.store(key, value);
        Assert.assertTrue(nonTransientFailedKeys.isEmpty());
		
	}
	
	@Test(expected=TransientDataAccessException.class)
	public void testStoreRepeatedTransientError() {
		
		final Object key = Integer.valueOf(1);
		final Object value = "testValue";
		
		context.checking(new Expectations() {{
			atLeast(1).of(delegate).store(key, value);
			will(throwException(new TransientDataAccessResourceException("transient")));
		}});

		try {
		    cacheStore.store(key, value);
		} catch (RuntimeException ex) {
		    Assert.assertTrue(nonTransientFailedKeys.isEmpty());
		    throw ex;
		}
		
	}

	@Test
	public void testStoreNonTransientError() {
		
		final Object key = Integer.valueOf(1);
		final Object value = "testValue";
		
		context.checking(new Expectations() {{
			oneOf(delegate).store(key, value);
			will(throwException(new NonTransientDataAccessResourceException("not transient")));
		}});
		
		cacheStore.store(key, value);
        Assert.assertEquals(1, nonTransientFailedKeys.size());
        Assert.assertTrue(nonTransientFailedKeys.contains(key));
		
	}
	
	@Test
	public void testStoreAllOk() {
		
		final Map<Integer, String> data = new HashMap<Integer, String>();
		data.put(1, "test1");
		data.put(2, "test2");
		data.put(3, "test3");
		
		context.checking(new Expectations() {{
			oneOf(delegate).storeAll(data);
		}});
		
		cacheStore.storeAll(data);
        Assert.assertTrue(nonTransientFailedKeys.isEmpty());

	}
	
	@Test
	public void testStoreAllOneTransient() {
		
		final Map<Integer, String> data = new HashMap<Integer, String>();
		data.put(1, "test1");
		data.put(2, "test2");
		data.put(3, "test3");
		
		context.checking(new Expectations() {{
			oneOf(delegate).storeAll(data);
			will(throwException(new TransientDataAccessResourceException("")));
			oneOf(delegate).storeAll(data);
		}});
		
		cacheStore.storeAll(data);
        Assert.assertTrue(nonTransientFailedKeys.isEmpty());
		
	}
	
	@Test(expected=TransientDataAccessException.class)
	public void testStoreAllRepeatedTransient() {
		
		final Map<Integer, String> data = new HashMap<Integer, String>();
		data.put(1, "test1");
		data.put(2, "test2");
		data.put(3, "test3");
		
		context.checking(new Expectations() {{
			atLeast(1).of(delegate).storeAll(data);
			will(throwException(new TransientDataAccessResourceException("")));
            allowing(delegate).store(1, "test1");
            allowing(delegate).store(2, "test2");
            will(throwException(new TransientDataAccessResourceException("")));
            allowing(delegate).store(3, "test3");
		}});
		
		try {
			cacheStore.storeAll(data);
		} catch (RuntimeException e) {
			Assert.assertEquals(1, data.size());
			Assert.assertEquals(0, nonTransientFailedKeys.size());
			throw e;
		}
		
	}
	
	@Test
	public void testStoreAllNonTransient() {
		
		final Map<Integer, String> data = new HashMap<Integer, String>();
		data.put(1, "test1");
		data.put(2, "test2");
		data.put(3, "test3");
		
		context.checking(new Expectations() {{
			oneOf(delegate).storeAll(data);
			will(throwException(new NonTransientDataAccessResourceException("")));
			atLeast(1).of(delegate).store(1, "test1");
			atLeast(1).of(delegate).store(3, "test3");
			oneOf(delegate).store(2, "test2");
			will(throwException(new NonTransientDataAccessResourceException("")));
		}});
		
		cacheStore.storeAll(data);
		Assert.assertEquals(1, nonTransientFailedKeys.size());
		Assert.assertTrue(nonTransientFailedKeys.contains(2));
	}

}
