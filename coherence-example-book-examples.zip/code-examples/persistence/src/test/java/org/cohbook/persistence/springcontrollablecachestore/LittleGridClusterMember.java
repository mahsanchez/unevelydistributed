package org.cohbook.persistence.springcontrollablecachestore;

import org.cohbook.configuration.spring.BeanLocator;
import org.littlegrid.impl.DefaultClusterMember;

public class LittleGridClusterMember extends DefaultClusterMember {

    @Override
    public void doBeforeStart() {
        BeanLocator.getContext("coherenceBeansContext");
    }
}
