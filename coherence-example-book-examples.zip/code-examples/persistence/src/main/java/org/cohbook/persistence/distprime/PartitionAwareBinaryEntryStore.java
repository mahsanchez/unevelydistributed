package org.cohbook.persistence.distprime;

import java.util.Set;

import com.tangosol.net.PartitionedService;
import com.tangosol.net.cache.BinaryEntryStore;
import com.tangosol.util.BinaryEntry;

public class PartitionAwareBinaryEntryStore implements BinaryEntryStore {

    @Override
    public void store(BinaryEntry binaryentry) {
        PartitionedService service = (PartitionedService) binaryentry.getContext().getCacheService();
//        int partition = service.getKeyPartitioningStrategy().getKeyPartition(binaryentry.getKey());
        
        int partition = binaryentry.getBinaryKey().calculateNaturalPartition(service.getPartitionCount());

        /* rest of store implementation */
    }

    @Override
    public void load(BinaryEntry binaryentry) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void loadAll(Set set) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void storeAll(Set set) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void erase(BinaryEntry binaryentry) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void eraseAll(Set set) {
        throw new UnsupportedOperationException("not yet implemented");
    }

}
