package org.cohbook.persistence.storebinary;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.tangosol.io.Base64InputStream;
import com.tangosol.io.Base64OutputStream;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.cache.BinaryEntryStore;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;

public class EncodedKeyBinaryStore implements BinaryEntryStore {
    
    private static final String SELECT_ONE_SQL = "SELECT VALUE FROM BINTABLE WHERE KEY=?";
    private static final String SELECT_MANY_SQL = "SELECT KEY, VALUE FROM BINTABLE WHERE KEY IN (:KEYS)";
    private static final String MERGE_SQL = "MERGE INTO BINTABLE VALUES(?, ?, ?)";
    private static final String DELETE_ONE_SQL = "DELETE FROM BINTABLE WHERE KEY = ?";
    private static final String DELETE_MANY_SQL = "DELETE FROM BINTABLE WHERE KEY IN (:KEYS)";

    private final NamedParameterJdbcOperations jdbcTemplate;
    
    public EncodedKeyBinaryStore(DataSource dataSource) {
        jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    @Override
    public void load(BinaryEntry binaryentry) {
        
        Binary binarykey = binaryentry.getBinaryKey();
        String encodedKey = new String(Base64OutputStream.encode(binarykey.toByteArray()));
        
        byte[] bytesvalue = jdbcTemplate.getJdbcOperations().queryForObject(
                SELECT_ONE_SQL,
                byte[].class,
                encodedKey);
        
        binaryentry.updateBinaryValue(new Binary(bytesvalue));
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void loadAll(@SuppressWarnings("rawtypes") final Set set) {
        
        final Map<Binary, Binary> results = new HashMap<>();

        RowMapper<Object> rowmapper = new RowMapper<Object>() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                String encodedKey = rs.getString(1);
                Binary key = new Binary(Base64InputStream.decode(encodedKey.toCharArray()));
                Binary value = new Binary(rs.getBytes(2));
                results.put(key, value);
                return null;
            }
        };
        
        List<String> keys = new ArrayList<>(set.size());
        for (BinaryEntry entry : (Set<BinaryEntry>) set) {
            Binary binarykey = entry.getBinaryKey();
            keys.add(new String(Base64OutputStream.encode(binarykey.toByteArray())));
        }

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("KEYS", keys);
        
        jdbcTemplate.query(SELECT_MANY_SQL, parameters, rowmapper);
        
        for (BinaryEntry entry : (Set<BinaryEntry>) set) {
            Binary key = entry.getBinaryKey();
            if (results.containsKey(key)) {
                entry.updateBinaryValue(results.get(key));
            }
        }
    }

    @Override
    public void store(BinaryEntry binaryentry) {
        
        Binary binarykey = binaryentry.getBinaryKey();
        Binary value = binaryentry.getBinaryValue();
        PartitionedService service = (PartitionedService) binaryentry.getContext().getCacheService();
        int partition = binarykey.calculateNaturalPartition(service.getPartitionCount());
        
        String encodedKey = new String(Base64OutputStream.encode(binarykey.toByteArray()));

        jdbcTemplate.getJdbcOperations().update(
                MERGE_SQL, encodedKey, value.toByteArray(), partition);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void storeAll(@SuppressWarnings("rawtypes") Set set) {
        List<Object[]> batchValues = new ArrayList<>(set.size());
        for (BinaryEntry binaryentry : (Set<BinaryEntry>) set) {
            PartitionedService service =
                    (PartitionedService) binaryentry.getContext().getCacheService();
            Binary binarykey = binaryentry.getBinaryKey();
            Binary value = binaryentry.getBinaryValue();
            int partition = binarykey.calculateNaturalPartition(service.getPartitionCount());
            String encodedKey = new String(Base64OutputStream.encode(binarykey.toByteArray()));

            batchValues.add(new Object[] { 
                    encodedKey, value.toByteArray(), partition });
        }
        jdbcTemplate.getJdbcOperations().batchUpdate(MERGE_SQL, batchValues);
    }

    @Override
    public void erase(BinaryEntry binaryentry) {
        Binary binarykey = binaryentry.getBinaryKey();
        String encodedKey = new String(Base64OutputStream.encode(binarykey.toByteArray()));
        jdbcTemplate.getJdbcOperations().update(
                DELETE_ONE_SQL, encodedKey);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void eraseAll(@SuppressWarnings("rawtypes") Set set) {

        List<String> keys = new ArrayList<>(set.size());
        for (BinaryEntry entry : (Set<BinaryEntry>) set) {
            Binary binarykey = entry.getBinaryKey();
            String encodedKey = new String(Base64OutputStream.encode(binarykey.toByteArray()));
            keys.add(encodedKey);
        }

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("KEYS", keys);

        jdbcTemplate.update(DELETE_MANY_SQL, parameters);

    }
}
