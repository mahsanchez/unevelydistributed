package org.cohbook.persistence.modelcachestore;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.RecoverableDataAccessException;
import org.springframework.dao.TransientDataAccessException;

import com.tangosol.net.cache.BinaryEntryStore;
import com.tangosol.util.BinaryEntry;

public class ExceptionHandlingBinaryEntryStore implements BinaryEntryStore {
    
    private static final int MAX_RETRY_COUNT = 3;
    private static final Logger LOG = LoggerFactory.getLogger(ExceptionHandlingBinaryEntryStore.class);
    private final BinaryEntryStore delegate;
    
    public ExceptionHandlingBinaryEntryStore(BinaryEntryStore delegate) {
        this.delegate = delegate;
    }

    @Override
    public void load(BinaryEntry binaryentry) {
        delegate.load(binaryentry);
    }

    @SuppressWarnings("rawtypes")
    @Override

    public void loadAll(Set set) {
        delegate.loadAll(set);
    }

    @Override
    public void store(BinaryEntry binaryentry) {
        try {
            storeWithRetry(binaryentry);
        } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
            throw ex;
        } catch (RuntimeException ex) {
            handleNonTransientFailure(binaryentry.getKey(), binaryentry.getValue(), ex);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public void storeAll(@SuppressWarnings("rawtypes") Set set) {
        
        try {
            storeAllWithRetry(set);
        } catch (RuntimeException ex) {
            handleBatchFailure(set);
        }
    }
    
    private void storeAllWithRetry(Set<BinaryEntry> set) {
        int retryCount = 0;
        RuntimeException lastException = null;
        
        while (retryCount < MAX_RETRY_COUNT) {
            try {
                delegate.storeAll(set);
                return;
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
                retryCount++;
            }
        }
        throw lastException;
    }
    
    private void storeWithRetry(BinaryEntry binaryEntry) {
        int retryCount = 0;
        RuntimeException lastException = null;
        
        while (retryCount < MAX_RETRY_COUNT) {
            try {
                delegate.store(binaryEntry);
                return;
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
                retryCount++;
            }
        }
        throw lastException;
    }
    
    private void handleBatchFailure(@SuppressWarnings("rawtypes") Set set) {
        RuntimeException lastException = null;
        @SuppressWarnings("unchecked")
        Iterator<BinaryEntry> iterator = set.iterator();
        while (iterator.hasNext()) {
            BinaryEntry entry = iterator.next();
            try {
                storeWithRetry(entry);
                iterator.remove();
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
            } catch (RuntimeException ex) {
                handleNonTransientFailure(entry.getKey(), entry.getValue(), ex);
                iterator.remove();
            }
        }
        if (lastException != null) {
            throw lastException;
        }
    }

    @Override
    public void erase(BinaryEntry entry) {
        eraseAll(Collections.singleton(entry));
    }

    @Override
    public void eraseAll(@SuppressWarnings("rawtypes") Set set) {

        int retryCount = 0;
        RuntimeException lastException = null;
        
        while (retryCount < MAX_RETRY_COUNT) {
            try {
                delegate.eraseAll(set);
                return;
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
                retryCount++;
            }
        }
                
        throw lastException;
    }

    protected void handleNonTransientFailure(Object key, Object value, Exception exception) {
        LOG.error("failed to store " + key + ":" + value, exception);
    }

}
