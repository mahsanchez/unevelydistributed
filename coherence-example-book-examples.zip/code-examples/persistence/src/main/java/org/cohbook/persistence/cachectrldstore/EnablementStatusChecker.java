package org.cohbook.persistence.cachectrldstore;

public interface EnablementStatusChecker {
    boolean isEnabled();
}
