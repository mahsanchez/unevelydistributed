package org.cohbook.persistence.distprime;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.KeyPartitioningStrategy;
import com.tangosol.net.partition.PartitionSet;

@Portable
public class CachePrimeInvocable implements Invocable {
    
    private static final long serialVersionUID = -7949503502069914697L;
    private static final String CACHENAME = "testCache";
    private static final String LOADSQL = "SELECT KEY, VALUE FROM EXAMPLE_TABLE WHERE PARTITION IN ( :PARTITIONS )";
    private static final Logger LOG = LoggerFactory.getLogger(CachePrimeInvocable.class);
    
    private transient Member member;
    private transient NamedParameterJdbcOperations jdbcTemplate;
    private transient NamedCache cache;
    private transient PartitionSet partitionSet;
    
    @Override
    public void init(InvocationService invocationservice) {
        member = invocationservice.getCluster().getLocalMember();
        DataSource dataSource = new DriverManagerDataSource(
                System.getProperty("database.url"));
        jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
        cache = CacheFactory.getCache(CACHENAME);
    }
    
    public RowMapper<Object> getRowMapper() {
        return new RowMapper<Object>() {
            
            private final KeyPartitioningStrategy keystrat = 
                    ((PartitionedService) cache.getCacheService()).getKeyPartitioningStrategy();
            
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                Object key = rs.getString(1);
                LOG.debug("put key " + key + " from member " + member.getId());
                
                int rowpart = keystrat.getKeyPartition(key);
                if (!partitionSet.contains(rowpart)) {
                    throw new IllegalStateException(
                            "partition " + rowpart + " for key " + key + " is not on member " + member.getId());
                }
                cache.put(key, rs.getString(2));
                return null;
            }
        };
    }

    @Override
    public void run() {
        
        PartitionedService service = (PartitionedService) cache.getCacheService();
        partitionSet = service.getOwnedPartitions(member);
        List<Integer> parts = Arrays.asList(ArrayUtils.toObject(partitionSet.toArray()));

        LOG.debug("retrieving partitions " + parts + " from member " + member.getId());
        
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("PARTITIONS", parts);
        
        jdbcTemplate.query(LOADSQL, parameters, getRowMapper());
    }

    @Override
    public Object getResult() {
        return partitionSet;
    }

}
