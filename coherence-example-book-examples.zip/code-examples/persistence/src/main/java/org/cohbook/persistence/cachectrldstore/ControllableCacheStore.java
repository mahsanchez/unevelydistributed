package org.cohbook.persistence.cachectrldstore;

import java.util.Collection;
import java.util.Map;

import com.tangosol.net.cache.CacheStore;

public class ControllableCacheStore implements CacheStore {
    
    private final CacheStore delegate;
    private final EnablementStatusChecker check;

    public ControllableCacheStore(CacheStore delegate, EnablementStatusChecker check) {
        this.delegate = delegate;
        this.check = check;
    }
    
    @Override
    public Object load(Object obj) {
        return delegate.load(obj);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map loadAll(Collection collection) {
        return delegate.loadAll(collection);
    }

    @Override
    public void store(Object obj, Object obj1) {
        if (check.isEnabled()) {
            delegate.store(obj, obj1);
        }
    }

    @Override
    public void storeAll(@SuppressWarnings("rawtypes") Map map) {
        if (check.isEnabled()) {
            delegate.storeAll(map);
        }
    }

    @Override
    public void erase(Object obj) {
        if (check.isEnabled()) {
            delegate.erase(obj);
        }
    }

    @Override
    public void eraseAll(@SuppressWarnings("rawtypes") Collection collection) {
        if (check.isEnabled()) {
            delegate.eraseAll(collection);
        }
    }
}
