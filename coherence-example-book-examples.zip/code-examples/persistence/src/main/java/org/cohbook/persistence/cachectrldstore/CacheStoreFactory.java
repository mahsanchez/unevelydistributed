package org.cohbook.persistence.cachectrldstore;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.cohbook.persistence.modelcachestore.SpringJdbcCacheStore;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.tangosol.net.cache.CacheStore;

public class CacheStoreFactory {
    
    private static final Map<String,ControllableCacheStore> cacheStoreMap = new HashMap<>();
    private static final DataSource dataSource = new DriverManagerDataSource(
            System.getProperty("database.url"));
    
    public static ControllableCacheStore getCacheStore(String cacheStoreName) {
        synchronized (cacheStoreMap) {
            ControllableCacheStore result = cacheStoreMap.get(cacheStoreName);
            if (result == null) {
                CacheStore jc = new SpringJdbcCacheStore(dataSource);
                result = new ControllableCacheStore(jc,
                        new CacheEnablementStatusChecker(cacheStoreName));
                cacheStoreMap.put(cacheStoreName, result);
            }
            return result;
        }
    }
}
