package org.cohbook.persistence.distprime;

import java.util.Collection;
import java.util.Map;

import com.tangosol.coherence.component.util.BackingMapManagerContext;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.cache.CacheStore;

public class PartitionAwareCacheStore implements CacheStore {

    private PartitionedService service;
        
    protected PartitionAwareCacheStore(BackingMapManagerContext bmmc) {
        this.service = (PartitionedService) bmmc.getCacheService();
    }

    @Override
    public void store(Object key, Object value) {
        
        int partition = service.getKeyPartitioningStrategy().getKeyPartition(key);
        
        /* rest of store implementation */
    }

    @Override
    public Object load(Object obj) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public Map loadAll(Collection collection) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void storeAll(Map map) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void erase(Object obj) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public void eraseAll(Collection collection) {
        throw new UnsupportedOperationException("not yet implemented");
    }

}
