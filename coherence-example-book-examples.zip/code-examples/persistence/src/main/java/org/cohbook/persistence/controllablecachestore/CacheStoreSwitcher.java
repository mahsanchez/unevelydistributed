package org.cohbook.persistence.controllablecachestore;

import java.io.Serializable;

import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationService;

public class CacheStoreSwitcher implements Invocable, Serializable {
    
    private static final long serialVersionUID = -5415068943068920481L;
    
    private final boolean enable;
    private final String cacheStoreName;
    private transient Object result = null;
    private transient ControllableCacheStore cacheStore;

    public CacheStoreSwitcher(String cacheStoreName, boolean enable) {
        this.enable = enable;
        this.cacheStoreName = cacheStoreName;
    }

    @Override
    public void init(InvocationService invocationservice) {
        this.cacheStore = CacheStoreFactory.getCacheStore(cacheStoreName);
    }

    @Override
    public void run() {
        try {
            cacheStore.setEnabled(enable);
        } catch (RuntimeException e) {
            result = e;
        }
    }

    @Override
    public Object getResult() {
        return result;
    }
}
