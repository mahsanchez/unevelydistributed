package org.cohbook.persistence.modelcachestore;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.RecoverableDataAccessException;
import org.springframework.dao.TransientDataAccessException;

import com.tangosol.net.cache.CacheStore;

public class ExceptionHandlingCacheStore implements CacheStore {
    
    public static final int MAX_RETRY_COUNT = 3;
    private static final Logger LOG = LoggerFactory.getLogger(ExceptionHandlingCacheStore.class);
    private final CacheStore delegate;
    
    public ExceptionHandlingCacheStore(CacheStore delegate) {
        this.delegate = delegate;
    }

    @Override
    public Object load(Object obj) {
        return delegate.load(obj);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map loadAll(Collection collection) {
        return delegate.loadAll(collection);
    }

    @Override
    public void store(Object key, Object value) {
		try {
			storeWithRetry(key, value);
        } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
            throw ex;
		} catch (RuntimeException ex) {
            handleNonTransientFailure(key, value, ex);
		}
    }

    @Override
    public void storeAll(@SuppressWarnings("rawtypes") Map rawmap) {
        
        @SuppressWarnings("unchecked")
        Map<Object,Object> map = rawmap;
        
		try {
			storeAllWithRetry(map);
        } catch (RuntimeException ex) {
            handleBatchFailure(map);
        }
    }
    
    private void storeWithRetry(Object key, Object value) {
        int retryCount = 0;
        RuntimeException lastException = null;
        while (retryCount < MAX_RETRY_COUNT) {
            try {
            	delegate.store(key, value);
                return;
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
                retryCount++;
            }
        }
        throw lastException;
    }
    
    private void storeAllWithRetry(Map<Object,Object> map) {
        int retryCount = 0;
        RuntimeException lastException = null;
        
        while (retryCount < MAX_RETRY_COUNT) {
            try {
        		delegate.storeAll(map);
                return;
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
                retryCount++;
            }
        }
        throw lastException;
    }
    
    private void handleBatchFailure(Map<Object,Object> map) {
        RuntimeException lastException = null;
        Iterator<Map.Entry<Object,Object>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Object, Object> entry = iterator.next();
            try {
                store(entry.getKey(), entry.getValue());
                iterator.remove();
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
            } catch (RuntimeException ex) {
                handleNonTransientFailure(entry.getKey(), entry.getValue(), ex);
                iterator.remove();
            }
        }
        if (lastException != null) {
            throw lastException;
        }
    }

    @Override
    public void erase(Object obj) {
        int retryCount = 0;
        RuntimeException lastException = null;
        
        while (retryCount < MAX_RETRY_COUNT) {
            try {
        		delegate.erase(obj);
                return;
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
                retryCount++;
            }
        }
                
        throw lastException;
    }

    @Override
    public void eraseAll(@SuppressWarnings("rawtypes") Collection collection) {

        int retryCount = 0;
        RuntimeException lastException = null;
        
        while (retryCount < MAX_RETRY_COUNT) {
            try {
                delegate.eraseAll(collection);
                return;
            } catch (RecoverableDataAccessException | TransientDataAccessException ex) {
                lastException = ex;
                retryCount++;
            }
        }
                
        throw lastException;
    }

    protected void handleNonTransientFailure(Object key, Object value, Exception exception) {
        LOG.error("failed to store " + key + ":" + value, exception);
    }
}
