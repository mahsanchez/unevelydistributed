package org.cohbook.persistence.controllablecachestore;

import java.util.Collection;
import java.util.Map;

import com.tangosol.net.cache.CacheStore;

public class ControllableCacheStore implements CacheStore {
    
    private final CacheStore delegate;
    private boolean enabled = false;

    public ControllableCacheStore(CacheStore delegate) {
        this.delegate = delegate;
    }

    @Override
    public Object load(Object obj) {
        return delegate.load(obj);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map loadAll(Collection collection) {
        return delegate.loadAll(collection);
    }

    @Override
    public void store(Object obj, Object obj1) {
        if (enabled) {
            delegate.store(obj, obj1);
        }
    }

    @Override
    public void storeAll(@SuppressWarnings("rawtypes") Map map) {
        if (enabled) {
            delegate.storeAll(map);
        }
    }

    @Override
    public void erase(Object obj) {
        if (enabled) {
            delegate.erase(obj);
        }
    }

    @Override
    public void eraseAll(@SuppressWarnings("rawtypes") Collection collection) {
        if (enabled) {
            delegate.eraseAll(collection);
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
