package org.cohbook.persistence.springcontrollablecachestore;

import java.util.concurrent.CountDownLatch;

import org.cohbook.configuration.spring.LifecycleValidatingCacheFactoryBuilder;
import org.cohbook.persistence.cachectrldstore.EnablementStatusChecker;
import org.springframework.context.SmartLifecycle;

import com.tangosol.net.CacheFactory;

public class CacheEnablementStatusChecker implements EnablementStatusChecker, SmartLifecycle {

    public static final String CONTROLCACHE = "control-cache";
    private final String key;
    private final CountDownLatch latch = new CountDownLatch(1);
    
    public CacheEnablementStatusChecker(String key) {
        this.key = key;
    }

    @Override
    public boolean isEnabled() {
        try {
            latch.await();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Boolean enabled = (Boolean) CacheFactory.getCache(CONTROLCACHE).get(key);
        return enabled == null ? false : enabled;
    }

    @Override
    public void start() {
        latch.countDown();
    }

    @Override
    public void stop() {
    }

    @Override
    public boolean isRunning() {
        return latch.getCount() == 0;
    }

    @Override
    public int getPhase() {
        return LifecycleValidatingCacheFactoryBuilder.AFTER_CLUSTER_PHASE;
    }

    @Override
    public boolean isAutoStartup() {
        return true;
    }

    @Override
    public void stop(Runnable callback) {
    }
}
