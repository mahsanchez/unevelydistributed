package org.cohbook.persistence.modelcachestore;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.tangosol.net.cache.CacheStore;

public class SpringJdbcCacheStore implements CacheStore {
    
    private final NamedParameterJdbcOperations jdbcTemplate;
    
    private static final String SELECT_ONE_SQL = "SELECT VALUE FROM EXAMPLE_TABLE WHERE KEY = ?";
    private static final String SELECT_MANY_SQL = "SELECT KEY, VALUE FROM EXAMPLE_TABLE WHERE KEY in (:keys)";
    private static final String DELETE_ONE_SQL = "DELETE FROM EXAMPLE_TABLE WHERE KEY = ?";
    private static final String DELETE_MANY_SQL = "DELETE FROM EXAMPLE_TABLE WHERE KEY IN (:keys)";
    
    private static final String MERGE_SQL = "MERGE INTO EXAMPLE_TABLE "
            + "VALUES(?, ?)";

    public SpringJdbcCacheStore(DataSource dataSource) {
        jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    @Override
    public Object load(Object key) {
        return jdbcTemplate.getJdbcOperations().queryForObject(SELECT_ONE_SQL,
                new Object[] { key }, String.class);
    }

    @SuppressWarnings("rawtypes")
    public Map loadAll(Collection keys) {
        
        final Map<String, String> result = new HashMap<String, String>();
        
        RowMapper<String[]> rowmapper = new RowMapper<String[]>() {
            @Override
            public String[] mapRow(ResultSet rs, int rowNum) throws SQLException {
                result.put(rs.getString(1), rs.getString(2));
                return null;
            }
        };

        Map<String, Object> params = new HashMap<>();
        params.put("keys", keys);

        jdbcTemplate.query(SELECT_MANY_SQL, params, rowmapper);

        return result;
    }

    @Override
    public void store(Object key, Object value) {
        jdbcTemplate.getJdbcOperations().update(MERGE_SQL, key, value );
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void storeAll(@SuppressWarnings("rawtypes") Map map) {
        
        List<Object[]> batchValues = new ArrayList<>(map.size());
        for (Map.Entry<String,String> entry : ((Map<String,String>) map).entrySet()) {
            batchValues.add(new Object[] { 
                    entry.getKey(), entry.getValue() });
        }
        jdbcTemplate.getJdbcOperations().batchUpdate(MERGE_SQL, batchValues);
    }

    @Override
    public void erase(Object key) {
        jdbcTemplate.getJdbcOperations().update(DELETE_ONE_SQL, key);
    }

    @Override
    public void eraseAll(@SuppressWarnings("rawtypes") Collection keys) {
        
        Map<String, Object> params = new HashMap<>();
        params.put("keys", keys);

        jdbcTemplate.update(DELETE_MANY_SQL, params);
    }
}
