package org.cohbook.persistence.cachectrldstore;

import com.tangosol.net.CacheFactory;

public class CacheEnablementStatusChecker implements EnablementStatusChecker {

    public static final String CONTROLCACHE = "control-cache";
    private final String key;
    
    public CacheEnablementStatusChecker(String key) {
        this.key = key;
    }

    @Override
    public boolean isEnabled() {
        Boolean enabled = (Boolean) CacheFactory.getCache(CONTROLCACHE).get(key);
        return enabled == null ? false : enabled;
    }

}
