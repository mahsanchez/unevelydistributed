package org.cohbook.serialisation.codec;

import java.io.IOException;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.reflect.Codec;

public abstract class AbstractEnumOrdinalCodec implements Codec {
    
    private final Class<?> enumType;

    protected AbstractEnumOrdinalCodec(Class<?> enumType) {
        this.enumType = enumType;
    }

    @Override
    public Object decode(PofReader pofreader, int i) throws IOException {
        int ordinal = pofreader.readInt(i);
        for (Object e : enumType.getEnumConstants()) {
            if (ordinal == ((Enum<?>)e).ordinal()) {
                return e;
            }
        }
        throw new IllegalArgumentException(
                "invalid ordinal " + ordinal + " for type " + enumType.getName()) ;
    }

    @Override
    public void encode(PofWriter pofwriter, int i, Object obj)
            throws IOException {
        pofwriter.writeInt(i, ((Enum<?>)obj).ordinal()); 
    }
}
