package org.cohbook.serialisation.filter;

import com.tangosol.io.pof.reflect.SimplePofPath;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.PofExtractor;
import com.tangosol.util.filter.EqualsFilter;

/**
 * Version of IsNullFilter that accepts a ValueExtractor
 *
 */
public class EqNullFilter extends EqualsFilter {

    private static final long serialVersionUID = 8430960903861739875L;

    public EqNullFilter() {
    }

    public EqNullFilter(ValueExtractor extractor) {
        super(extractor, null);
    }
    
    public EqNullFilter(int pofindex) {
        super(new PofExtractor(null, pofindex), null);
    }
    
    public EqNullFilter(int[] pofIndexes) {
        super(new PofExtractor(null, new SimplePofPath(pofIndexes)), null);
    }

}
