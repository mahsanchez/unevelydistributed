package org.cohbook.serialisation.domain;

import java.io.IOException;
import java.util.List;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;

public class ListHolder2 implements PortableObject {
    
    private List<Integer> list;

    public ListHolder2() {
    }

    public ListHolder2(List<Integer> list) {
        this.list = list;
    }

    public List<Integer> getList() {
        return list;
    }

    public void setList(List<Integer> list) {
        this.list = list;
    }

    @Override
    public void readExternal(PofReader pofreader) throws IOException {
        list = (List<Integer>) pofreader.readCollection(0, null);
    }

    @Override
    public void writeExternal(PofWriter pofwriter) throws IOException {
        pofwriter.writeCollection(0, list, Integer.class);
    }
    

}
