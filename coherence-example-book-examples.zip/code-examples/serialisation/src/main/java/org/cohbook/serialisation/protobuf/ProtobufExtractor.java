package org.cohbook.serialisation.protobuf;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map.Entry;

import com.google.protobuf.CodedInputStream;
import com.google.protobuf.Descriptors;
import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.extractor.EntryExtractor;

public class ProtobufExtractor extends EntryExtractor {
    
    private static final long serialVersionUID = -8790143507306877309L;
    private int[] fields;
    private Descriptors.FieldDescriptor.Type fieldType;
    
    public ProtobufExtractor() {
    }

    public ProtobufExtractor(int nTarget, int fields[], Descriptors.FieldDescriptor.Type fieldType) {
        super(nTarget);
        this.fields = fields;
        this.fieldType = fieldType;
    }
    
    // Start field numbers from 10 to avoid collisions with superclass
    private static final int FIELDS_INDEX = 10;
    private static final int FIELDTYPE_INDEX = 11;

    @Override
    public void readExternal(PofReader in) throws IOException {
        super.readExternal(in);
        fields = in.readIntArray(FIELDS_INDEX);
        fieldType = Descriptors.FieldDescriptor.Type.valueOf(in.readString(FIELDTYPE_INDEX));
    }

    @Override
    public void writeExternal(PofWriter out) throws IOException {
        super.writeExternal(out);
        out.writeIntArray(FIELDS_INDEX, fields);
        out.writeString(FIELDTYPE_INDEX, fieldType.name());
    }

    @Override
    public Object extractFromEntry(@SuppressWarnings("rawtypes") Entry untypedentry) {
        BinaryEntry entry = (BinaryEntry) untypedentry;
        
        Binary bin;
        switch (super.m_nTarget) {
        case KEY:
            bin = entry.getBinaryKey();
            break;
        case VALUE:
            bin = entry.getBinaryValue();
            break;
        default:
            throw new RuntimeException("invalid target " + m_nTarget);    
        }
        
        CodedInputStream stream = CodedInputStream.newInstance(bin.toByteArray());
        
        try {
            return readFieldFromMessageStream(stream, fields);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    private Object readFieldFromMessageStream(CodedInputStream stream, int[] fields) throws IOException {
        int nextField = fields[0];
        int rtag;
        while ((rtag = stream.readTag()) != 0) {
            int fieldRead = WireFormat.getTagFieldNumber(rtag);
            if (fieldRead == nextField) {
                if (fields.length == 1) {
                    return WireFormat.readField(stream, rtag, fieldType);
                } else {
                    return readFieldFromMessageStream(stream, Arrays.copyOfRange(fields, 1, fields.length));
                }
            } else {
                stream.skipField(rtag);
            }
        }
        return null;
        
    }

    @Override
    public Object extractOriginalFromEntry(
            com.tangosol.util.MapTrigger.Entry entry) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((fieldType == null) ? 0 : fieldType.hashCode());
        result = prime * result + Arrays.hashCode(fields);
        result = prime * result + m_nTarget;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ProtobufExtractor other = (ProtobufExtractor) obj;
        if (fieldType != other.fieldType) {
            return false;
        }
        if (!Arrays.equals(fields, other.fields)) {
            return false;
        }
        if (m_nTarget != other.m_nTarget) {
            return false;
        }
        return true;
    }
    
    
}
