package org.cohbook.serialisation.filter;

import com.tangosol.util.ValueExtractor;
import com.tangosol.util.filter.NotEqualsFilter;

/**
 * Version of IsNullFilter that accepts a ValueExtractor
 *
 */
public class NotNullFilter extends NotEqualsFilter {

    private static final long serialVersionUID = 8430960903861739875L;

    public NotNullFilter() {
    }

    public NotNullFilter(ValueExtractor extractor) {
        super(extractor, null);
    }

}
