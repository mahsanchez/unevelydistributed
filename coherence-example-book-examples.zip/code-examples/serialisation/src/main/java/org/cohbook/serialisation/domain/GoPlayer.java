package org.cohbook.serialisation.domain;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;

@Portable
public class GoPlayer implements Player {

    public static final int POF_DAN = 11;
    private String firstName;
    private String lastName;
    private int dan;
    
    public GoPlayer() {
    }

    public GoPlayer(String firstName, String lastName, int dan) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dan = dan;
    }

    @Override
    @PortableProperty(POF_FIRSTNAME) public String getFirstName() {
        return firstName;
    }

    @Override
    @PortableProperty(POF_LASTNAME) public String getLastName() {
        return lastName;
    }

    @PortableProperty(POF_DAN) public int getDan() {
        return dan;
    }

    public void setDan(int dan) {
        this.dan = dan;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + dan;
        result = prime * result
                + ((firstName == null) ? 0 : firstName.hashCode());
        result = prime * result
                + ((lastName == null) ? 0 : lastName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        GoPlayer other = (GoPlayer) obj;
        if (dan != other.dan) {
            return false;
        }
        if (firstName == null) {
            if (other.firstName != null) {
                return false;
            }
        } else if (!firstName.equals(other.firstName)) {
            return false;
        }
        if (lastName == null) {
            if (other.lastName != null) {
                return false;
            }
        } else if (!lastName.equals(other.lastName)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "GoPlayer [firstName=" + firstName + ", lastName=" + lastName
                + ", dan=" + dan + "]";
    }

}
