package org.cohbook.serialisation.filter;

import com.tangosol.io.pof.reflect.PofNavigator;
import com.tangosol.util.extractor.PofExtractor;
import com.tangosol.util.filter.AndFilter;
import com.tangosol.util.filter.EqualsFilter;

public class TypeEqualsFilter extends AndFilter {

    private static final long serialVersionUID = 1L;

    public TypeEqualsFilter(int typeId, int target, PofNavigator navigator, Object value) {
        super(
                new PofTypeIdFilter(typeId, target, navigator),
                new EqualsFilter(new PofExtractor(null, navigator, target), value));
    }

}
