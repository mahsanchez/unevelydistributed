package org.cohbook.serialisation.protobuf;

import java.io.IOException;
import java.io.OutputStream;

import org.cohbook.serialisation.protobuf.Player;
import org.cohbook.serialisation.protobuf.Player.ChessPlayer;
import org.cohbook.serialisation.protobuf.Player.GoPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.tangosol.io.ReadBuffer.BufferInput;
import com.tangosol.io.Serializer;
import com.tangosol.io.WriteBuffer.BufferOutput;
import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.util.Binary;
import com.tangosol.util.ExternalizableHelper;

public class ProtobufSerialiser implements Serializer {
    
    private Serializer pofDelegate = new ConfigurablePofContext("org/cohbook/serialisation/protobuf/protobuf-pof-config.xml");
    
    private static final Logger LOG = LoggerFactory.getLogger(ProtobufSerialiser.class);
    
    @Override
    public void serialize(final BufferOutput bufferoutput, final Object obj)
            throws IOException {
        
        OutputStream output = ExternalizableHelper.getOutputStream(bufferoutput);
        
        Player.Wrapper.Builder wrapperBuilder = Player.Wrapper.newBuilder();
        
        if (obj instanceof ChessPlayer) {
            wrapperBuilder.setChessPlayer((ChessPlayer) obj);
            wrapperBuilder.setType(Player.Wrapper.MessageType.CHESSPLAYER);
            wrapperBuilder.build().writeDelimitedTo(output);
        } else if (obj instanceof GoPlayer) {
            wrapperBuilder.setGoPlayer((GoPlayer) obj);
            wrapperBuilder.setType(Player.Wrapper.MessageType.GOPLAYER);
            wrapperBuilder.build().writeDelimitedTo(output);
        } else {
            wrapperBuilder.setPofStream(ByteString.copyFrom(
                    ExternalizableHelper.toBinary(obj, pofDelegate).toByteArray()));
            wrapperBuilder.setType(Player.Wrapper.MessageType.POFSTREAM);
            wrapperBuilder.build().writeDelimitedTo(output);
        }
        
//        LOG.debug("serialised {} to buffer:{}", obj.getClass(), bufferoutput.getBuffer().toByteArray());
        
    }

    @Override
    public Object deserialize(final BufferInput bufferinput) throws IOException {
        
        LOG.debug("deserialse from buffer:{}", bufferinput.getBuffer().toByteArray());
        Player.Wrapper wrapper = Player.Wrapper.parseDelimitedFrom(ExternalizableHelper.getInputStream(bufferinput));
        
        switch (wrapper.getType()) {
        case GOPLAYER:
            return wrapper.getGoPlayer();
        case CHESSPLAYER:
            return wrapper.getChessPlayer();
        case POFSTREAM:
            return ExternalizableHelper.fromBinary(new Binary(wrapper.getPofStream().toByteArray()), pofDelegate);
        default:
            throw new RuntimeException("unexpected message type: " + wrapper.getType());
        }
    }
}
