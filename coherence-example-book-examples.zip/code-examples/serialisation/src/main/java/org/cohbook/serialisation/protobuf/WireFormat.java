package org.cohbook.serialisation.protobuf;

import java.io.IOException;

import com.google.protobuf.CodedInputStream;
import com.google.protobuf.Descriptors;


public class WireFormat {

    private WireFormat() {}

    public static final int WIRETYPE_VARINT           = 0;
    public static final int WIRETYPE_FIXED64          = 1;
    public static final int WIRETYPE_LENGTH_DELIMITED = 2;
    public static final int WIRETYPE_START_GROUP      = 3;
    public static final int WIRETYPE_END_GROUP        = 4;
    public static final int WIRETYPE_FIXED32          = 5;

    static final int TAG_TYPE_BITS = 3;
    static final int TAG_TYPE_MASK = (1 << TAG_TYPE_BITS) - 1;

    /** Given a tag value, determines the wire type (the lower 3 bits). */
    static int getTagWireType(final int tag) {
        return tag & TAG_TYPE_MASK;
    }

    /** Given a tag value, determines the field number (the upper 29 bits). */
    public static int getTagFieldNumber(final int tag) {
        return tag >>> TAG_TYPE_BITS;
    }

    /** Makes a tag value given a field number and wire type. */
    static int makeTag(final int fieldNumber, final int wireType) {
        return (fieldNumber << TAG_TYPE_BITS) | wireType;
    }

    // Field numbers for feilds in MessageSet wire format.
    static final int MESSAGE_SET_ITEM    = 1;
    static final int MESSAGE_SET_TYPE_ID = 2;
    static final int MESSAGE_SET_MESSAGE = 3;

    // Tag numbers.
    static final int MESSAGE_SET_ITEM_TAG =
            makeTag(MESSAGE_SET_ITEM, WIRETYPE_START_GROUP);
    static final int MESSAGE_SET_ITEM_END_TAG =
            makeTag(MESSAGE_SET_ITEM, WIRETYPE_END_GROUP);
    static final int MESSAGE_SET_TYPE_ID_TAG =
            makeTag(MESSAGE_SET_TYPE_ID, WIRETYPE_VARINT);
    static final int MESSAGE_SET_MESSAGE_TAG =
            makeTag(MESSAGE_SET_MESSAGE, WIRETYPE_LENGTH_DELIMITED);

    public static Object readField(final CodedInputStream stream, final int tag, final Descriptors.FieldDescriptor.Type fieldType) throws IOException {
        switch (WireFormat.getTagWireType(tag)) {
        case WireFormat.WIRETYPE_VARINT:
            return stream.readInt32();
        case WireFormat.WIRETYPE_FIXED64:
            return stream.readRawLittleEndian64();
        case WireFormat.WIRETYPE_LENGTH_DELIMITED:
            switch (fieldType) {
            case STRING:
                return stream.readString();
            case MESSAGE:
                return null;
            case GROUP:
                return null;
            default:
                return null;
            }
        case WireFormat.WIRETYPE_START_GROUP:
            stream.skipField(tag);
            return null;
        case WireFormat.WIRETYPE_END_GROUP:
            return null;
        case WireFormat.WIRETYPE_FIXED32:
            return stream.readRawLittleEndian32();
        default:
            throw new RuntimeException("invalid wire type");
        }

    }

}
