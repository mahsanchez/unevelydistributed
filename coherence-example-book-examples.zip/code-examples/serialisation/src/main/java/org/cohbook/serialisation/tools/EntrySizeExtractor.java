package org.cohbook.serialisation.tools;

import java.util.Map.Entry;

import com.tangosol.net.cache.BinaryMemoryCalculator;
import com.tangosol.net.cache.ConfigurableCacheMap;
import com.tangosol.net.cache.ConfigurableCacheMap.UnitCalculator;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.MapIndex;
import com.tangosol.util.SimpleMapIndex;
import com.tangosol.util.SimpleMapIndex.IndexCalculator;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.EntryExtractor;

public class EntrySizeExtractor extends EntryExtractor {

    private static final long serialVersionUID = 270960358069534844L;
    
    public static final EntrySizeExtractor INSTANCE = new EntrySizeExtractor();

    @Override
    public Object extractFromEntry(@SuppressWarnings("rawtypes") Entry entry) {
        BinaryEntry binaryEntry = (BinaryEntry) entry;
        
        UnitCalculator calculator = BinaryMemoryCalculator.INSTANCE;
//        UnitCalculator calculator = ((ConfigurableCacheMap)binaryEntry.getBackingMapContext().getBackingMap()).getUnitCalculator();
        int result = calculator.calculateUnits(
                binaryEntry.getBinaryKey(), binaryEntry.getBinaryValue());
        
        for (MapIndex index : binaryEntry.getBackingMapContext().getIndexMap().values()) {
            Object indexedValue = index.get(binaryEntry.getBinaryKey());
            UnitCalculator indexCalculator = (IndexCalculator) ((SimpleMapIndex)index).getCalculator();
            result += indexCalculator.calculateUnits(null, indexedValue);
            
        }
        return result;
        
    }
}
