package org.cohbook.serialisation.filter;

import java.util.Map.Entry;

import com.tangosol.io.pof.PofContext;
import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.io.pof.reflect.PofNavigator;
import com.tangosol.io.pof.reflect.PofValue;
import com.tangosol.io.pof.reflect.PofValueParser;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.filter.EntryFilter;

/**
 * Filter to test the concrete type of a key or value in the cache. Can be used to test either
 * the key or the value in the cache. If a {@code PofNavigator} (such as an {@link AnnotationReflectionPofPath}
 * the filter can examine the type of a value within the object, rather than the object itself.
 * <p>
 * A class object and {@link PofIntrospector} must be supplied for determination of the POF Type id, this happens
 * only on the application/client side - once in the grid comparisons are made based on the typeId
 * obtained by the constructor of this class.
 * 
 * @author whitmard
 *
 */
@Portable
public class PofTypeIdFilter implements EntryFilter {
    
    @PortableProperty(0) private int typeId;
    @PortableProperty(1) private int target;
    @PortableProperty(2) private PofNavigator navigator;
    
    public PofTypeIdFilter() {
        super();
    }

    /**
     * Deserialiser constructor.
     * @param typeId the type id
     * @param target target, key or value
     * @param navigator the navigator
     */
    public PofTypeIdFilter(
            int typeId,
            int target,
            PofNavigator navigator) {
        this.typeId = typeId;
        this.target = target;
        this.navigator = navigator;
    }

    @Override
    public boolean evaluateEntry(@SuppressWarnings("rawtypes") Entry entry) {
        BinaryEntry binEntry = (BinaryEntry) entry;
        PofContext ctx = (PofContext) binEntry.getSerializer();
        com.tangosol.util.Binary binTarget;
        switch (target) {
            case AbstractExtractor.KEY:
                binTarget = binEntry.getBinaryKey();
                break;
            case AbstractExtractor.VALUE:
                binTarget = binEntry.getBinaryValue();
                break;
            default:
                throw new IllegalArgumentException("invalid target");    
        }
        
        PofValue value = PofValueParser.parse(binTarget, ctx);
        
        if (navigator != null) {
            value = navigator.navigate(value);
        }

        if (value == null) {
            return false;
        }
        
        int valueType = value.getTypeId();
        
        return valueType == typeId;

    }
    
    @Override
    public boolean evaluate(Object obj) {
        throw new UnsupportedOperationException();
    }
}
