package org.cohbook.serialisation.filter;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.tangosol.io.pof.annotation.PortableProperty;

public class POFAnnotationUtils {

    private POFAnnotationUtils() {
    }
    
    public static PortableProperty getMethodAnnotation(final Class<?> clazz, final String methodName) {
        Method getterMethod;
        try {
            getterMethod = clazz.getMethod(methodName);
        } catch (NoSuchMethodException e) {
            return null;
        }
        
        return getterMethod.getAnnotation(PortableProperty.class);
    }
    
    public static PortableProperty getFieldAnnotation(final Class<?> clazz, final String fieldName) {
        Field field = null;
        try {
            field = clazz.getDeclaredField(fieldName);
        } catch (NoSuchFieldException e) {
            return null;
        }
        return field.getAnnotation(PortableProperty.class);
    }
    
    public static int getPofIndexForMethod(final Class<?> clazz, final String methodName) {

        PortableProperty getterAnnotation = getMethodAnnotation(clazz, methodName);
        if (getterAnnotation == null) {
            throw new RuntimeException("method " + methodName + " on class " + clazz.getSimpleName() + " has no PortableProperty annotation");
        }
        
        return getterAnnotation.value();
    }

    static final String PREFIXES[] = { "get", "is" };
    public static int getPofIndexForProperty(Class<?> clazz,
            String propertyName) {
        
        PortableProperty fieldAnnotation = getFieldAnnotation(clazz, propertyName);
        if (fieldAnnotation != null) {
            return fieldAnnotation.value();
        }
        
        String stem = propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
        
        for (String prefix : PREFIXES) {
            PortableProperty methodAnnotation = getMethodAnnotation(clazz, prefix + stem);
            if (methodAnnotation != null) {
                return methodAnnotation.value();
            }
        }
        
        throw new RuntimeException("property " + propertyName + " on class " + clazz.getSimpleName() + " has no PortableProperty annotation");
    }
}
