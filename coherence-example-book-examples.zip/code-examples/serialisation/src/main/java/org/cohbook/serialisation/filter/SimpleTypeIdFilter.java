/**
 * 
 */
package org.cohbook.serialisation.filter;

import java.util.Map.Entry;

import com.tangosol.io.pof.PofContext;
import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.io.pof.reflect.PofValue;
import com.tangosol.io.pof.reflect.PofValueParser;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.filter.EntryFilter;

@Portable
public class SimpleTypeIdFilter implements EntryFilter {
    
    private static final int POF_TYPEID = 0;
    @PortableProperty(POF_TYPEID) private int typeId;

    public SimpleTypeIdFilter() {
    }

    public SimpleTypeIdFilter(
            int typeId) {
        this.typeId = typeId;
    }

    @Override
    public boolean evaluateEntry(@SuppressWarnings("rawtypes") Entry entry) {
        BinaryEntry binEntry = (BinaryEntry) entry;

        PofContext ctx = (PofContext) binEntry.getSerializer();
        
        PofValue value = PofValueParser.parse(binEntry.getBinaryValue(), ctx);

        int valueType = value.getTypeId();
        
        return valueType == typeId;

    }
    
    @Override
    public boolean evaluate(Object obj) {
        throw new UnsupportedOperationException();
    }
}
