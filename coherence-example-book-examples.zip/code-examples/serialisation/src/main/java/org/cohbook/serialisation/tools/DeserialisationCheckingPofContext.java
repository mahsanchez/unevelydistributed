package org.cohbook.serialisation.tools;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import com.tangosol.io.ReadBuffer.BufferInput;
import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.run.xml.XmlElement;

public class DeserialisationCheckingPofContext extends ConfigurablePofContext {
    
    private static ConcurrentHashMap<Class<?>, AtomicInteger> deserialisationCount = new ConcurrentHashMap<>();

    public DeserialisationCheckingPofContext() {
    }

    public DeserialisationCheckingPofContext(String sLocator) {
        super(sLocator);
    }

    public DeserialisationCheckingPofContext(XmlElement xml) {
        super(xml);
    }

    @Override
    public Object deserialize(BufferInput in) throws IOException {
        Object result = super.deserialize(in);

        if (result != null) {
            Class<?> resultClass = result.getClass();

            deserialisationCount.putIfAbsent(resultClass, new AtomicInteger(0));
            deserialisationCount.get(resultClass).incrementAndGet();
        }
        return result;
    }
    
    public static Integer getDeserialisationCount(Class<?> clazz) {
        AtomicInteger counter = deserialisationCount.get(clazz);
        return counter == null ? 0 : counter.getAndSet(0);
    }

}
