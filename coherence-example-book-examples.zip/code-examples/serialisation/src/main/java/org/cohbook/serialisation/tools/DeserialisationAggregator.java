package org.cohbook.serialisation.tools;

import java.util.Collection;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.net.CacheFactory;
import com.tangosol.util.InvocableMap.EntryAggregator;
import com.tangosol.util.InvocableMap.ParallelAwareAggregator;

@Portable
public class DeserialisationAggregator implements ParallelAwareAggregator {

    private static final Logger LOG = LoggerFactory.getLogger(DeserialisationAggregator.class);
    
    private static final long serialVersionUID = -9189801674964868965L;
    @PortableProperty(0) private String className;
    
    public DeserialisationAggregator() {
    }

    public DeserialisationAggregator(Class<?> clazz) {
        this.className = clazz.getName();
    }

    @Override
    public Object aggregate(@SuppressWarnings("rawtypes") Set set) {
        Class<?> clazz;
        try {
            clazz = Class.forName(className);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        
        int count = DeserialisationCheckingPofContext.getDeserialisationCount(clazz);

        LOG.info("Class " + clazz.getSimpleName() + " had " + count +
                    " deserialisations on member " + CacheFactory.getCluster().getLocalMember().getId());
        return count;
    }

    @Override
    public EntryAggregator getParallelAggregator() {
        return this;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object aggregateResults(@SuppressWarnings("rawtypes") Collection collection) {
        Integer total = 0;
        for (Integer partial : (Collection<Integer>) collection) {
            total += partial;
        }
        return total;
    }
}
