package org.cohbook.serialisation.domain;

import java.io.IOException;
import java.util.List;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;

public class ListHolder3 implements PortableObject {
    
    private List<? extends Number> list;

    public ListHolder3() {
    }

    public ListHolder3(List<? extends Number> list) {
        this.list = list;
    }

    public List<? extends Number> getList() {
        return list;
    }

    public void setList(List<? extends Number> list) {
        this.list = list;
    }

    @Override
    public void readExternal(PofReader pofreader) throws IOException {
        list = (List<? extends Number>) pofreader.readCollection(0, null);
    }

    @Override
    public void writeExternal(PofWriter pofwriter) throws IOException {
        pofwriter.writeCollection(0, list);
    }
}
