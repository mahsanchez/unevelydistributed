package org.cohbook.serialisation.domain;

public enum GoRating {
    first_dan, second_dan, third_dan, fourth_dan,
    fifth_dan, sixth_dan, seventh_dan, eighth_dan, ninth_dan
}
