package org.cohbook.serialisation.codec;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.reflect.Codec;

public class LinkedHashMapCodec implements Codec {

    @Override
    public Object decode(PofReader pofreader, int i) throws IOException {
        return pofreader.readMap(i, new LinkedHashMap<>());
    }

    @Override
    public void encode(PofWriter pofwriter, int i, Object obj)
            throws IOException {
        pofwriter.writeMap(i, (Map)obj, String.class, String.class);
    }

}
