package org.cohbook.serialisation.domain;


public interface Player {
    
    public static final int POF_FIRSTNAME = 0;
    public static final int POF_LASTNAME = 1;
    
    String getFirstName();

    String getLastName();

}
