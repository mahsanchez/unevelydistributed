package org.cohbook.serialisation.filter;

import com.tangosol.util.extractor.PofExtractor;

public class MethodPofExtractor extends PofExtractor {

    private static final long serialVersionUID = -3763865803327976626L;

    public MethodPofExtractor() {
    }

    public MethodPofExtractor(Class<?> clz, String methodName) {
        super(clz, POFAnnotationUtils.getPofIndexForMethod(clz, methodName));
    }

}
