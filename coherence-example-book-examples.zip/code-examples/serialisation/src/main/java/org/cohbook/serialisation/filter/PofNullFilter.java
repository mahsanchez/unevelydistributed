package org.cohbook.serialisation.filter;

import com.tangosol.io.pof.PofConstants;
import com.tangosol.io.pof.reflect.PofNavigator;

public class PofNullFilter extends PofTypeIdFilter {

    public PofNullFilter() {
    }

    public PofNullFilter(int target, PofNavigator navigator) {
        super(PofConstants.V_REFERENCE_NULL, target, navigator);
    }

}
