package org.cohbook.serialisation.filter;

import com.tangosol.util.extractor.PofExtractor;

public class PropertyPofExtractor extends PofExtractor {

    private static final long serialVersionUID = -3763865803327976626L;

    public PropertyPofExtractor() {
    }

    public PropertyPofExtractor(Class<?> clz, String propertyName) {
        super(clz, POFAnnotationUtils.getPofIndexForProperty(clz, propertyName));
    }

}
