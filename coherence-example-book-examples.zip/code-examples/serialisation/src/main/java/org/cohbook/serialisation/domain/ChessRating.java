package org.cohbook.serialisation.domain;

public enum ChessRating {
    candidate_master, master, grand_master, international_master
}
