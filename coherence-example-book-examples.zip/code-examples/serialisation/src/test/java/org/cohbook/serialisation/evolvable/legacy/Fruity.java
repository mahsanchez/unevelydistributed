package org.cohbook.serialisation.evolvable.legacy;

import com.tangosol.io.AbstractEvolvable;
import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;

@Portable
public class Fruity extends AbstractEvolvable {

    public static final int POF_NAME = 0;
    public static final int POF_FRUIT = 1;
    @PortableProperty(POF_NAME) private String name;
    @PortableProperty(POF_FRUIT) private String favouriteFruit;
    
    public Fruity() {
    }

    public Fruity(String name, String favouriteFruit) {
        this.name = name;
        this.favouriteFruit = favouriteFruit;
    }

    @Override
    public int getImplVersion() {
        return 2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFavouriteFruit() {
        return favouriteFruit;
    }

    public void setFavouriteFruit(String favouriteFruit) {
        this.favouriteFruit = favouriteFruit;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((favouriteFruit == null) ? 0 : favouriteFruit.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Fruity other = (Fruity) obj;
        if (favouriteFruit == null) {
            if (other.favouriteFruit != null) {
                return false;
            }
        } else if (!favouriteFruit.equals(other.favouriteFruit)) {
            return false;
        }
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        return true;
    }

}
