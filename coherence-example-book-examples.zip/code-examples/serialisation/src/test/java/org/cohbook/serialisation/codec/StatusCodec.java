package org.cohbook.serialisation.codec;

import org.cohbook.serialisation.codec.CodecValueObject.Status;

public class StatusCodec extends AbstractEnumOrdinalCodec {

    public StatusCodec() {
        super(Status.class);
    }

}
