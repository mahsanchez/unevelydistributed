package org.cohbook.serialisation.tools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.cohbook.serialisation.domain.GoPlayer;
import org.cohbook.serialisation.tools.DeserialisationAggregator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.aggregator.LongMax;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.AndFilter;
import com.tangosol.util.filter.EqualsFilter;

public class TestTrackWithIndex {

    private ClusterMemberGroup memberGroup;
    private NamedCache cache;
    private static final int ENTRIES = 2000;

    @Before
    public void setup() {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(2)
                .setCacheConfiguration("org/cohbook/serialisation/tools/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();

        cache = CacheFactory.getCache("test");
        
        for (int i = 0; i < ENTRIES; i++) {
            cache.put(i, new GoPlayer("THX", Integer.valueOf(i).toString(), 9));
        }
        
        cache.addIndex(new ReflectionExtractor("getLastName"), false, null);
        
        // clear the counters
        cache.aggregate(AlwaysFilter.INSTANCE, new DeserialisationAggregator(GoPlayer.class));
    }
    
    @After
    public void teardown() {
        CacheFactory.shutdown();
        memberGroup.stopAll();
    }
    
    
    @Test
    public void testGetOne() {

        Filter firstNameFilter = new EqualsFilter("getFirstName", "THX");
        Filter lastNameFilter = new EqualsFilter("getLastName", "1138");
        
        int resultSetSize = cache.keySet(
                new AndFilter(firstNameFilter, lastNameFilter))
                .size();
        
        assertEquals(1, resultSetSize);

        int deserial = (int) cache.aggregate(
                AlwaysFilter.INSTANCE,
                new DeserialisationAggregator(GoPlayer.class));

        assertEquals(1, deserial);
    }
    
    @Test
    public void testMemberFail() {
        
        int firstMember = memberGroup.getStartedMemberIds()[0];
        
        memberGroup.stopMember(firstMember);
        
        int deserial = (int) cache.aggregate(
                AlwaysFilter.INSTANCE,
                new DeserialisationAggregator(GoPlayer.class));
        
        System.out.println("deserialised " + deserial + " entries");
        
        assertTrue(deserial > 0);
    }
    
    @Test
    public void testGetMaxSize() {
        
        Long maxsize = (Long) cache.aggregate(AlwaysFilter.INSTANCE, new LongMax(EntrySizeExtractor.INSTANCE));
        
        System.out.println("max size is " + maxsize);
        
        assertTrue(maxsize > 0l);
    }
}
