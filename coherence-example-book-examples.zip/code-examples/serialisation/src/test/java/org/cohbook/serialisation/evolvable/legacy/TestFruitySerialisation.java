package org.cohbook.serialisation.evolvable.legacy;

import java.io.IOException;

import org.cohbook.serialisation.poftest.SerialisationTestHelper;
import org.junit.Test;


public class TestFruitySerialisation {

    private SerialisationTestHelper serialisationTestHelper;
    
    public TestFruitySerialisation() {
        serialisationTestHelper = new SerialisationTestHelper("org/cohbook/serialisation/evolvable/legacy/fruity-pof-config.xml");
    }

    @Test
    public void testFruitySerialisation() throws IOException {
        
        Object object = new Fruity("Mark", "Grapes");

//        serialisationTestHelper.saveBinary(object, "mark-grapes.bin");
        
        serialisationTestHelper.equalsCheckSerialisation(object);
        
    }

}
