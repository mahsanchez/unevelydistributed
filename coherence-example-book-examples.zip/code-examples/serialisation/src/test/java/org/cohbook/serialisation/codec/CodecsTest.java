package org.cohbook.serialisation.codec;

import org.cohbook.serialisation.codec.CodecValueObject.Status;
import org.cohbook.serialisation.domain.GoPlayer;
import org.cohbook.serialisation.domain.Person;
import org.cohbook.serialisation.poftest.SerialisationTestHelper;
import org.junit.Test;


public class CodecsTest {
    
    private SerialisationTestHelper serialisationTestHelper;

    public CodecsTest() {
        serialisationTestHelper = new SerialisationTestHelper(
                "/org/cohbook/serialisation/codec/codec-test-pof-config.xml");
    }

    @Test
    public void testCodecValueObject() {
        serialisationTestHelper.equalsCheckSerialisation(
                new CodecValueObject(42, Status.failure, new RuntimeException("test exception")));
    }
    
}
