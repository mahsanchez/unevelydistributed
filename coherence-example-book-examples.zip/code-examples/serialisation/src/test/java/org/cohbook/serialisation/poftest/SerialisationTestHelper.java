package org.cohbook.serialisation.poftest;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.junit.Assert;

import com.tangosol.io.Serializer;
import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.util.Binary;
import com.tangosol.util.ExternalizableHelper;

public class SerialisationTestHelper {

    private final Serializer serialiser;
    
    public SerialisationTestHelper(String configFileName) {
        this.serialiser = new ConfigurablePofContext(configFileName);
    }

    public SerialisationTestHelper(Serializer serializer) {
        this.serialiser = serializer;
    }
    
    public void equalsCheckSerialisation(Object object) {
        
        Binary binaryObject = ExternalizableHelper.toBinary(object, serialiser);
        
        Object objectAgain = ExternalizableHelper.fromBinary(binaryObject, serialiser);
        
        Assert.assertEquals(object, objectAgain);
    }
    
    public void reflectionCheckSerialisation(Object object) {
        
        Binary binaryObject = ExternalizableHelper.toBinary(object, serialiser);
        
        Object objectAgain = ExternalizableHelper.fromBinary(binaryObject, serialiser);
        
        Assert.assertTrue(EqualsBuilder.reflectionEquals(object, objectAgain));
    }
    
    public void saveBinary(Object object, String fileName) throws IOException {

        Binary binaryObject = ExternalizableHelper.toBinary(object, serialiser);
        
        byte bytes[]  = binaryObject.toByteArray();
        
        try (OutputStream os = new FileOutputStream(fileName)) {
            os.write(bytes);
        }
    }
    
    public void equalsSavedBinary(Object object, String fileName) throws IOException {
        
        Binary binaryObject = new Binary(getByteArrayFromFile(fileName));
        
        Object objectAgain = ExternalizableHelper.fromBinary(binaryObject, serialiser);
        
        Assert.assertEquals(object, objectAgain);
        
    }
    
    private byte[] getByteArrayFromFile(String fileName) throws IOException {

        try (InputStream input = new FileInputStream(fileName);
                ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int n = 0;
            while (-1 != (n = input.read(buffer))) {
                output.write(buffer, 0, n);
            }
            return output.toByteArray();
        }
    }
}
