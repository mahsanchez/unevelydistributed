package org.cohbook.serialisation.codec;

import java.util.LinkedHashMap;
import java.util.Map;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;

@Portable
public class CodecValueObject {
    
    public enum Status { success, failure };
    
    @PortableProperty(0)
    private int jobNumber;
    
    @PortableProperty(value=1, codec=StatusCodec.class)
    private Status status; 
    
    @PortableProperty(value=2, codec=SerialiserCodec.class)
    private Exception failureReason;
    
    @PortableProperty(value=3, codec=LinkedHashMapCodec.class)
    private Map<String,String> params;

    public CodecValueObject() {
    }

    public CodecValueObject(int jobNumber, Status status,
            Exception failureReason) {
        this.jobNumber = jobNumber;
        this.status = status;
        this.failureReason = failureReason;
        this.params = new LinkedHashMap<>();
    }

    public int getJobNumber() {
        return jobNumber;
    }

    public Status getStatus() {
        return status;
    }

    public Exception getFailureReason() {
        return failureReason;
    }

    public Map<String, String> getParams() {
        return params;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((failureReason == null) ? 0 : failureReason.getMessage().hashCode());
        result = prime * result + jobNumber;
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        CodecValueObject other = (CodecValueObject) obj;
        if (failureReason == null) {
            if (other.failureReason != null) {
                return false;
            }
        } else if (!failureReason.getMessage().equals(other.failureReason.getMessage())) {
            return false;
        }
        if (jobNumber != other.jobNumber) {
            return false;
        }
        if (status != other.status) {
            return false;
        }
        return true;
    }
    
    

}
