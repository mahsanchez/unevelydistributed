package org.cohbook.serialisation.poftest;

import java.util.ArrayList;
import java.util.List;

import org.cohbook.serialisation.domain.ListHolder1;
import org.cohbook.serialisation.domain.ListHolder2;
import org.cohbook.serialisation.domain.ListHolder3;
import org.cohbook.serialisation.domain.ListHolder4;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.io.pof.PofContext;
import com.tangosol.util.Binary;
import com.tangosol.util.ExternalizableHelper;
import com.tangosol.util.WrapperException;

public class TestUniformCollection {
    
    private PofContext pofContext = new ConfigurablePofContext("pof-config.xml");
    private static final Logger LOG = LoggerFactory.getLogger(TestUniformCollection.class);
    
    @Test
    public void checkIntListSized() {
        
        List<Integer> intList = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            intList.add(i);
        }
        
        ListHolder1 lh1 = new ListHolder1(intList);
        ListHolder2 lh2 = new ListHolder2(intList);
        
        Binary lh1b = ExternalizableHelper.toBinary(lh1, pofContext);
        int l1 = lh1b.length();
        
        LOG.info("non-uniform collection serialised size=" + l1);
        
        int l2 = ExternalizableHelper.toBinary(lh2, pofContext).length();
        
        LOG.info("uniform collection serialised size=" + l2);
        
        Assert.assertTrue(l1 > l2);
        
        ListHolder1 lh1x = (ListHolder1) ExternalizableHelper.fromBinary(lh1b, pofContext);
        
        LOG.info("deserialised class is " + lh1.getList().getClass().getCanonicalName());
    }
    
    @Test
    public void checkNumberList() {
        
        List<Number> intList = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            intList.add(Integer.valueOf(2 * i));
            intList.add(Short.valueOf((short)(2 * i + 1)));
        }
        
        ListHolder3 lh3 = new ListHolder3(intList);
        
        int l3 = ExternalizableHelper.toBinary(lh3, pofContext).length();
        
        LOG.info("polymorphic collection serialised size=" + l3);
        
    }
    
    @Test(expected=WrapperException.class)
    public void checkUniformNumberList() {
        
        List<Number> intList = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            intList.add(Integer.valueOf(2 * i));
            intList.add(Short.valueOf((short)(2 * i + 1)));
        }
        
        ListHolder4 lh4 = new ListHolder4(intList);
        
        Binary l4b = ExternalizableHelper.toBinary(lh4, pofContext);
        int l4 = l4b.length();
        
        LOG.info("uniform polymorphic collection serialised size=" + l4);
        
        ExternalizableHelper.fromBinary(l4b, pofContext);
        
    }
}
