package org.cohbook.serialisation;


import org.cohbook.serialisation.filter.POFAnnotationUtils;
import org.junit.Assert;
import org.junit.Test;

import com.tangosol.io.pof.annotation.PortableProperty;

public class PofAnnotationUtilsTest {

    private static final int POF_FIELD = 1;
    private static final int POF_GET = 2;
    private static final int POF_IS = 4;

    public static class AnnotatedClass {
        @PortableProperty(POF_FIELD) private int field;
        @PortableProperty(POF_GET) public int getADozen() { return field; };
        @PortableProperty(POF_IS) public boolean isHonestLawyer() { return false; };
    }
    
    @Test
    public void testGetMethodAnnotation() {
        Assert.assertEquals(POF_GET, POFAnnotationUtils.getMethodAnnotation(AnnotatedClass.class, "getADozen").value());
        Assert.assertNull(POFAnnotationUtils.getMethodAnnotation(AnnotatedClass.class, "getHalfADozen"));
    }
    
    @Test
    public void testGetPofIndexForMethod() {
        Assert.assertEquals(POF_GET, POFAnnotationUtils.getPofIndexForMethod(AnnotatedClass.class, "getADozen"));
    }

    @Test(expected=RuntimeException.class)
    public void testGetPofIndexForInvalidMethod() {
        POFAnnotationUtils.getPofIndexForMethod(AnnotatedClass.class, "getHalfADozen");
    }
    
    @Test
    public void testGetFieldProperty() {
        Assert.assertEquals(POF_FIELD, POFAnnotationUtils.getPofIndexForProperty(AnnotatedClass.class, "field"));
    }
    @Test
    public void testGetFieldGetter() {
        Assert.assertEquals(POF_GET, POFAnnotationUtils.getPofIndexForProperty(AnnotatedClass.class, "aDozen"));
    }
    @Test
    public void testGetFieldIs() {
        Assert.assertEquals(POF_IS, POFAnnotationUtils.getPofIndexForProperty(AnnotatedClass.class, "honestLawyer"));
    }
    @Test(expected=RuntimeException.class)
    public void testGetPofIndexForInvalidProperty() {
        POFAnnotationUtils.getPofIndexForProperty(AnnotatedClass.class, "halfADozen");
    }

}
