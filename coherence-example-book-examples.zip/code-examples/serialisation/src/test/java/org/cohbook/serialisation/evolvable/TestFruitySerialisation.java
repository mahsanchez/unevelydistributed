package org.cohbook.serialisation.evolvable;

import java.io.IOException;

import org.cohbook.serialisation.evolvable.Fruity;
import org.cohbook.serialisation.poftest.SerialisationTestHelper;
import org.junit.Test;


public class TestFruitySerialisation {

    private SerialisationTestHelper serialisationTestHelper;
    
    public TestFruitySerialisation() {
        serialisationTestHelper = new SerialisationTestHelper("org/cohbook/serialisation/evolvable/fruity-pof-config.xml");
    }

    @Test
    public void testFruitySerialisation() throws IOException {
        
        Object object = new Fruity("Mark", "Grapes");

        serialisationTestHelper.equalsCheckSerialisation(object);
        
    }

    @Test
    public void testCheesySerialisation() throws IOException {
        
        Object object = new Fruity("Elizabeth", "Banana", "Wensleydale");

        serialisationTestHelper.equalsCheckSerialisation(object);
        
    }
    
    @Test
    public void testFruityEvolvable() throws IOException {

        Object object = new Fruity("Mark", "Grapes");

        serialisationTestHelper.equalsSavedBinary(object, "mark-grapes.bin");
        
    }

}
