package org.cohbook.serialisation.poftest;

import org.cohbook.serialisation.domain.GoPlayer;
import org.cohbook.serialisation.domain.Person;
import org.junit.Test;


public class PersonSerialisationTest {
    
    private SerialisationTestHelper serialisationTestHelper;

    public PersonSerialisationTest() {
        serialisationTestHelper = new SerialisationTestHelper(
                "/org/cohbook/serialisation/domain/person-pof-config.xml");
    }

    @Test
    public void testPersonSerialise() {
        serialisationTestHelper.equalsCheckSerialisation(new Person("Phil", "Wheeler"));
    }
    
    @Test
    public void testGoPlayerSerialise() {
        serialisationTestHelper.equalsCheckSerialisation(new GoPlayer("David", "Whitmarsh", 9));
    }
}
