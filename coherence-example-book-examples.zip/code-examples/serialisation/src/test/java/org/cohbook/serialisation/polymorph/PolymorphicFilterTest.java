package org.cohbook.serialisation.polymorph;

import org.cohbook.serialisation.domain.ChessPlayer;
import org.cohbook.serialisation.domain.GoPlayer;
import org.cohbook.serialisation.filter.SimpleTypeIdFilter;
import org.junit.Assert;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.extractor.PofExtractor;
import com.tangosol.util.filter.AndFilter;
import com.tangosol.util.filter.EqualsFilter;

public class PolymorphicFilterTest {

    @Test
    public void test() {
        ClusterMemberGroup memberGroup = null;
        
        System.setProperty("tangosol.coherence.serializer", "pof");
        
        try {
            memberGroup = ClusterMemberGroupUtils.newBuilder()
                    .setStorageEnabledCount(2)
                    .buildAndConfigureForStorageDisabledClient();
 
            final NamedCache cache = CacheFactory.getCache("test");
            cache.put(1, new ChessPlayer("Phil", "Wheeler", "Grandmaster"));
            cache.put(2, new GoPlayer("David", "Whitmarsh", 9));
            
            Assert.assertEquals(1, cache.keySet(new EqualsFilter(new PofExtractor(String.class, ChessPlayer.POF_FIRSTNAME), "Phil")).size());
            
            ConfigurablePofContext ctx = (ConfigurablePofContext) cache.getCacheService().getSerializer();
            int typeId = ctx.getUserTypeIdentifier(GoPlayer.class);
            Filter goFilter = new AndFilter(new SimpleTypeIdFilter(typeId),
                    new EqualsFilter(new PofExtractor(Integer.class, GoPlayer.POF_DAN), 9));
            Assert.assertEquals(1, cache.keySet(goFilter).size());
 
        } finally {
            CacheFactory.shutdown();
            memberGroup.stopAll();
        }
    }

}
