package org.cohbook.serialisation.tools;

import static org.junit.Assert.assertEquals;

import org.cohbook.serialisation.domain.GoPlayer;
import org.cohbook.serialisation.filter.EqNullFilter;
import org.cohbook.serialisation.filter.PofNullFilter;
import org.cohbook.serialisation.tools.DeserialisationAggregator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.io.pof.reflect.SimplePofPath;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.aggregator.Count;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.PofExtractor;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.EqualsFilter;
import com.tangosol.util.filter.IsNullFilter;

public class TestTrackNullFilter {

    private ClusterMemberGroup memberGroup;
    private NamedCache cache;

    @Before
    public void setup() {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(2)
                .setCacheConfiguration("org/cohbook/serialisation/tools/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();

        cache = CacheFactory.getCache("test");
        
        cache.put(1, new GoPlayer("Honinbo", "Sansa", 9));
        cache.put(2, new GoPlayer("Nakamura", "Doseki", 9));
        cache.put(3, new GoPlayer("Nobuaki Ansai", null, 4));
    }
    
    @After
    public void teardown() {
        CacheFactory.shutdown();
        memberGroup.stopAll();
    }
    
    
    @Test
    public void testIsNullFilter() {
        
        Filter isNullFilter = new IsNullFilter("getLastName");

        int count = (int) cache.aggregate(isNullFilter, new Count());

        assertEquals(1, count);

        int deserial = (int) cache.aggregate(AlwaysFilter.INSTANCE, new DeserialisationAggregator(GoPlayer.class));

        assertEquals(3, deserial);
    }
    
    @Test
    public void testPofNullFilter() {
        
        Filter isNullFilter = new EqualsFilter(new PofExtractor(null, GoPlayer.POF_LASTNAME), null);

        int count = (int) cache.aggregate(isNullFilter, new Count());

        assertEquals(1, count);

        int deserial = (int) cache.aggregate(AlwaysFilter.INSTANCE, new DeserialisationAggregator(GoPlayer.class));

        assertEquals(0, deserial);
    }
    
    @Test
    public void testPofEqNullFilter() {
        
        Filter isNullFilter = new EqNullFilter(GoPlayer.POF_LASTNAME);

        int count = (int) cache.aggregate(isNullFilter, new Count());

        assertEquals(1, count);

        int deserial = (int) cache.aggregate(AlwaysFilter.INSTANCE, new DeserialisationAggregator(GoPlayer.class));

        assertEquals(0, deserial);
    }
    
    @Test
    public void testPofNullTypeIdFilter() {
        
        Filter isNullFilter = new PofNullFilter(
                AbstractExtractor.VALUE,
                new SimplePofPath(GoPlayer.POF_LASTNAME));

        int count = (int) cache.aggregate(isNullFilter, new Count());

        assertEquals(1, count);

        int deserial = (int) cache.aggregate(AlwaysFilter.INSTANCE, new DeserialisationAggregator(GoPlayer.class));

        assertEquals(0, deserial);
    }
}
