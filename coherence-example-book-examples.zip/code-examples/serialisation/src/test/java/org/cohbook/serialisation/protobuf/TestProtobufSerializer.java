package org.cohbook.serialisation.protobuf;

import java.io.IOException;

import org.cohbook.serialisation.poftest.SerialisationTestHelper;
import org.cohbook.serialisation.protobuf.ProtobufSerialiser;
import org.junit.Test;



public class TestProtobufSerializer {

    private SerialisationTestHelper serialisationTestHelper;
    
    public TestProtobufSerializer() {
        serialisationTestHelper = new SerialisationTestHelper(new ProtobufSerialiser());
    }

    @Test
    public void testSerialiseGoPlayer() throws IOException {
        Player.GoPlayer.Builder builder = Player.GoPlayer.newBuilder();
        Player.Person.Builder personBuilder = Player.Person.newBuilder();
        personBuilder.setFirstname("David");
        personBuilder.setLastname("Whitmarsh");
        builder.setPerson(personBuilder.build());
        builder.setDan(9);
        
        Player.GoPlayer object = builder.build();
        
        serialisationTestHelper.equalsCheckSerialisation(object);
    }
    
    @Test
    public void testSerialiseString() throws IOException {
        serialisationTestHelper.equalsCheckSerialisation("a test string");
    }
    
}
