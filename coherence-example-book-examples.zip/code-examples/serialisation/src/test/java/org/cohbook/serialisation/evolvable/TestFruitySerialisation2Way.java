package org.cohbook.serialisation.evolvable;

import java.io.IOException;

import org.junit.Test;


public class TestFruitySerialisation2Way {

    private Serialisation2WayTestHelper serialisation2WayTestHelper;
    
    public TestFruitySerialisation2Way() {
        serialisation2WayTestHelper = new Serialisation2WayTestHelper("org/cohbook/serialisation/evolvable/legacy/fruity-pof-config.xml",
                "org/cohbook/serialisation/evolvable/fruity-pof-config.xml");
    }

    @Test
    public void testFruitySerialisation() throws IOException {
        
        Object legacyObject = new org.cohbook.serialisation.evolvable.legacy.Fruity("Mark", "Grapes");

        Object currentObject = new org.cohbook.serialisation.evolvable.Fruity("Mark", "Grapes");
        
        serialisation2WayTestHelper.roundTripCheck(legacyObject, currentObject);
        serialisation2WayTestHelper.currentToLegacyCheck(legacyObject, currentObject);
        serialisation2WayTestHelper.legacyToCurrentCheck(legacyObject, currentObject);
        
    }

    @Test
    public void testCheesySerialisation() throws IOException {
        
        Object legacyObject = new org.cohbook.serialisation.evolvable.legacy.Fruity("Elizabeth", "Banana");

        Object currentObject = new org.cohbook.serialisation.evolvable.Fruity("Elizabeth", "Banana", "Wensleydale");
        
        serialisation2WayTestHelper.roundTripCheck(legacyObject, currentObject);
        serialisation2WayTestHelper.currentToLegacyCheck(legacyObject, currentObject);
        
    }
    
}
