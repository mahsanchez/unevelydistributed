package org.cohbook.serialisation.protobuf;

import org.cohbook.serialisation.protobuf.ProtobufExtractor;
import org.junit.Assert;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.google.protobuf.Descriptors;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.EntryExtractor;
import com.tangosol.util.processor.ExtractorProcessor;

public class ProtobufClusterTest {

    static {
        System.setProperty("tangosol.coherence.serializer", "pof");
    }

    @Test
    public void testPutGet() {
        ClusterMemberGroup memberGroup = null;
        
        try {
            memberGroup = ClusterMemberGroupUtils.newBuilder()
                    .setStorageEnabledCount(2)
                    .setCacheConfiguration("org/cohbook/serialisation/protobuf/cache-config.xml")
                    .buildAndConfigureForStorageDisabledClient();
 
            final NamedCache cache = CacheFactory.getCache("test");
            
            Player.GoPlayer.Builder builder = Player.GoPlayer.newBuilder();
            Player.Person.Builder personBuilder = Player.Person.newBuilder();
            personBuilder.setFirstname("David");
            personBuilder.setLastname("Whitmarsh");
            builder.setPerson(personBuilder.build());
            builder.setDan(9);
            
            Player.GoPlayer object = builder.build();

            cache.put("DJW", object);
            
            Player.GoPlayer object2 = (org.cohbook.serialisation.protobuf.Player.GoPlayer) cache.get("DJW");
            
            Assert.assertEquals(object, object2);
 
        } finally {
            CacheFactory.shutdown();
            memberGroup.stopAll();
        }
    }
    @Test
    public void testExtract() {
        ClusterMemberGroup memberGroup = null;
        
        try {
            memberGroup = ClusterMemberGroupUtils.newBuilder()
                    .setStorageEnabledCount(2)
                    .setCacheConfiguration("org/cohbook/serialisation/protobuf/cache-config.xml")
                    .buildAndConfigureForStorageDisabledClient();
 
            final NamedCache cache = CacheFactory.getCache("test");
            
            Player.GoPlayer.Builder builder = Player.GoPlayer.newBuilder();
            Player.Person.Builder personBuilder = Player.Person.newBuilder();
            personBuilder.setFirstname("David");
            personBuilder.setLastname("Whitmarsh");
            builder.setPerson(personBuilder.build());
            builder.setDan(9);
            
            Player.GoPlayer object = builder.build();

            cache.put("DJW", object);

            EntryExtractor extractor = new ProtobufExtractor(AbstractExtractor.VALUE,
                    new int[] { Player.Wrapper.GOPLAYER_FIELD_NUMBER, Player.GoPlayer.DAN_FIELD_NUMBER },
                    Descriptors.FieldDescriptor.Type.INT32);
 
            Integer extDan = (Integer) cache.invoke("DJW", new ExtractorProcessor(extractor));
            
            Assert.assertEquals(Integer.valueOf(9), extDan);
 
        } finally {
            CacheFactory.shutdown();
            memberGroup.stopAll();
        }
    }

}
