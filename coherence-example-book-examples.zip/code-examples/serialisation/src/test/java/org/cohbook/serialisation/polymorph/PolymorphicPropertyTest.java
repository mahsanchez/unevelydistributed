package org.cohbook.serialisation.polymorph;

import org.cohbook.serialisation.domain.ChessPlayer;
import org.cohbook.serialisation.domain.ChessRating;
import org.cohbook.serialisation.domain.GenericPlayer;
import org.cohbook.serialisation.domain.GoRating;
import org.cohbook.serialisation.filter.TypeEqualsFilter;
import org.junit.Assert;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.io.pof.reflect.PofNavigator;
import com.tangosol.io.pof.reflect.SimplePofPath;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.PofExtractor;
import com.tangosol.util.filter.EqualsFilter;

public class PolymorphicPropertyTest {

    @Test
    public void test() {
        ClusterMemberGroup memberGroup = null;
        
        System.setProperty("tangosol.coherence.serializer", "pof");
        
        try {
            memberGroup = ClusterMemberGroupUtils.newBuilder()
                    .setStorageEnabledCount(2)
                    .buildAndConfigureForStorageDisabledClient();
 
            final NamedCache cache = CacheFactory.getCache("test");
            cache.put(1, new GenericPlayer<ChessRating>("Phil", "Wheeler", ChessRating.grand_master));
            cache.put(2, new GenericPlayer<GoRating>("David", "Whitmarsh", GoRating.ninth_dan));
            
            Assert.assertEquals(1, cache.keySet(new EqualsFilter(new PofExtractor(String.class, ChessPlayer.POF_FIRSTNAME), "Phil")).size());
            
            ConfigurablePofContext ctx = (ConfigurablePofContext) cache.getCacheService().getSerializer();
            int typeId = ctx.getUserTypeIdentifier(GoRating.class);
            PofNavigator nav = new SimplePofPath(GenericPlayer.POF_RATING);
//            Filter typeIdFilter = new PofTypeIdFilter(typeId, AbstractExtractor.VALUE, nav);
//            Filter valueFilter = new EqualsFilter(new PofExtractor(GoRating.class, nav), GoRating.ninth_dan);
//            Filter goFilter = new AndFilter(typeIdFilter,
//                    valueFilter);
//            Assert.assertEquals(1, cache.keySet(valueFilter).size());
            
            Filter goFilter = new TypeEqualsFilter(typeId, AbstractExtractor.VALUE, nav, GoRating.ninth_dan);
            Assert.assertEquals(1, cache.keySet(goFilter).size());
 
        } finally {
            CacheFactory.shutdown();
            memberGroup.stopAll();
        }
    }

}
