package org.cohbook.serialisation.protobuf;

import org.cohbook.serialisation.protobuf.ProtobufExtractor;
import org.cohbook.serialisation.protobuf.ProtobufSerialiser;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.Descriptors;
import com.tangosol.io.Serializer;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.ExternalizableHelper;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.EntryExtractor;

public class TestProtobufExtractor {

    private Serializer serialiser;
    private Mockery context;
    
    @Before
    public void setup() {
        serialiser = new ProtobufSerialiser();
        context = new Mockery();
    }

    @Test
    public void test() {
        Player.GoPlayer.Builder builder = Player.GoPlayer.newBuilder();
        Player.Person.Builder personBuilder = Player.Person.newBuilder();
        personBuilder.setFirstname("David");
        personBuilder.setLastname("Whitmarsh");
        builder.setPerson(personBuilder.build());
        builder.setDan(9);
        
        Player.GoPlayer object = builder.build();
        
        final Binary binaryObject = ExternalizableHelper.toBinary(object, serialiser);
        
        final BinaryEntry entry = context.mock(BinaryEntry.class);
        
        context.checking(new Expectations() {{
            oneOf(entry).getBinaryValue();
            will(returnValue(binaryObject));
        }});
        
        EntryExtractor extractor = new ProtobufExtractor(AbstractExtractor.VALUE,
                new int[] { Player.Wrapper.GOPLAYER_FIELD_NUMBER, Player.GoPlayer.DAN_FIELD_NUMBER },
                Descriptors.FieldDescriptor.Type.INT32);
        
        Assert.assertEquals(9, extractor.extractFromEntry(entry));
        
        context.assertIsSatisfied();

    }

}
