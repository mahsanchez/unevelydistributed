package org.cohbook.serialisation.evolvable;

import org.junit.Assert;

import com.tangosol.io.Serializer;
import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.util.Binary;
import com.tangosol.util.ExternalizableHelper;

public class Serialisation2WayTestHelper {

    private final Serializer currentSerialiser;
    private final Serializer legacySerialiser;
    
    public Serialisation2WayTestHelper(String legacyConfigFileName, String currentConfigFileName) {
        legacySerialiser = new ConfigurablePofContext(legacyConfigFileName);
        currentSerialiser = new ConfigurablePofContext(currentConfigFileName);
    }
    
    public Object currentToLegacy(Object currentObject) {
        
        Binary binaryObject = ExternalizableHelper.toBinary(currentObject, currentSerialiser);
        return ExternalizableHelper.fromBinary(binaryObject, legacySerialiser);
        
    }
    
    public Object legacyToCurrent(Object legacyObject) {
        
        Binary binaryObject = ExternalizableHelper.toBinary(legacyObject, legacySerialiser);
        return ExternalizableHelper.fromBinary(binaryObject, currentSerialiser);
        
    }
    
    public void currentToLegacyCheck(Object legacyObject, Object currentObject) {
        
        Assert.assertEquals(legacyObject, currentToLegacy(legacyToCurrent(legacyObject)));
        
    }
    
    public void legacyToCurrentCheck(Object legacyObject, Object currentObject) {
        
        Assert.assertEquals(currentObject, legacyToCurrent(currentToLegacy(currentObject)));
        
    }
    
    public void roundTripCheck(Object legacyObject, Object currentObject) {
        
        Assert.assertEquals(currentObject, legacyToCurrent(currentToLegacy(currentObject)));
        Assert.assertEquals(legacyObject, currentToLegacy(legacyToCurrent(legacyObject)));
        
    }
}
