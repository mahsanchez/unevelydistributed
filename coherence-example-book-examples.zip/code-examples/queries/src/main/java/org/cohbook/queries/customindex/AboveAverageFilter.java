package org.cohbook.queries.customindex;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.filter.IndexAwareFilter;

@Portable
public class AboveAverageFilter implements IndexAwareFilter {

    @PortableProperty(0)
    private ValueExtractor valueExtractor;
    
    public AboveAverageFilter() {
    }

    public AboveAverageFilter(ValueExtractor valueExtractor) {
        this.valueExtractor = valueExtractor;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public boolean evaluateEntry(Entry entry) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean evaluate(Object obj) {
        throw new UnsupportedOperationException();
    }

    @SuppressWarnings("rawtypes")
    @Override
    public int calculateEffectiveness(Map indexMap, Set keySet) {
        return 1;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public Filter applyIndex(Map indexMap, Set keySet) {
        ValueExtractor statisticsIndexKey = new StatisticsIndexBuildExtractor(valueExtractor);
        StatisticsIndex index = (StatisticsIndex) indexMap.get(statisticsIndexKey);
        
        if (index == null) {
            throw new IllegalArgumentException("No matching StatisticsIndex found");
        }
        
        for (Iterator<Object> keyit = keySet.iterator(); keyit.hasNext();) {
            Object key = keyit.next();
            
            Double value = (Double) index.get(key);
            DescriptiveStatistics statistics = index.getStatistics(key);
            
            if (value <= statistics.getMean()) {
                keyit.remove();
            }
        }
        
        return null;
    }
}
