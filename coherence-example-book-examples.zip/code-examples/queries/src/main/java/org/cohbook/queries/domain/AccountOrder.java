package org.cohbook.queries.domain;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.PofExtractor;

@Portable
public class AccountOrder extends AbstractOrder {
    
    public static final int POF_CUSTOMERACCOUNT = 2;
    
    @PortableProperty(POF_CUSTOMERACCOUNT)
    private int customerAccount;
    
    public static final AbstractExtractor CUSTOMERACCOUNTEXTRACTOR = new PofExtractor(Integer.class, POF_CUSTOMERACCOUNT);
    
    public AccountOrder() {
    }

    public AccountOrder(int orderId, int customerAccount) {
        this.orderId = orderId;
        this.customerAccount = customerAccount;
    }

    protected int getCustomerAccount() {
        return customerAccount;
    }
}
