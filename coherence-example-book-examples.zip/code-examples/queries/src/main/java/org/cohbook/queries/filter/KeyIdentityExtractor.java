package org.cohbook.queries.filter;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.IdentityExtractor;

@Portable
public class KeyIdentityExtractor extends IdentityExtractor {
    
    private static final long serialVersionUID = 9212802465407336449L;
    public static final KeyIdentityExtractor INSTANCE = new KeyIdentityExtractor();

    public KeyIdentityExtractor() {
        this.m_nTarget = AbstractExtractor.KEY;
    }

}
