package org.cohbook.queries.projection;

import java.util.Map.Entry;

import org.cohbook.queries.domain.CustomerOrder;
import org.cohbook.queries.domain.SummaryCustomerDetail;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.util.InvocableMap;
import com.tangosol.util.extractor.EntryExtractor;

@Portable
public class CustomerSummaryEntryExtractor extends EntryExtractor {

    private static final long serialVersionUID = 2510594629863507771L;
    
    public static final CustomerSummaryEntryExtractor INSTANCE = new CustomerSummaryEntryExtractor();
    
    @Override
    public Object extractFromEntry(@SuppressWarnings("rawtypes") Entry entry) {
        InvocableMap.Entry iEntry = (com.tangosol.util.InvocableMap.Entry) entry;
        return new SummaryCustomerDetail(
                (String) iEntry.extract(CustomerOrder.CUSTOMERNAMEEXTRACTOR),
                (String) iEntry.extract(CustomerOrder.POSTCODEEXTRACTOR));
    }
}
