package org.cohbook.queries.filter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang3.reflect.FieldUtils;

import com.tangosol.io.pof.PofContext;
import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.io.pof.reflect.PofNavigator;
import com.tangosol.io.pof.reflect.PofValue;
import com.tangosol.io.pof.reflect.PofValueParser;
import com.tangosol.io.pof.reflect.SimplePofPath;
import com.tangosol.net.BackingMapContext;
import com.tangosol.util.Binary;
import com.tangosol.util.Filter;
import com.tangosol.util.SimpleMapIndex;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.filter.IndexAwareFilter;

@Portable
public class UniqueValueFilter implements IndexAwareFilter {
    
    @PortableProperty(0)
    private ValueExtractor indexExtractor;
    @PortableProperty(1)
    private PofNavigator navigator;
    
    private transient PofContext serialiser;
    
    public UniqueValueFilter() {
    }

    public UniqueValueFilter(ValueExtractor indexExtractor, int associatedKeyPofIndex) {
        this.indexExtractor = indexExtractor;
        this.navigator = new SimplePofPath(associatedKeyPofIndex);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public boolean evaluateEntry(Entry entryArg) {
        throw new UnsupportedOperationException("This filter only works with a supporting index");
    }

    @Override
    public boolean evaluate(Object obj) {
        throw new UnsupportedOperationException("This filter only works with a supporting index");
    }

    @SuppressWarnings("rawtypes")
    @Override
    public int calculateEffectiveness(Map map, Set set) {
        return 1;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Filter applyIndex(Map indexmap, Set keyset) {
        
        SimpleMapIndex index = (SimpleMapIndex) indexmap.get(indexExtractor);
        if (index == null) {
            throw new IllegalArgumentException("This filter only works with a supporting index");
        }
        
        serialiser = getPofContext(index);
        
        Collection<Object> matchingKeys = new ArrayList<>(keyset.size());
        
        for (Binary candidateKey : (Set<Binary>) keyset) {
            Object value = index.get(candidateKey);
            if (value instanceof Collection) {
                for (Object valueItem : (Collection<Object>) value) {
                    Collection<Binary> otherKeys = (Collection<Binary>) index.getIndexContents().get(valueItem);
                    if (isCandidateUniqueInSet(candidateKey, keyset, otherKeys)) {
                        matchingKeys.add(candidateKey);
                    }
                }
            } else {
                Collection<Binary> otherKeys = (Collection<Binary>) index.getIndexContents().get(value);
                if (isCandidateUniqueInSet(candidateKey, keyset, otherKeys)) {
                    matchingKeys.add(candidateKey);
                }
            }
        }
        
        keyset.retainAll(matchingKeys);
        
        return null;
        
    }
    
    private PofContext getPofContext(SimpleMapIndex mapIndex) {
        BackingMapContext bmc;
        try {
            bmc = (BackingMapContext) FieldUtils.readField(mapIndex, "m_ctx", true);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        return (PofContext) bmc.getManagerContext().getCacheService().getSerializer();
//        return (PofContext) CacheFactory.getCache(cacheName).getCacheService().getSerializer();
    }
    
    private boolean isCandidateUniqueInSet(Binary candidateKey, Set<Object> keyset, Collection<Binary> otherKeys) {
        Binary candidateAssociatedKey = getAssociatedKey(candidateKey);
        for (Binary compareKey : otherKeys) {
            if (!candidateKey.equals(compareKey)
                    && keyset.contains(compareKey)
                    && candidateAssociatedKey.equals(getAssociatedKey(compareKey))) {
                return false;
            }
        }
        
        return true;
    }
    
    private Binary getAssociatedKey(Binary key) {
        PofValue pofKey = PofValueParser.parse((Binary)key, serialiser);
        PofValue associatedKey = navigator.navigate(pofKey);
        try {
            return (Binary)FieldUtils.readField(associatedKey, "m_bufValue", true);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
//        return navigator.navigate(pofKey).getValue();
    }
}
