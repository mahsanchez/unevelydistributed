package org.cohbook.queries.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map.Entry;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.AbstractExtractor;

@Portable
public class CollectionElementExtractor extends AbstractExtractor {
    
    private static final long serialVersionUID = 3224470825772654781L;
    
    @PortableProperty(0)
    private ValueExtractor collectionExtractor;
    @PortableProperty(1)
    private ValueExtractor elementExtractor;

    public CollectionElementExtractor() {
    }

    public CollectionElementExtractor(ValueExtractor collectionExtractor, ValueExtractor elementExtractor) {
        this.collectionExtractor = collectionExtractor;
        this.elementExtractor = elementExtractor;
    }

    public Object extractFromCollection(Collection<Object> input) {
        Collection<Object> result = new ArrayList<>(input.size());
        for (Object element : input) {
            result.add(elementExtractor.extract(element));
        }
        return result;
    }

    @Override
    public Object extract(Object oTarget) {
        @SuppressWarnings("unchecked")
        Collection<Object> collection = (Collection<Object>) collectionExtractor.extract(oTarget);
        return extractFromCollection(collection);
    }

    @Override
    public Object extractFromEntry(@SuppressWarnings("rawtypes") Entry entry) {
        if (collectionExtractor instanceof AbstractExtractor) {
            @SuppressWarnings("unchecked")
            Collection<Object> collection = (Collection<Object>) ((AbstractExtractor) collectionExtractor).extractFromEntry(entry);
            return extractFromCollection(collection);
        } else {
            return extract(entry.getValue());
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((collectionExtractor == null) ? 0 : collectionExtractor
                        .hashCode());
        result = prime
                * result
                + ((elementExtractor == null) ? 0 : elementExtractor.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        CollectionElementExtractor other = (CollectionElementExtractor) obj;
        if (collectionExtractor == null) {
            if (other.collectionExtractor != null) {
                return false;
            }
        } else if (!collectionExtractor.equals(other.collectionExtractor)) {
            return false;
        }
        if (elementExtractor == null) {
            if (other.elementExtractor != null) {
                return false;
            }
        } else if (!elementExtractor.equals(other.elementExtractor)) {
            return false;
        }
        return true;
    }
}
