package org.cohbook.queries.collections;

import java.io.IOException;
import java.util.Map.Entry;

import org.cohbook.queries.domain.AbstractOrder;
import org.cohbook.queries.domain.OrderLine;

import com.tangosol.io.pof.PofContext;
import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofSerializer;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.reflect.PofCollection;
import com.tangosol.io.pof.reflect.PofNavigator;
import com.tangosol.io.pof.reflect.PofValue;
import com.tangosol.io.pof.reflect.PofValueParser;
import com.tangosol.io.pof.reflect.SimplePofPath;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.extractor.AbstractExtractor;

public class OrderValueExtractor extends AbstractExtractor {

    private static final long serialVersionUID = 2755924341432805842L;
    private static final PofNavigator ORDERLINESNAVIGATOR = new SimplePofPath(AbstractOrder.POF_ORDERLINES);
    private static final PofNavigator ITEMPRICENAVIGATOR = new SimplePofPath(OrderLine.POF_ITEMPRICE);
    private static final PofNavigator QUANTITYNAVIGATOR = new SimplePofPath(OrderLine.POF_QUANTITY);
    
    @Override
    public Object extractFromEntry(@SuppressWarnings("rawtypes") Entry entry) {
        BinaryEntry binaryEntry = (BinaryEntry) entry;
        PofContext pofContext = (PofContext) binaryEntry.getSerializer();

        Binary binaryValue = binaryEntry.getBinaryValue();

        PofValue pofValue = PofValueParser.parse(binaryValue, pofContext);
        PofCollection pofCollection = (PofCollection) ORDERLINESNAVIGATOR.navigate(pofValue);
        
        double result = 0.0;
        
        for (int i = 0; i < pofCollection.getLength(); i++) {
            PofValue pofElement = pofCollection.getChild(i);
            int quantity = (int) QUANTITYNAVIGATOR.navigate(pofElement).getValue();
            double itemprice = (double)ITEMPRICENAVIGATOR.navigate(pofElement).getValue();
            result += quantity * itemprice;
        }
        
        return result;
    }
    
    public static final OrderValueExtractor INSTANCE = new OrderValueExtractor();

    private OrderValueExtractor() {
    }

    public static class Serializer implements PofSerializer {

        @Override
        public void serialize(PofWriter pofwriter, Object obj)
                throws IOException {
            pofwriter.writeRemainder(null);
        }

        @Override
        public Object deserialize(PofReader pofreader) throws IOException {
            pofreader.readRemainder();
            return INSTANCE;
        }
    }
}
