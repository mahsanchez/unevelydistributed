package org.cohbook.queries.customindex;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import com.tangosol.net.BackingMapContext;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.KeyAssociator;
import com.tangosol.util.Binary;
import com.tangosol.util.Converter;
import com.tangosol.util.InvocableMapHelper;
import com.tangosol.util.MapIndex;
import com.tangosol.util.ValueExtractor;

public class StatisticsIndex implements MapIndex {

    private static class AssociatedKeyIndex {
        private final Map<Object,Double> forwardIndex;
        private DescriptiveStatistics statistics;
        
        private AssociatedKeyIndex() {
            this.forwardIndex = new HashMap<>();
            this.statistics = new DescriptiveStatistics();
        }
        
        private void addValue(Object key, double value) {
            forwardIndex.put(key, value);
            statistics.addValue(value);
        }
        
        private void removeValue(Object key) {
            forwardIndex.remove(key);
            statistics = new DescriptiveStatistics();
            for (Double value : forwardIndex.values()) {
                statistics.addValue(value);
            }
        }
    }
    
    private final Map<Object, AssociatedKeyIndex> associatedKeyMap;
    private final ValueExtractor valueExtractor;
    private final KeyAssociator keyAssociator;
    private final Converter keyFromInternalConverter;

    public StatisticsIndex(ValueExtractor valueExtractor, BackingMapContext context) {
        PartitionedService service = (PartitionedService) context.getManagerContext().getCacheService();
        this.valueExtractor = valueExtractor;
        this.keyAssociator = service.getKeyAssociator();
        this.keyFromInternalConverter = context.getManagerContext().getKeyFromInternalConverter();
        associatedKeyMap = new HashMap<>();
    }
    
    public StatisticsIndex(ValueExtractor valueExtractor, KeyAssociator keyAssociator) {
        this.valueExtractor = valueExtractor;
        this.keyAssociator = keyAssociator;
        associatedKeyMap = new HashMap<>();
        this.keyFromInternalConverter = null;
    }

    private Object convertKeyFromBinary(Object key) {
        if (key instanceof Binary) {
            return keyFromInternalConverter.convert(key);
        } else {
            return key;
        }
    }
    
    private Object getAssociatedKey(Object primaryKey) {
        return keyAssociator.getAssociatedKey(primaryKey);
    }

    @Override
    public ValueExtractor getValueExtractor() {
        return valueExtractor;
    }

    @Override
    public boolean isOrdered() {
        return false;
    }

    @Override
    public boolean isPartial() {
        return false;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map getIndexContents() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Object get(Object key) {
        key = convertKeyFromBinary(key);
        Object associatedKey = getAssociatedKey(key);
        AssociatedKeyIndex s = associatedKeyMap.get(associatedKey);
        return s == null ? null : s.forwardIndex.get(key);
    }

    public DescriptiveStatistics getStatistics(Object key) {
        key = convertKeyFromBinary(key);
        AssociatedKeyIndex s = associatedKeyMap.get(getAssociatedKey(key));
        return s == null ? null : s.statistics;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Comparator getComparator() {
        return null;
    }

    @Override
    public void insert(@SuppressWarnings("rawtypes") Entry entry) {
        Object key = entry.getKey();
        double value = (double) InvocableMapHelper.extractFromEntry(valueExtractor, entry);
        insertInternal(key, value);
    }
    
    private void insertInternal(Object key, double value) {

        Object associatedKey = getAssociatedKey(key);
        AssociatedKeyIndex s = associatedKeyMap.get(associatedKey);
        if (s == null) {
            s = new AssociatedKeyIndex();
            associatedKeyMap.put(associatedKey, s);
        }
        s.addValue(key, value);
    }

    @Override
    public void delete(@SuppressWarnings("rawtypes") Entry entry) {
        Object key = entry.getKey();
        deleteInternal(key);
    }

    private void deleteInternal(Object key) {

        Object associatedKey = getAssociatedKey(key);
        AssociatedKeyIndex s = associatedKeyMap.get(associatedKey);
        if (s != null) {
            s.removeValue(key);
            if (s.forwardIndex.isEmpty()) {
                associatedKeyMap.remove(associatedKey);
                s = null;
            }
        }
    }

    @Override
    public void update(@SuppressWarnings("rawtypes") Entry entry) {
        Object key = entry.getKey();
        double value = (double) InvocableMapHelper.extractFromEntry(valueExtractor, entry);
        deleteInternal(key);
        insertInternal(key, value);
    }
}
