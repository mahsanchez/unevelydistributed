package org.cohbook.queries.domain;

import java.io.Serializable;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.PofExtractor;

@Portable
public class CustomerOrder extends AbstractOrder implements Serializable {
    
    private static final long serialVersionUID = -2463128160190979868L;
    
    private static final int POF_CUSTOMERNAME = 2;
    private static final int POF_CUSTOMERADDRESS = 3;
    private static final int POF_POSTCODE = 4;
    
    @PortableProperty(POF_CUSTOMERNAME)
    private String customerName;
    @PortableProperty(POF_CUSTOMERADDRESS)
    private String customerAddress;
    @PortableProperty(POF_POSTCODE)
    private String postCode;
    
    public static final AbstractExtractor POSTCODEEXTRACTOR = new PofExtractor(String.class, POF_POSTCODE);
    public static final AbstractExtractor CUSTOMERNAMEEXTRACTOR = new PofExtractor(String.class, POF_CUSTOMERNAME);
    
    public CustomerOrder() {
    }
    
    public CustomerOrder(int orderId, String customerName, String customerAddress, String postCode) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.postCode = postCode;
    }

    public String getCustomerName() {
        return customerName;
    }
    
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    
    public String getCustomerAddress() {
        return customerAddress;
    }
    
    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }
    
    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }
}
