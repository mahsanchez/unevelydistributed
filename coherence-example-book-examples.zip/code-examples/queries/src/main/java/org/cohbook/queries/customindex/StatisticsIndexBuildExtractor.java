package org.cohbook.queries.customindex;

import java.util.Comparator;
import java.util.Map;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.net.BackingMapContext;
import com.tangosol.util.MapIndex;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.IndexAwareExtractor;

@Portable
public class StatisticsIndexBuildExtractor implements IndexAwareExtractor {

    @PortableProperty(0)
    private ValueExtractor valueExtractor;
    
    
    public StatisticsIndexBuildExtractor() {
    }

    public StatisticsIndexBuildExtractor(ValueExtractor valueExtractor) {
        this.valueExtractor = valueExtractor;
    }


    @Override
    public Object extract(Object obj) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public MapIndex createIndex(boolean flag, Comparator comparator, Map map,
            BackingMapContext backingmapcontext) {
        MapIndex index = new StatisticsIndex(valueExtractor, backingmapcontext);
        map.put(this, index);
        return index;
    }

    @Override
    public MapIndex destroyIndex(@SuppressWarnings("rawtypes") Map map) {
        return (MapIndex) map.remove(this);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((valueExtractor == null) ? 0 : valueExtractor.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        StatisticsIndexBuildExtractor other = (StatisticsIndexBuildExtractor) obj;
        if (valueExtractor == null) {
            if (other.valueExtractor != null) {
                return false;
            }
        } else if (!valueExtractor.equals(other.valueExtractor)) {
            return false;
        }
        return true;
    }
}
