package org.cohbook.queries.customindex;

import java.util.Map.Entry;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.net.BackingMapContext;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.AbstractExtractor;

@Portable
public class MeanExtractor extends AbstractExtractor {

    private static final long serialVersionUID = -3722194152372224211L;
    @PortableProperty(0)
    private ValueExtractor valueExtractor;
    
    public MeanExtractor() {
    }

    public MeanExtractor(ValueExtractor valueExtractor) {
        this.valueExtractor = valueExtractor;
    }

    @Override
    public Object extractFromEntry(@SuppressWarnings("rawtypes") Entry entry) {
        
        BackingMapContext context = ((BinaryEntry) entry).getBackingMapContext();
        ValueExtractor indexMapKey = new StatisticsIndexBuildExtractor(valueExtractor);
        StatisticsIndex index = (StatisticsIndex) context.getIndexMap().get(indexMapKey);

        if (index == null) {
            throw new IllegalStateException("No index defined to support this extractor");
        }
        
        DescriptiveStatistics stats = index.getStatistics(entry.getKey());
        return stats == null ? null : stats.getMean();
    }
}
