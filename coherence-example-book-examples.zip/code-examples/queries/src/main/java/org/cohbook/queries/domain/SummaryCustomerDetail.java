package org.cohbook.queries.domain;

import java.io.Serializable;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;

@Portable
public class SummaryCustomerDetail implements Serializable {
    
    private static final long serialVersionUID = 3253508806577262925L;

    @PortableProperty(0)
    private String customerName;
    @PortableProperty(1)
    private String postCode;
    
    public SummaryCustomerDetail() {
    }

    public SummaryCustomerDetail(String customerName, String postCode) {
        this.customerName = customerName;
        this.postCode = postCode;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public String getPostCode() {
        return postCode;
    }

}
