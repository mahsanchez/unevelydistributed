package org.cohbook.queries.domain;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.net.cache.KeyAssociation;

@Portable
public class OrderKey implements KeyAssociation {
    
    public static final int POF_ORDERID = 0;
    public static final int POF_DEPOTID = 1;
    @PortableProperty(POF_ORDERID)
    private int orderId;
    @PortableProperty(POF_DEPOTID)
    private int depotId;

    public OrderKey() {
    }

    public OrderKey(int orderId, int depotId) {
        this.orderId = orderId;
        this.depotId = depotId;
    }

    public int getOrderId() {
        return orderId;
    }

    public int getDepotId() {
        return depotId;
    }

    @Override
    public Object getAssociatedKey() {
        return getDepotId();
    }

    @Override
    public String toString() {
        return "OrderKey [orderId=" + orderId + ", depotId=" + depotId + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + depotId;
        result = prime * result + orderId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        OrderKey other = (OrderKey) obj;
        if (depotId != other.depotId) {
            return false;
        }
        if (orderId != other.orderId) {
            return false;
        }
        return true;
    }

}
