package org.cohbook.queries.projection;

import java.io.Serializable;

import org.cohbook.queries.domain.CustomerOrder;
import org.cohbook.queries.domain.SummaryCustomerDetail;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.util.ValueExtractor;

@Portable
public class CustomerSummaryExtractor implements ValueExtractor, Serializable {

    private static final long serialVersionUID = 7632484522423506742L;
    
    public static final CustomerSummaryExtractor INSTANCE = new CustomerSummaryExtractor();
    
    @Override
    public Object extract(Object obj) {
        CustomerOrder order = (CustomerOrder) obj;
        return new SummaryCustomerDetail(
                order.getCustomerName(), order.getPostCode());
    }

}
