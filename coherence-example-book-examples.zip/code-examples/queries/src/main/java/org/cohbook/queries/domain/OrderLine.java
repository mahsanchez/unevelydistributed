package org.cohbook.queries.domain;

import java.io.Serializable;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.PofExtractor;

@Portable
public class OrderLine implements Serializable {
    
    private static final long serialVersionUID = 8142127063857061088L;
    
    public static final int POF_PRODUCT = 0;
    @PortableProperty(POF_PRODUCT)
    private String product;
    public static final int POF_ITEMPRICE = 1;
    @PortableProperty(POF_ITEMPRICE)
    private double itemPrice;
    public static final int POF_QUANTITY = 2;
    @PortableProperty(POF_QUANTITY)
    private int quantity;
    
    public static final ValueExtractor PRODUCTEXTRACTOR = new PofExtractor(String.class, POF_PRODUCT);
    public static final ValueExtractor ITEMPRICEEXTRACTOR = new PofExtractor(String.class, POF_ITEMPRICE);
    public static final ValueExtractor QUANTITYEXTRACTOR = new PofExtractor(String.class, POF_QUANTITY);
    
    public OrderLine() {
    }

    public OrderLine(String product, double itemPrice, int quantity) {
        this.product = product;
        this.itemPrice = itemPrice;
        this.quantity = quantity;
    }
    
    public String getProduct() {
        return product;
    }
    
    public void setProduct(String product) {
        this.product = product;
    }
    
    public double getItemPrice() {
        return itemPrice;
    }
    
    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public double getValue() {
        return itemPrice * quantity;
    }
}
