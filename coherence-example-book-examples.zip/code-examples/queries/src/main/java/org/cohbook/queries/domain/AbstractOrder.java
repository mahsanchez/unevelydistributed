package org.cohbook.queries.domain;

import java.util.ArrayList;
import java.util.List;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.PofExtractor;

@Portable
public class AbstractOrder {

    public static final int POF_ORDER = 0;
    public static final int POF_ORDERLINES = 1;
    
    @PortableProperty(POF_ORDER)
    protected int orderId;
    @PortableProperty(POF_ORDERLINES)
    protected List<OrderLine> orderLines;
    
    public static final ValueExtractor ORDERLINESEXTRACTOR = new PofExtractor(null, POF_ORDERLINES); 

    public AbstractOrder() {
        orderLines = new ArrayList<>();
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public List<OrderLine> getOrderLines() {
        return orderLines;
    }

    public double getOrderValue() {
        double result = 0.0;
        for (OrderLine orderline : orderLines) {
            result += orderline.getValue();
        }
        return result;
    }

}
