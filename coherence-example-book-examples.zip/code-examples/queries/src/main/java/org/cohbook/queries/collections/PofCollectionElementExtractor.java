package org.cohbook.queries.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map.Entry;

import com.tangosol.io.pof.PofContext;
import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.io.pof.reflect.PofCollection;
import com.tangosol.io.pof.reflect.PofNavigator;
import com.tangosol.io.pof.reflect.PofValue;
import com.tangosol.io.pof.reflect.PofValueParser;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.extractor.AbstractExtractor;

@Portable
public class PofCollectionElementExtractor extends AbstractExtractor {

    private static final long serialVersionUID = 3224470825772654781L;

    @PortableProperty(0)
    private int target;
    @PortableProperty(1)
    private PofNavigator collectionNavigator;
    @PortableProperty(2)
    private PofNavigator elementNavigator;

    public PofCollectionElementExtractor() {
    }

    public PofCollectionElementExtractor(PofNavigator collectionNavigator,
            PofNavigator elementNavigator) {
        this.target = 0;
        this.collectionNavigator = collectionNavigator;
        this.elementNavigator = elementNavigator;
    }

    @Override
    public Object extractFromEntry(@SuppressWarnings("rawtypes") Entry entry) {
        BinaryEntry binaryEntry = (BinaryEntry) entry;
        PofContext pofContext = (PofContext) binaryEntry.getSerializer();

        Binary binaryValue;
        switch (target) {
        case 0:
        default:
            binaryValue = binaryEntry.getBinaryValue();
            break;
        case 1:
            binaryValue = binaryEntry.getBinaryKey();
            break;
        }
        
        if (binaryValue == null) {
            return null;
        }

        PofValue pofValue = PofValueParser.parse(binaryValue, pofContext);
        PofCollection pofCollection = (PofCollection) collectionNavigator.navigate(pofValue);
        
        Collection<Object> result = new ArrayList<>(pofCollection.getSize());
        
        for (int i = 0; i < pofCollection.getLength(); i++) {
            PofValue pofElement = pofCollection.getChild(i);
            PofValue extractedValue = elementNavigator.navigate(pofElement);
            result.add(extractedValue.getValue());
        }
        
        return result;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((collectionNavigator == null) ? 0 : collectionNavigator
                        .hashCode());
        result = prime
                * result
                + ((elementNavigator == null) ? 0 : elementNavigator.hashCode());
        result = prime * result + target;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        PofCollectionElementExtractor other = (PofCollectionElementExtractor) obj;
        if (collectionNavigator == null) {
            if (other.collectionNavigator != null) {
                return false;
            }
        } else if (!collectionNavigator.equals(other.collectionNavigator)) {
            return false;
        }
        if (elementNavigator == null) {
            if (other.elementNavigator != null) {
                return false;
            }
        } else if (!elementNavigator.equals(other.elementNavigator)) {
            return false;
        }
        if (target != other.target) {
            return false;
        }
        return true;
    }
}
