package org.cohbook.queries.condindex;

import java.util.Collection;

import org.cohbook.queries.domain.AccountOrder;
import org.cohbook.queries.domain.CustomerOrder;
import org.cohbook.serialisation.filter.SimpleTypeIdFilter;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.extractor.ConditionalExtractor;
import com.tangosol.util.filter.EqualsFilter;

public class ConditionalIndexTest {

    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        
        System.setProperty("tangosol.coherence.serializer", "pof");

        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(1)
                .buildAndConfigureForStorageDisabledClient();
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        ConfigurablePofContext pofContext = (ConfigurablePofContext) orderCache.getCacheService().getSerializer();
        int accountOrderTypeId = pofContext.getUserTypeIdentifier(AccountOrder.class);
        Filter filter = new SimpleTypeIdFilter(accountOrderTypeId);
        
        ConditionalExtractor extractor = new ConditionalExtractor(filter, AccountOrder.CUSTOMERACCOUNTEXTRACTOR, true);
        orderCache.addIndex(extractor, true, null);

        
    }
    
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testQuery() {
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        orderCache.put(1, new CustomerOrder(1, "David Cameron", "10 Downing Street", "SW1A 2AA"));
        orderCache.put(2, new AccountOrder(2, 42));
        
        @SuppressWarnings("unchecked")
        Collection<Integer> keys = orderCache.keySet(new EqualsFilter(AccountOrder.CUSTOMERACCOUNTEXTRACTOR, 42));
        
        Assert.assertEquals(1, keys.size());
        Assert.assertEquals(Integer.valueOf(2), (Integer)keys.iterator().next());
        
    }

}
