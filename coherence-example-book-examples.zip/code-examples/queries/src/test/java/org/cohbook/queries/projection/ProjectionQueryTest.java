package org.cohbook.queries.projection;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import org.cohbook.queries.domain.CustomerOrder;
import org.cohbook.queries.domain.SummaryCustomerDetail;
import org.cohbook.serialisation.tools.DeserialisationAggregator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.InvocableMap.EntryAggregator;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.aggregator.ReducerAggregator;
import com.tangosol.util.extractor.MultiExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.AlwaysFilter;

public class ProjectionQueryTest {

    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        
        System.setProperty("tangosol.coherence.serializer", "pof");

        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(1)
                .setCacheConfiguration("/org/cohbook/queries/projection/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        orderCache.put(1, new CustomerOrder(1, "David Cameron", "10 Downing Street", "SW1A 2AA"));
        
    }
    
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testCoveredExtractor() {
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor extractor = new ReflectionExtractor("getCustomerName");
        orderCache.addIndex(extractor, false, null);
        
        DeserialisationAggregator aggCheck = new DeserialisationAggregator(CustomerOrder.class);
        orderCache.aggregate(AlwaysFilter.INSTANCE, aggCheck);
        
        EntryAggregator aggregator = new ReducerAggregator(extractor);
        
        @SuppressWarnings("unchecked")
        Map<Integer, String> resultMap =
                (Map<Integer, String>) orderCache.aggregate(AlwaysFilter.INSTANCE, aggregator);
        
        for (String customerName : resultMap.values()) {
            assertEquals("David Cameron", customerName);
        }
        
        assertEquals(1, resultMap.size());
        assertEquals(Integer.valueOf(0), (Integer) orderCache.aggregate(AlwaysFilter.INSTANCE, aggCheck));
    }
    @Test
    public void testUnCoveredExtractor() {
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor extractor = new ReflectionExtractor("getCustomerName");
        
        DeserialisationAggregator aggCheck = new DeserialisationAggregator(CustomerOrder.class);
        orderCache.aggregate(AlwaysFilter.INSTANCE, aggCheck);
        
        EntryAggregator aggregator = new ReducerAggregator(extractor);
        
        @SuppressWarnings("unchecked")
        Map<Integer, String> resultMap =
                (Map<Integer, String>) orderCache.aggregate(AlwaysFilter.INSTANCE, aggregator);
        
        for (String customerName : resultMap.values()) {
            assertEquals("David Cameron", customerName);
        }
        
        assertEquals(1, resultMap.size());
        assertEquals(Integer.valueOf(1), (Integer) orderCache.aggregate(AlwaysFilter.INSTANCE, aggCheck));
    }
    
    @Test
    public void testMultiExtractor() {
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor extractor = new MultiExtractor(new ValueExtractor[] {
                new ReflectionExtractor("getCustomerName"),
                new ReflectionExtractor("getPostCode")
        });
        
        EntryAggregator aggregator = new ReducerAggregator(extractor);
        
        @SuppressWarnings("unchecked")
        Map<Integer, List<Object>> resultMap =
                (Map<Integer, List<Object>>) orderCache.aggregate(AlwaysFilter.INSTANCE, aggregator);
        
        for (List<Object> values : resultMap.values()) {
        
            String customerName = (String) values.get(0);
            String postCode = (String) values.get(1);
            
            assertEquals(2, values.size());
            assertEquals("David Cameron", customerName);
            assertEquals("SW1A 2AA", postCode);
        }
        
        assertEquals(1, resultMap.size());
    }
    
    @Test
    public void testCustomExtractor() {
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        EntryAggregator aggregator = new ReducerAggregator(CustomerSummaryExtractor.INSTANCE);
        
        @SuppressWarnings("unchecked")
        Map<Integer, SummaryCustomerDetail> resultMap =
                (Map<Integer, SummaryCustomerDetail>) orderCache.aggregate(AlwaysFilter.INSTANCE, aggregator);
        
        for (SummaryCustomerDetail values : resultMap.values()) {
        
            String customerName = values.getCustomerName();
            String postCode = values.getPostCode();
            
            assertEquals("David Cameron", customerName);
            assertEquals("SW1A 2AA", postCode);
        }
        
        assertEquals(1, resultMap.size());
    }
    @Test
    
    public void testCustomEntryExtractor() {
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        EntryAggregator aggregator = new ReducerAggregator(CustomerSummaryEntryExtractor.INSTANCE);
        
        @SuppressWarnings("unchecked")
        Map<Integer, SummaryCustomerDetail> resultMap =
                (Map<Integer, SummaryCustomerDetail>) orderCache.aggregate(AlwaysFilter.INSTANCE, aggregator);
        
        for (SummaryCustomerDetail values : resultMap.values()) {
        
            String customerName = values.getCustomerName();
            String postCode = values.getPostCode();
            
            assertEquals("David Cameron", customerName);
            assertEquals("SW1A 2AA", postCode);
        }
        
        assertEquals(1, resultMap.size());
    }

}
