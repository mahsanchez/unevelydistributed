package org.cohbook.queries.collections;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;

import org.cohbook.queries.domain.AbstractOrder;
import org.cohbook.queries.domain.AccountOrder;
import org.cohbook.queries.domain.CustomerOrder;
import org.cohbook.queries.domain.OrderLine;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.io.pof.reflect.SimplePofPath;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.InvocableMap.EntryAggregator;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.aggregator.ReducerAggregator;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.ContainsFilter;

public class CollectionQueryTest {

    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        
        System.setProperty("tangosol.coherence.serializer", "pof");

        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(1)
                .buildAndConfigureForStorageDisabledClient();
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        CustomerOrder order1 = new CustomerOrder(1, "David Cameron", "10 Downing Street", "SW1A 2AA");
        order1.getOrderLines().add(new OrderLine("BLUWDG", 0.23, 100));
        order1.getOrderLines().add(new OrderLine("GLDWDG", 7.99, 5));
        orderCache.put(order1.getOrderId(), order1);
        
        AccountOrder order2 = new AccountOrder(2, 42);
        order2.getOrderLines().add(new OrderLine("GLDWDG", 8.49, 1));
        orderCache.put(order2.getOrderId(), order2);
    }
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testCollectionExtractor() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor productExtractor = new CollectionElementExtractor(
                AbstractOrder.ORDERLINESEXTRACTOR, new ReflectionExtractor("getProduct"));
        
        EntryAggregator reducer = new ReducerAggregator(productExtractor);

        @SuppressWarnings("unchecked")
        Map<Integer,Collection<String>> orderProducts =
                (Map<Integer, Collection<String>>) orderCache.aggregate(Collections.singleton(1), reducer);
        
        Assert.assertEquals(1, orderProducts.size());
        
        Collection<String> products = orderProducts.get(1);
        
        Assert.assertEquals(2, products.size());
        Assert.assertTrue(products.contains("BLUWDG"));
        Assert.assertTrue(products.contains("GLDWDG"));
        
    }

    @Test
    public void testPofCollectionExtractor() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor productExtractor = new PofCollectionElementExtractor(
                new SimplePofPath(AbstractOrder.POF_ORDERLINES),
                new SimplePofPath(OrderLine.POF_PRODUCT));
        
        EntryAggregator reducer = new ReducerAggregator(productExtractor);

        @SuppressWarnings("unchecked")
        Map<Integer,Collection<String>> orderProducts =
                (Map<Integer, Collection<String>>) orderCache.aggregate(Collections.singleton(1), reducer);
        
        Assert.assertEquals(1, orderProducts.size());
        
        Collection<String> products = orderProducts.get(1);
        
        Assert.assertEquals(2, products.size());
        Assert.assertTrue(products.contains("BLUWDG"));
        Assert.assertTrue(products.contains("GLDWDG"));
        
    }
    
    @Test
    public void testCollectionQuery() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor productExtractor = new CollectionElementExtractor(
                AbstractOrder.ORDERLINESEXTRACTOR, new ReflectionExtractor("getProduct"));

        Filter filter = new ContainsFilter(productExtractor, "BLUWDG");
        
        @SuppressWarnings("unchecked")
        Collection<Integer> blueOrderKeys = orderCache.keySet(filter);
        
        Assert.assertEquals(1, blueOrderKeys.size());
        Assert.assertTrue(blueOrderKeys.contains(1));
    }
    
    @Test
    public void testPofCollectionQuery() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor productExtractor = new PofCollectionElementExtractor(
                new SimplePofPath(AbstractOrder.POF_ORDERLINES),
                new SimplePofPath(OrderLine.POF_PRODUCT));

        Filter filter = new ContainsFilter(productExtractor, "BLUWDG");
        
        @SuppressWarnings("unchecked")
        Collection<Integer> blueOrderKeys = orderCache.keySet(filter);
        
        Assert.assertEquals(1, blueOrderKeys.size());
        Assert.assertTrue(blueOrderKeys.contains(1));
    }
    
    @Test
    public void testIndexedCollectionQuery() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor productExtractor = new CollectionElementExtractor(
                AbstractOrder.ORDERLINESEXTRACTOR, new ReflectionExtractor("getProduct"));
        
        orderCache.addIndex(productExtractor, true, null);

        Filter filter = new ContainsFilter(productExtractor, "BLUWDG");
        
        @SuppressWarnings("unchecked")
        Collection<Integer> blueOrderKeys = orderCache.keySet(filter);
        
        Assert.assertEquals(1, blueOrderKeys.size());
        Assert.assertTrue(blueOrderKeys.contains(1));
    }
    
    @Test
    public void testIndexedPofCollectionQuery() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor productExtractor = new PofCollectionElementExtractor(
                new SimplePofPath(AbstractOrder.POF_ORDERLINES),
                new SimplePofPath(OrderLine.POF_PRODUCT));
        
        orderCache.addIndex(productExtractor, true, null);

        Filter filter = new ContainsFilter(productExtractor, "BLUWDG");
        
        @SuppressWarnings("unchecked")
        Collection<Integer> blueOrderKeys = orderCache.keySet(filter);
        
        Assert.assertEquals(1, blueOrderKeys.size());
        Assert.assertTrue(blueOrderKeys.contains(1));
    }

}
