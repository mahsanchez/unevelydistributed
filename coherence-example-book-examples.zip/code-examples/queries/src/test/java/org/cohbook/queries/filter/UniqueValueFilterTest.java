package org.cohbook.queries.filter;

import java.util.Set;

import org.cohbook.queries.collections.PofCollectionElementExtractor;
import org.cohbook.queries.domain.AbstractOrder;
import org.cohbook.queries.domain.AccountOrder;
import org.cohbook.queries.domain.OrderKey;
import org.cohbook.queries.domain.OrderLine;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.io.pof.reflect.SimplePofPath;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.PofExtractor;

public class UniqueValueFilterTest {

    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        
        System.setProperty("tangosol.coherence.serializer", "pof");

        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(1)
                .buildAndConfigureForStorageDisabledClient();
        
        createOrder(100, 42, 1000, "BLUWDG");
        createOrder(101, 43, 1000, "BLUWDG", "GRNWDG");
        createOrder(102, 44, 1000, "BLUWDG");
        createOrder(103, 42, 1001, "GLDWDG");
        createOrder(104, 42, 1001, "BLUWDG");
        createOrder(105, 42, 1001, "BLUWDG");
        createOrder(106, 42, 1002, "GLDWDG");
        createOrder(107, 42, 1002, "GLDWDG");
        createOrder(108, 43, 1002, "BLUWDG");
    }
    
    private void createOrder(int orderId, int depotId, int customerId, String... products) {
        NamedCache orderCache = CacheFactory.getCache("order");
        AccountOrder order = new AccountOrder(orderId, customerId);
        for (String product : products) {
            order.getOrderLines().add(new OrderLine(product, 8.49, 1));
        }
        orderCache.put(new OrderKey(orderId, depotId), order);
    }
    
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testUniqueSimpleField() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor customerExtractor = new PofExtractor(Integer.class, AccountOrder.POF_CUSTOMERACCOUNT);
        
        orderCache.addIndex(customerExtractor, false, null);

        Filter filter = new UniqueValueFilter(customerExtractor, OrderKey.POF_DEPOTID);
        
        @SuppressWarnings("unchecked")
        Set<OrderKey> uniqueCustomerKeys = orderCache.keySet(filter);
        
        Assert.assertEquals(4, uniqueCustomerKeys.size());
        for (OrderKey key : uniqueCustomerKeys) {
            System.out.println(key);
        }
        Assert.assertTrue(uniqueCustomerKeys.contains(new OrderKey(100, 42)));
        Assert.assertTrue(uniqueCustomerKeys.contains(new OrderKey(101, 43)));
        Assert.assertTrue(uniqueCustomerKeys.contains(new OrderKey(102, 44)));
        Assert.assertTrue(uniqueCustomerKeys.contains(new OrderKey(108, 43)));
    }
    
    @Test
    public void testUniqueCollectionField() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        ValueExtractor productExtractor = new PofCollectionElementExtractor(
                new SimplePofPath(AbstractOrder.POF_ORDERLINES),
                new SimplePofPath(OrderLine.POF_PRODUCT));
        
        orderCache.addIndex(productExtractor, false, null);

        Filter filter = new UniqueValueFilter(productExtractor, OrderKey.POF_DEPOTID);
        
        @SuppressWarnings("unchecked")
        Set<OrderKey> uniqueProductKeys = orderCache.keySet(filter);
        
        Assert.assertEquals(2, uniqueProductKeys.size());
        for (OrderKey key : uniqueProductKeys) {
            System.out.println(key);
        }
        Assert.assertTrue(uniqueProductKeys.contains(new OrderKey(101, 43)));
        Assert.assertTrue(uniqueProductKeys.contains(new OrderKey(102, 44)));
    }
}
