package org.cohbook.queries.keybased;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.cohbook.queries.domain.CustomerOrder;
import org.cohbook.queries.filter.KeyIdentityExtractor;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.KeyPartitioningStrategy;
import com.tangosol.net.partition.PartitionSet;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.aggregator.GroupAggregator;
import com.tangosol.util.aggregator.ReducerAggregator;
import com.tangosol.util.extractor.IdentityExtractor;
import com.tangosol.util.extractor.KeyExtractor;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.AndFilter;
import com.tangosol.util.filter.InFilter;
import com.tangosol.util.filter.PartitionedFilter;

public class TestKeyBasedQueries {
    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        
        System.setProperty("tangosol.coherence.serializer", "pof");

        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(3)
                .setCacheConfiguration("/org/cohbook/queries/projection/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();
        
        NamedCache orderCache = CacheFactory.getCache("order");
        
        orderCache.put(1, new CustomerOrder(1, "David Cameron", "10 Downing Street", "SW1A 2AA"));
        orderCache.put(2, new CustomerOrder(2, "David Cameron", "10 Downing Street", "SW1A 2AA"));
        orderCache.put(3, new CustomerOrder(3, "David Cameron", "10 Downing Street", "SW1A 2AA"));
        orderCache.put(4, new CustomerOrder(4, "David Cameron", "10 Downing Street", "SW1A 2AA"));
        orderCache.put(5, new CustomerOrder(5, "David Cameron", "10 Downing Street", "SW1A 2AA"));
        orderCache.put(6, new CustomerOrder(6, "David Cameron", "10 Downing Street", "SW1A 2AA"));
        
    }
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testKeyBasedGroupAggregator() {
        
        NamedCache orderCache = CacheFactory.getCache("order");

        Set<Integer> keyset = orderCache.keySet();
        Filter subQuery = AlwaysFilter.INSTANCE;
        
        ValueExtractor keyExtractor = new KeyExtractor(IdentityExtractor.INSTANCE);
        
        Set result1 = orderCache.entrySet(new AndFilter(new InFilter(new KeyExtractor(IdentityExtractor.INSTANCE), keyset), subQuery));
        
        Map result2 = (Map) orderCache.aggregate(keyset, GroupAggregator.createInstance(
                new KeyExtractor(IdentityExtractor.INSTANCE),
                new ReducerAggregator(IdentityExtractor.INSTANCE),
                subQuery));
        
        Assert.assertEquals(keyset.size(), result1.size());
        
        Object value1 = result2.get(Integer.valueOf(1));

        Assert.assertEquals(keyset.size(), result2.size());
        
    }
    
    @Test
    public void testPartitionFilter() {
        Set<Integer> keys = new HashSet<>();
        keys.add(1);
        keys.add(2);
        keys.add(3);

        NamedCache orderCache = CacheFactory.getCache("order");
        Set result = orderCache.keySet(getFilterParitionForKeys(orderCache, keys, AlwaysFilter.INSTANCE));
        
        Assert.assertEquals(3, result.size());
        
    }
    
    public void testAssociatedKeyPartitionFilter() {
        
    }
    
    public static Filter getFilterParitionForKeys(NamedCache cache, Set<? extends Object> keys, Filter filter) {
        
        PartitionedService service = (PartitionedService) cache.getCacheService();
        PartitionSet partitionSet = new PartitionSet(service.getPartitionCount());
        
        KeyPartitioningStrategy partstrat = service.getKeyPartitioningStrategy();
        for (Object key : keys) {
            partitionSet.add(partstrat.getKeyPartition(key));
        }
        
        Filter keyFilter = new InFilter(KeyIdentityExtractor.INSTANCE, keys);
        
        return new PartitionedFilter(new AndFilter(keyFilter, filter), partitionSet);
    }

}
