package org.cohbook.queries.filter;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.cohbook.queries.collections.PofCollectionElementExtractor;
import org.cohbook.queries.domain.AbstractOrder;
import org.cohbook.queries.domain.AccountOrder;
import org.cohbook.queries.domain.OrderKey;
import org.cohbook.queries.domain.OrderLine;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.io.pof.reflect.SimplePofPath;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.KeyPartitioningStrategy;
import com.tangosol.net.partition.PartitionSet;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.aggregator.GroupAggregator;
import com.tangosol.util.aggregator.ReducerAggregator;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.IdentityExtractor;
import com.tangosol.util.extractor.KeyExtractor;
import com.tangosol.util.extractor.PofExtractor;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.AndFilter;
import com.tangosol.util.filter.InFilter;
import com.tangosol.util.filter.PartitionedFilter;

public class AssociatedKeyPartitionFilteTest {

    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        
        System.setProperty("tangosol.coherence.serializer", "pof");

        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(3)
                .buildAndConfigureForStorageDisabledClient();
        
        createOrder(100, 42, 1000, "BLUWDG");
        createOrder(101, 43, 1000, "BLUWDG", "GRNWDG");
        createOrder(102, 44, 1000, "BLUWDG");
        createOrder(103, 42, 1001, "GLDWDG");
        createOrder(104, 42, 1001, "BLUWDG");
        createOrder(105, 42, 1001, "BLUWDG");
        createOrder(106, 42, 1002, "GLDWDG");
        createOrder(107, 42, 1002, "GLDWDG");
        createOrder(108, 43, 1002, "BLUWDG");
    }
    
    private void createOrder(int orderId, int depotId, int customerId, String... products) {
        NamedCache orderCache = CacheFactory.getCache("order");
        AccountOrder order = new AccountOrder(orderId, customerId);
        for (String product : products) {
            order.getOrderLines().add(new OrderLine(product, 8.49, 1));
        }
        orderCache.put(new OrderKey(orderId, depotId), order);
    }
    
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    @Test
    public void testPartitionFilter() {
        Set<Integer> keys = new HashSet<>();
        keys.add(42);

        NamedCache orderCache = CacheFactory.getCache("order");
        Set result = orderCache.keySet(
                getFilterParitionForKeys(orderCache, keys, AlwaysFilter.INSTANCE,
                        new PofExtractor(null, new SimplePofPath(OrderKey.POF_DEPOTID), AbstractExtractor.KEY)));
        
        Assert.assertEquals(6, result.size());
        
    }
    
    public static Filter getFilterParitionForKeys(NamedCache cache, Set<? extends Object> keys, Filter filter,
            ValueExtractor associatedKeyExtractor) {
        
        PartitionedService service = (PartitionedService) cache.getCacheService();
        PartitionSet partitionSet = new PartitionSet(service.getPartitionCount());
        
        KeyPartitioningStrategy partstrat = service.getKeyPartitioningStrategy();
        for (Object key : keys) {
            partitionSet.add(partstrat.getKeyPartition(key));
        }
        
        Filter keyFilter = new InFilter(associatedKeyExtractor, keys);
        
        return new PartitionedFilter(new AndFilter(keyFilter, filter), partitionSet);
    }
}
