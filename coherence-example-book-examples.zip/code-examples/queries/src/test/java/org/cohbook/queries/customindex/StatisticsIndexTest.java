package org.cohbook.queries.customindex;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Map;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.cohbook.queries.domain.OrderKey;
import org.jmock.Expectations;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.tangosol.net.PartitionedService;
import com.tangosol.net.cache.KeyAssociation;
import com.tangosol.net.partition.KeyAssociator;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.IdentityExtractor;

public class StatisticsIndexTest {
    @Rule
    public JUnitRuleMockery mockery = new JUnitRuleMockery();

    private ValueExtractor valueExtractor = IdentityExtractor.INSTANCE;
    private StatisticsIndex statisticsIndex;

    private static final OrderKey PKEY1 = new OrderKey(1, 100);
    private static final OrderKey PKEY2 = new OrderKey(2, 102);
    private static final OrderKey PKEY3 = new OrderKey(3, 102);
    private static final OrderKey PKEY4 = new OrderKey(4, 102);
    private static final double VALUE1 = 1.001;
    private static final double VALUE2 = 2.001;
    private static final double VALUE3 = VALUE2;
    private static final double VALUE4 = 4.001;

    @SuppressWarnings("rawtypes")
    @Before
    public void setUp() {
        final KeyAssociator keyAssociator = new KeyAssociator() {
            
            @Override
            public void init(PartitionedService partitionedservice) {
            }
            
            @Override
            public Object getAssociatedKey(Object obj) {
                return ((KeyAssociation)obj).getAssociatedKey();
            }
        };
        
        statisticsIndex = new StatisticsIndex(valueExtractor, keyAssociator);
        final Map.Entry entry1 = mockery.mock(Map.Entry.class, "entry1");
        final Map.Entry entry2 = mockery.mock(Map.Entry.class, "entry2");
        final Map.Entry entry3 = mockery.mock(Map.Entry.class, "entry3");
        mockery.checking(new Expectations() {{
            allowing(entry1).getValue();
            will(returnValue(VALUE1));
            allowing(entry1).getKey();
            will(returnValue(PKEY1));
            allowing(entry2).getValue();
            will(returnValue(VALUE2));
            allowing(entry2).getKey();
            will(returnValue(PKEY2));
            allowing(entry3).getValue();
            will(returnValue(VALUE3));
            allowing(entry3).getKey();
            will(returnValue(PKEY3));
        }});
        statisticsIndex.insert(entry1);
        statisticsIndex.insert(entry2);
        statisticsIndex.insert(entry3);
    }

    @Test
    public void testGet() {
        assertEquals(VALUE1, statisticsIndex.get(PKEY1));
        assertEquals(VALUE2, statisticsIndex.get(PKEY2));
        assertEquals(VALUE3, statisticsIndex.get(PKEY3));
        assertNull(statisticsIndex.get(new OrderKey(99, 99)));
        checkStatics(PKEY1, VALUE1);
        checkStatics(PKEY2, (VALUE2 + VALUE3) / 2);
        checkStatics(PKEY3, (VALUE2 + VALUE3) / 2);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void testInsert() {
        final Map.Entry entry4 = mockery.mock(Map.Entry.class, "entry4");
        mockery.checking(new Expectations() {{
            allowing(entry4).getValue();
            will(returnValue(VALUE4));
            allowing(entry4).getKey();
            will(returnValue(PKEY4));
        }});
        statisticsIndex.insert(entry4);
        assertEquals(VALUE4, statisticsIndex.get(PKEY4));
        checkStatics(PKEY1, VALUE1);
        checkStatics(PKEY2, (VALUE2 + VALUE3 + VALUE4) / 3);
        checkStatics(PKEY3, (VALUE2 + VALUE3 + VALUE4) / 3);
        checkStatics(PKEY4, (VALUE2 + VALUE3 + VALUE4) / 3);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void testUpdate() {
        final Map.Entry entry4 = mockery.mock(Map.Entry.class, "entry4");
        mockery.checking(new Expectations() {{
            allowing(entry4).getValue();
            will(returnValue(VALUE4));
            allowing(entry4).getKey();
            will(returnValue(PKEY3));
        }});
        statisticsIndex.update(entry4);
        assertEquals(VALUE4, statisticsIndex.get(PKEY3));
        checkStatics(PKEY1, VALUE1);
        checkStatics(PKEY2, (VALUE2 + VALUE4) / 2);
        checkStatics(PKEY3, (VALUE2 + VALUE4) / 2);
        
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void testDelete() {
        final Map.Entry entry4 = mockery.mock(Map.Entry.class, "entry4");
        mockery.checking(new Expectations() {{
            allowing(entry4).getValue();
            will(returnValue(VALUE3));
            allowing(entry4).getKey();
            will(returnValue(PKEY3));
        }});
        statisticsIndex.delete(entry4);
        assertNull(statisticsIndex.get(PKEY3));
        checkStatics(PKEY1, VALUE1);
        checkStatics(PKEY2, VALUE2);
        checkStatics(PKEY3, VALUE2);
    }
    
    @Test
    public void testNoAssociatedKey() {
        assertNull(statisticsIndex.getStatistics(new OrderKey(99, 99)));
    }
    
    @SuppressWarnings("rawtypes")
    @Test
    public void testDeleteLastAssociatedAndAddNew() {
        final Map.Entry entry4 = mockery.mock(Map.Entry.class, "entry4");
        final OrderKey key5 = new OrderKey(200, 100);
        final double value5 = 5.005;
        final Map.Entry entry5 = mockery.mock(Map.Entry.class, "entry5");
        mockery.checking(new Expectations() {{
            allowing(entry4).getValue();
            will(returnValue(VALUE1));
            allowing(entry4).getKey();
            will(returnValue(PKEY1));
            allowing(entry5).getValue();
            will(returnValue(value5));
            allowing(entry5).getKey();
            will(returnValue(key5));
        }});
        statisticsIndex.delete(entry4);
        statisticsIndex.insert(entry5);
        checkStatics(key5, value5);
        checkStatics(PKEY1, value5);
    }
    
    private void checkStatics(Object key, double mean) {
        DescriptiveStatistics stats = statisticsIndex.getStatistics(key);
        assertEquals(mean, stats.getMean(), 0.0);
    }

}
