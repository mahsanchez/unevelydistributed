package org.cohbook.queries.customindex;

import java.util.Set;

import org.cohbook.queries.domain.OrderKey;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.IdentityExtractor;
import com.tangosol.util.filter.LessFilter;

public class StatisticsIndexBuildExtractorTest {

    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        
        System.setProperty("tangosol.coherence.serializer", "pof");

        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(3)
                .buildAndConfigureForStorageDisabledClient();
        
        createOrder(100, 42, 1.0);
        createOrder(101, 42, 2.0);
        createOrder(102, 42, 3.0);
        createOrder(103, 43, 4.0);
        createOrder(104, 43, 5.0);
        createOrder(105, 43, 6.0);
        createOrder(106, 44, 7.0);
        createOrder(107, 44, 8.0);
        createOrder(108, 44, 9.0);

        NamedCache orderCache = CacheFactory.getCache("order");
        ValueExtractor indexBuildExtractor = new StatisticsIndexBuildExtractor(IdentityExtractor.INSTANCE);
        orderCache.addIndex(indexBuildExtractor, true, null);
    }
    
    private void createOrder(int orderId, int depotId, double price) {
        NamedCache orderCache = CacheFactory.getCache("order");
        orderCache.put(new OrderKey(orderId, depotId), price);
    }
    
    @Test
    public void testIndex() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        Filter filter = new LessFilter(new MeanExtractor(IdentityExtractor.INSTANCE), 5.0);
        
        @SuppressWarnings("rawtypes")
        Set keySet = orderCache.keySet(filter);
        
        Assert.assertEquals(3, keySet.size());

        Assert.assertTrue(keySet.contains(new OrderKey(100, 42)));
        Assert.assertTrue(keySet.contains(new OrderKey(101, 42)));
        Assert.assertTrue(keySet.contains(new OrderKey(102, 42)));
        
    }
    
    @Test
    public void testFilter() {

        NamedCache orderCache = CacheFactory.getCache("order");
        
        Filter filter = new AboveAverageFilter(IdentityExtractor.INSTANCE);
        
        @SuppressWarnings("rawtypes")
        Set keySet = orderCache.keySet(filter);
        
        Assert.assertEquals(3, keySet.size());
        Assert.assertTrue(keySet.contains(new OrderKey(102, 42)));
        Assert.assertTrue(keySet.contains(new OrderKey(105, 43)));
        Assert.assertTrue(keySet.contains(new OrderKey(108, 44)));
        
    }
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
}
