package org.cohbook.evolvable;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import com.tangosol.io.Serializer;
import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.util.Binary;
import com.tangosol.util.ExternalizableHelper;

public class SerialiserTestSupport {
    
    private Serializer serialiser;

    public SerialiserTestSupport(final String pofConfigName) {
        serialiser = new ConfigurablePofContext(pofConfigName);
    }
    
    public Object createBean(final String className, final Map<String, Object> properties)
            throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException,
            SecurityException, IllegalArgumentException, InvocationTargetException {
        
        Class<?> beanClass = this.getClass().getClassLoader().loadClass(className);
        
        Object bean = beanClass.newInstance();
        
        for (Map.Entry<String, Object> propEntry : properties.entrySet()) {
            Method setter = beanClass.getMethod(propEntry.getKey(), propEntry.getValue().getClass());
            setter.invoke(bean, propEntry.getValue());
        }
        
        return bean;
    }
    
    public byte[] serialise(Object object) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        return ExternalizableHelper.toBinary(object, serialiser).toByteArray();
    }
    
    public Object deserialise(byte[] bytearray)
               throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
        return ExternalizableHelper.fromBinary(new Binary(bytearray), serialiser);
    }


}
