package org.cohbook.gridprocessing.entryprocessor;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.PartitionedService;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.processor.AbstractProcessor;

@Portable
public class AlwaysFailingEntryProcessor extends AbstractProcessor {

    private static final long serialVersionUID = -7214713636181187461L;

    private static final Logger LOG = LoggerFactory.getLogger(AlwaysFailingEntryProcessor.class);
    
    public static final AlwaysFailingEntryProcessor INSTANCE = new AlwaysFailingEntryProcessor();
    
    public AlwaysFailingEntryProcessor() {
    }

    @Override
    public Object process(Entry entry) {

        BinaryEntry bentry = (BinaryEntry) entry;
        int key = (int) entry.getKey();
        PartitionedService ps = (PartitionedService) bentry.getContext().getCacheService();
        int partition = ps.getKeyPartitioningStrategy().getKeyPartition(key);

        LOG.info("invoked with key=" + key + ", partition=" + partition);

        throw new RuntimeException("Failed on key=" + key);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map processAll(Set set) {
    
        MDC.put("member", Integer.valueOf(CacheFactory.getCluster().getLocalMember().getId()).toString());

        LOG.info("invoked with set size=" + set.size());
        return super.processAll(set);
        
    }
}
