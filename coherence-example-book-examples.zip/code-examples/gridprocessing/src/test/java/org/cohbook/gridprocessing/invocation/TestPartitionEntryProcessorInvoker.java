package org.cohbook.gridprocessing.invocation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Semaphore;

import org.cohbook.gridprocessing.entryprocessor.ArbitrarilyFailingEntryProcessor;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationObserver;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.PartitionSet;
import com.tangosol.util.extractor.IdentityExtractor;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.EqualsFilter;

public class TestPartitionEntryProcessorInvoker {

    private ClusterMemberGroup memberGroup;
    private NamedCache cache;
    static final Logger LOG = LoggerFactory.getLogger(TestPartitionEntryProcessorInvoker.class);
    private static final int STORAGE_MEMBER_COUNT = 4;
    
    @Before
    public void setup() {
        LOG.info("***SETUP");
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(STORAGE_MEMBER_COUNT)
                .setCacheConfiguration("org/cohbook/gridprocessing/invocation/cache-config.xml")
                .setAdditionalSystemProperty("tangosol.coherence.log.level", 6)
                .buildAndConfigureForStorageDisabledClient();

        cache = CacheFactory.getCache("test");
        
        PartitionedService service = (PartitionedService) cache.getCacheService();

        int partitionCount = service.getPartitionCount();
        for (int i = 0; i < partitionCount; i++) {
            cache.put(i, "foo");
            cache.put(i + partitionCount, "foo");
            cache.put(i + partitionCount * 2, "foo");
        }
    }
    
    @After
    public void tearDown() {
        LOG.info("***TEARDOWN");
        ClusterMemberGroupUtils.shutdownCacheFactoryThenClusterMemberGroups(memberGroup);
    }
    
    @Test
    public void testInvocation() throws InterruptedException {
        
        LOG.info("***testInvocation");

        Assert.assertEquals(39, cache.size());

        PartitionedService cacheService = (PartitionedService) cache.getCacheService();
        final InvocationResult aggregatedResult = new InvocationResult(
                new HashMap<>(),
                new HashMap<Integer, Exception>(),
                new PartitionSet(cacheService.getPartitionCount()));

        final PartitionSet requiredPartitions = new PartitionSet(cacheService.getPartitionCount());
        requiredPartitions.fill();

        final Semaphore invocationComplete = new Semaphore(0);

        final Map<Integer, Throwable> memberExceptions = new HashMap<>();
        
        InvocationObserver observer = new InvocationResultObserver(
                aggregatedResult, invocationComplete, memberExceptions);
        
        InvocationService invocationService = (InvocationService) CacheFactory.getService("invocationService");

        int iterations = 0;
        
        while (!requiredPartitions.isEmpty()) {
            iterations++;
            Set<Member> memberSet = new HashSet<>();
            for (int partition : requiredPartitions.toArray()) {
                memberSet.add(cacheService.getPartitionOwner(partition));
            }
            
            Invocable invocable = new PartitionEntryProcessorInvoker(
                    ArbitrarilyFailingEntryProcessor.INSTANCE,
                    AlwaysFilter.INSTANCE,
                    "test",
                    requiredPartitions);

            invocationService.execute(invocable, memberSet, observer);

            invocationComplete.acquire();
            
            requiredPartitions.remove(aggregatedResult.getPartitionsProcessed());
            
            if (!memberExceptions.isEmpty()) {
                fail("member exceptions thrown");
                break;
            }
        }
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();
        
        LOG.info(setSize + " entries updated");
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));
        
        assertEquals(36, setSize);
        assertEquals(1, iterations);
    }
    
    @Test
    @Ignore("these tests don't work when all run squentially")
    public void testWithDeadMember() throws InterruptedException {
        
        LOG.info("***testWithDeadMember");

        Assert.assertEquals(39, cache.size());

        PartitionedService cacheService = (PartitionedService) cache.getCacheService();
        final InvocationResult aggregatedResult = new InvocationResult(
                new HashMap<>(),
                new HashMap<Integer, Exception>(),
                new PartitionSet(cacheService.getPartitionCount()));
        final PartitionSet requiredPartitions = new PartitionSet(cacheService.getPartitionCount());
        requiredPartitions.fill();

        final Semaphore invocationComplete = new Semaphore(0);

        final Map<Integer, Throwable> memberExceptions = new HashMap<>();
        
        InvocationObserver observer = new InvocationResultObserver(
                aggregatedResult, invocationComplete, memberExceptions);;
        
        final int memberToStop = memberGroup.getStartedMemberIds()[0];

        InvocationService invocationService = (InvocationService) CacheFactory.getService("invocationService");

        int iterations = 0;
        
        Semaphore runRelease = new Semaphore(0);
        SynchPartitionEntryProcessorInvoker.setRunReleaseSemaphore(runRelease);
        while (!requiredPartitions.isEmpty()) {

            iterations++;
            
            Set<Member> memberSet = new HashSet<>();
            for (int partition : requiredPartitions.toArray()) {
                Member member = cacheService.getPartitionOwner(partition);
                memberSet.add(member);
                LOG.info("partition: " + partition + ", member: " + member.getId());
            }
            
            Invocable invocable = new SynchPartitionEntryProcessorInvoker(
                    new DelegatingWaitEntryProcessor(
                            ArbitrarilyFailingEntryProcessor.INSTANCE, memberToStop),
                    AlwaysFilter.INSTANCE,
                    "test",
                    requiredPartitions);

            invocationService.execute(invocable, memberSet, observer);
            
            if (iterations == 1) {
                runRelease.acquire(memberSet.size());
                memberGroup.stopMember(memberToStop);
            }
            
            invocationComplete.acquire();
            
            requiredPartitions.remove(aggregatedResult.getPartitionsProcessed());

            LOG.info("Completed iteration " + iterations);
            
            if (!memberExceptions.isEmpty()) {
                fail("member exceptions thrown");
                break;
            }
        }
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();
        
        LOG.info(setSize + " entries updated");
        LOG.info(iterations + " interations");
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));
        
        assertEquals(36, setSize);
        assertEquals(2, iterations);
    }

    @Test
    @Ignore("these tests don't work when all run squentially")
    public void testWithDeadMemberAfterProcessing() throws InterruptedException {
        
        LOG.info("***testWithDeadMemberAfterProcessing");

        Assert.assertEquals(39, cache.size());

        PartitionedService cacheService = (PartitionedService) cache.getCacheService();
        final InvocationResult aggregatedResult = new InvocationResult(
                new HashMap<>(),
                new HashMap<Integer, Exception>(),
                new PartitionSet(cacheService.getPartitionCount()));

        final PartitionSet requiredPartitions = new PartitionSet(cacheService.getPartitionCount());
        requiredPartitions.fill();

        final Semaphore invocationComplete = new Semaphore(0);

        final Map<Integer, Throwable> memberExceptions = new HashMap<>();
        
        InvocationObserver observer = new InvocationResultObserver(
                aggregatedResult, invocationComplete, memberExceptions);
        
        final int memberToStop = memberGroup.getStartedMemberIds()[0];

        InvocationService invocationService = (InvocationService) CacheFactory.getService("invocationService");

        int iterations = 0;
        
        Semaphore runRelease = new Semaphore(0);
        DelegatingSynchEntryProcessor.setRunReleaseSemaphore(runRelease);
        
        Thread.sleep(10000);
        
        while (!requiredPartitions.isEmpty()) {

            iterations++;
            
            Set<Member> memberSet = new HashSet<>();
            for (int partition : requiredPartitions.toArray()) {
                memberSet.add(cacheService.getPartitionOwner(partition));
            }
            
            Invocable invocable = new PartitionEntryProcessorInvoker(
                    new DelegatingSynchEntryProcessor(
                            ArbitrarilyFailingEntryProcessor.INSTANCE, memberToStop),
                    AlwaysFilter.INSTANCE,
                    "test",
                    requiredPartitions);

            invocationService.execute(invocable, memberSet, observer);
            
            if (iterations == 1) {
                runRelease.acquire();
                memberGroup.stopMember(memberToStop);
            }
            
            invocationComplete.acquire();
            
            requiredPartitions.remove(aggregatedResult.getPartitionsProcessed());
            
            LOG.info("Completed iteration " + iterations);
            
            if (!memberExceptions.isEmpty()) {
                fail("member exceptions thrown");
                break;
            }
        }
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();
        int dupSetSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobarbar")).size();
        
        LOG.info(setSize + " entries updated once, " + dupSetSize + " entries updated twice");
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));
        
        assertEquals(33, setSize);
        assertEquals(3, dupSetSize);
        assertEquals(2, iterations);
    }
}
