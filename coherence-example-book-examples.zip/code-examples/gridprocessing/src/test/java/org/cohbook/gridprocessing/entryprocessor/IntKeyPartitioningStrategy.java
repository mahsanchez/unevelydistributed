package org.cohbook.gridprocessing.entryprocessor;

import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.KeyPartitioningStrategy;
import com.tangosol.net.partition.PartitionSet;

public class IntKeyPartitioningStrategy implements KeyPartitioningStrategy {

    private int npartitions;
    
    public IntKeyPartitioningStrategy() {
    }

    @Override
    public void init(PartitionedService partitionedservice) {
        npartitions = partitionedservice.getPartitionCount();
    }

    @Override
    public int getKeyPartition(Object obj) {
        return ((int) obj) % npartitions;
    }

    @Override
    public PartitionSet getAssociatedPartitions(Object obj) {
        PartitionSet result = new PartitionSet(npartitions);
        result.add(getKeyPartition(obj));
        return result;
    }
}
