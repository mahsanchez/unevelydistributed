package org.cohbook.gridprocessing.invocation;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

import com.tangosol.net.CacheFactory;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.InvocableMap.EntryProcessor;

public class DelegatingWaitEntryProcessor implements EntryProcessor, Serializable {

    private static final long serialVersionUID = -6752752730828219393L;
    private EntryProcessor delegate;
    private int memberToBlock;
    

    public DelegatingWaitEntryProcessor(EntryProcessor delegate, int memberToBlock) {
        this.delegate = delegate;
        this.memberToBlock = memberToBlock;
    }

    @Override
    public Object process(Entry entry) {
        return delegate.process(entry);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map processAll(Set setEntries) {
        if (CacheFactory.getCluster().getLocalMember().getId() == memberToBlock) {
            try {
                Thread.sleep(10000);
                throw new RuntimeException("waited too long to be killed");
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        return delegate.processAll(setEntries);
    }
}
