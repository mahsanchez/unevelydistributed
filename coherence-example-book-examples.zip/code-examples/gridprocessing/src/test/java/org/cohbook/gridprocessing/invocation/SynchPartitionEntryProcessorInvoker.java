package org.cohbook.gridprocessing.invocation;
import java.util.concurrent.Semaphore;

import org.cohbook.testutils.ReflectionUtils;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.net.NamedCache;
import com.tangosol.net.partition.PartitionSet;
import com.tangosol.util.Filter;
import com.tangosol.util.InvocableMap.EntryProcessor;

@Portable
public class SynchPartitionEntryProcessorInvoker extends PartitionEntryProcessorInvoker {

    private static final long serialVersionUID = 4088064661365742915L;

    @SuppressWarnings("unused")
    private static Semaphore runRelease;

    public static void setRunReleaseSemaphore(Semaphore semaphore) {
        runRelease = semaphore;
    }
    
    public static Semaphore getRunReleaseSemaphore() {
        return (Semaphore) ReflectionUtils.getFieldFromTopClassLoader(
                SynchPartitionEntryProcessorInvoker.class, "runRelease");
    }
    
    public SynchPartitionEntryProcessorInvoker(EntryProcessor entryProcessor,
            Filter queryFilter, String cacheName,
            PartitionSet requiredPartitions) {
        super(entryProcessor, queryFilter, cacheName, requiredPartitions);
    }

    @Override
    protected PartitionSet getPartitionSetToProcess(NamedCache cache) {
        PartitionSet partitionSet = super.getPartitionSetToProcess(cache);

        Semaphore semaphore = getRunReleaseSemaphore();
        if (semaphore != null) {
            semaphore.release();
        }
        
        return partitionSet;
    }
}
