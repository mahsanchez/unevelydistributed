package org.cohbook.gridprocessing.reentrancy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.InvocableMap.EntryProcessor;
import com.tangosol.util.processor.UpdaterProcessor;

public class FlightReservationProcessorTest {

    private static final Logger LOG = LoggerFactory.getLogger(FlightReservationProcessorTest.class);
    private ClusterMemberGroup memberGroup;
    private AtomicInteger bookingCounter;
    private static int FLIGHTS = 10;
    
    private static final String[] PASSENGERS = { "Louis Bleriot", "Amelia Earhart", "Chuck Yeager", "Charles Lindbergh", "Per Lindstrand",
            "Wop May", "Joseph-Michel Montgolfier", "Jacques-Étienne Montgolfier", "Beryl Markham", "Sheila Scott"};
    
    @Before
    public void setup() {
        
        bookingCounter = new AtomicInteger(1);
        
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setCacheConfiguration("org/cohbook/gridprocessing/reentrancy/cache-config.xml")
                .setStorageEnabledCount(1)
                .buildAndConfigureForStorageDisabledClient();
        
        NamedCache flightCache = CacheFactory.getCache("flight");
        CacheFactory.getCache("reservation");
        for (int flightId = 0; flightId < FLIGHTS; flightId++) {
            flightCache.put(flightId, new Flight(flightId));
        }
    }
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testBooking() {

        NamedCache flightCache = CacheFactory.getCache("flight");

        int flightId = 0;
        Flight flight0before = (Flight) flightCache.get(flightId);

        Reservation reservation = new Reservation();
        reservation.setBookingId(bookingCounter.incrementAndGet());
        reservation.setFlightId(flightId);
        reservation.setPassengerName("Amy Johnson");
        reservation.setSeatType(SeatType.economy);
        
        EntryProcessor reservationProcessor = new FlightReservationProcessor(
                Collections.singletonList(reservation), reservation.getBookingId());
        
        flightCache.invoke(reservation.getFlightId(), reservationProcessor);
        Flight flight0after = (Flight) flightCache.get(flightId);
        
        Assert.assertEquals(flight0before.getAvailableEconomy() - 1, flight0after.getAvailableEconomy());
        
        NamedCache bookingCache = CacheFactory.getCache("reservation");
        Reservation actual = (Reservation) bookingCache.get(new ReservationKey(reservation));
        Assert.assertTrue(EqualsBuilder.reflectionEquals(reservation, actual, false));
    }
    
    @Test
    public void testRemoveReservation() {
        
        int flightId = 0;
        int bookingId = 42;
        NamedCache flightCache = CacheFactory.getCache("flight");
        NamedCache reservationCache = CacheFactory.getCache("reservation");
        Flight flight0before = (Flight) flightCache.get(flightId);
        
        Reservation res1 = new Reservation();
        res1.setBookingId(bookingId);
        res1.setFlightId(flightId);
        res1.setPassengerName("Amy Johnson");
        res1.setSeatType(SeatType.economy);

        Reservation res2 = new Reservation();
        res2.setBookingId(bookingId);
        res2.setFlightId(flightId);
        res2.setPassengerName("Amelia Earhart");
        res2.setSeatType(SeatType.economy);
        
        List<Reservation> reservations = new ArrayList<>();
        reservations.add(res1);
        reservations.add(res2);

        flightCache.invoke(flightId, new FlightReservationProcessor(reservations, bookingId));
        
        res1.setSeatType(SeatType.business);
        reservations.remove(1);

        flightCache.invoke(flightId, new FlightReservationProcessor(reservations, bookingId));

        Flight flight0after = (Flight) flightCache.get(flightId);
        
        Assert.assertEquals(flight0before.getAvailableBusiness() -1, flight0after.getAvailableBusiness());
        Assert.assertEquals(flight0before.getAvailableEconomy(), flight0after.getAvailableEconomy());
        
        Assert.assertNotNull(reservationCache.get(new ReservationKey(res1)));
        Assert.assertNull(reservationCache.get(new ReservationKey(res2)));
        
    }
    
    @Test
    public void testDeadlock() throws InterruptedException {
        
        final int flightNo = 0;
        final int bookingId = 23;
        
        final NamedCache flightCache = CacheFactory.getCache("flight");
        final NamedCache reservationCache = CacheFactory.getCache("reservation");
        final AtomicInteger successCount = new AtomicInteger(0);
        
        Thread t1 = new Thread(new Runnable() {
            
            @Override
            public void run() {
                
                List<Reservation> reservations = new ArrayList<>();
                for (String passenger : PASSENGERS) {
                    Reservation reservation = new Reservation();
                    reservation.setFlightId(flightNo);
                    reservation.setPassengerName(passenger);
                    reservation.setBookingId(bookingId);
                    reservation.setSeatType(SeatType.economy);
                    reservations.add(reservation);
                }
                
                EntryProcessor flightProcessor = new FlightReservationProcessor(reservations, bookingId);
                
                for (int i = 0; i < 100; i++) {
                    LOG.info("flight invocation " + i);
                    flightCache.invoke(flightNo, flightProcessor);
                    LOG.info("flight invocation " + i + " done");
                }
                
                successCount.incrementAndGet();
            }
        });
        
        
        Thread t2 = new Thread(new Runnable() {

            @Override
            public void run() {
                List<ReservationKey> keys = new ArrayList<>();
                for (String passenger : PASSENGERS) {
                    keys.add(new ReservationKey(bookingId, passenger, flightNo));
                }
                
                boolean status = true;
                for (int i = 0; i < 100; i++) {
                    EntryProcessor checkinProcessor = new UpdaterProcessor("setCheckedIn", status);
                    LOG.info("booking invocation " + i);
                    reservationCache.invokeAll(keys, checkinProcessor);
                    LOG.info("booking invocation " + i + " done");
                    status = !status;
                }
                
                successCount.incrementAndGet();
            }
        });
        
        t1.start();
        t2.start();
        
        t1.join();
        t2.join();
        
        Assert.assertEquals(2, successCount.get());
    }
}
