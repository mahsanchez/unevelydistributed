package org.cohbook.gridprocessing.joins;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

import org.cohbook.gridprocessing.reentrancy.Flight;
import org.cohbook.gridprocessing.reentrancy.Reservation;
import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;
import org.cohbook.gridprocessing.reentrancy.ReservationKey;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.InvocableMap.EntryAggregator;
import com.tangosol.util.aggregator.ReducerAggregator;

public class PassengerManifestAggregatorTest {

    private ClusterMemberGroup memberGroup;
    
    private static final String[] ECONOMYPASSENGERS = { "Louis Bleriot", "Chuck Yeager", "Charles Lindbergh",
        "Wop May", "Joseph-Michel Montgolfier", "Jacques-Étienne Montgolfier", "Beryl Markham", "Sheila Scott"};
    private static final String[] BUSINESSPASSENGERS = { "Amelia Earhart", "Per Lindstrand" };
    private static final int FLIGHTID = 887;
    
    @Before
    public void setup() {
        
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setCacheConfiguration("org/cohbook/gridprocessing/reentrancy/cache-config.xml")
                .setStorageEnabledCount(1)
                .buildAndConfigureForStorageDisabledClient();
        
        String origin = "Paris";
        String destination = "Tahiti";
        Date departureTime = new Date();
        
        Flight flight = new Flight(FLIGHTID);
        flight.setOrigin(origin);
        flight.setDestination(destination);
        flight.setDepartureTime(departureTime);
        
        NamedCache flightCache = CacheFactory.getCache("flight");
        flightCache.put(FLIGHTID, flight);
        NamedCache reservationCache = CacheFactory.getCache("reservation");
        
        for (String passengerName : ECONOMYPASSENGERS) {
            Reservation reservation = new Reservation();
            reservation.setBookingId(23);
            reservation.setFlightId(FLIGHTID);
            reservation.setPassengerName(passengerName);
            reservation.setSeatType(SeatType.economy);
            reservationCache.put(new ReservationKey(reservation), reservation);
        }
        for (String passengerName : BUSINESSPASSENGERS) {
            Reservation reservation = new Reservation();
            reservation.setBookingId(23);
            reservation.setFlightId(FLIGHTID);
            reservation.setPassengerName(passengerName);
            reservation.setSeatType(SeatType.business);
            reservationCache.put(new ReservationKey(reservation), reservation);
        }
    }
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testManifest() {
        
        NamedCache flightCache = CacheFactory.getCache("flight");
        
        @SuppressWarnings("unchecked")
        Collection<PassengerManifest> manifests =
                (Collection<PassengerManifest>) flightCache.aggregate(
                        Collections.singleton(FLIGHTID), PassengerManifestAggregator.INSTANCE);
        PassengerManifest manifest = manifests.iterator().next();
        
        Assert.assertEquals(FLIGHTID, manifest.getFlightId());
        Assert.assertEquals(ECONOMYPASSENGERS.length, manifest.getEconomyPassengerNames().size());
        Assert.assertEquals(BUSINESSPASSENGERS.length, manifest.getBusinessPassengerNames().size());
    }

    @Test
    public void testManifestExtractor() {
        
        NamedCache flightCache = CacheFactory.getCache("flight");
        
        EntryAggregator manifestAggregator = new ReducerAggregator(PassengerManifestExtractor.INSTANCE);
        
        @SuppressWarnings("unchecked")
        Map<Integer, PassengerManifest> manifestMap = (Map<Integer, PassengerManifest>) flightCache.aggregate(
                Collections.singleton(FLIGHTID), manifestAggregator);

        PassengerManifest manifest = manifestMap.entrySet().iterator().next().getValue();
        
        Assert.assertEquals(FLIGHTID, manifest.getFlightId());
        Assert.assertEquals(ECONOMYPASSENGERS.length, manifest.getEconomyPassengerNames().size());
        Assert.assertEquals(BUSINESSPASSENGERS.length, manifest.getBusinessPassengerNames().size());
    }

}
