package org.cohbook.gridprocessing.joins;

import java.util.Collection;
import java.util.Date;

import org.cohbook.gridprocessing.reentrancy.Flight;
import org.cohbook.gridprocessing.reentrancy.Reservation;
import org.cohbook.gridprocessing.reentrancy.ReservationKey;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.EqualsFilter;

public class ItineraryAggregatorTest {

    private ClusterMemberGroup memberGroup;
    
    @Before
    public void setup() {
        
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setCacheConfiguration("org/cohbook/gridprocessing/reentrancy/cache-config.xml")
                .setStorageEnabledCount(1)
                .buildAndConfigureForStorageDisabledClient();
        
        createFlight(887, "Paris", "Tahiti", new Date(), "Joseph-Michel Montgolfier", "Jacques-Étienne Montgolfier");
        createFlight(888, "Tahiti", "Paris", new Date(), "Jacques-Étienne Montgolfier");
    }
    
    private void createFlight(int flightId, String origin, String destination, Date departureTime, String... passengerNames) {
        Flight flight = new Flight(flightId);
        flight.setOrigin(origin);
        flight.setDestination(destination);
        flight.setDepartureTime(departureTime);
        
        NamedCache flightCache = CacheFactory.getCache("flight");
        flightCache.put(flightId, flight);
        NamedCache reservationCache = CacheFactory.getCache("reservation");
        
        for (String passengerName : passengerNames) {
            Reservation reservation = new Reservation();
            reservation.setBookingId(23);
            reservation.setFlightId(flightId);
            reservation.setPassengerName(passengerName);
            reservationCache.put(new ReservationKey(reservation), reservation);
        }
    }
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testItinerary() {
        
        NamedCache reservationCache = CacheFactory.getCache("reservation");
        
        ValueExtractor extractor = new ReflectionExtractor(
                "getBookingId", null, AbstractExtractor.KEY);
        
        Filter filter = new EqualsFilter(extractor, 23);
        
        @SuppressWarnings("unchecked")
        Collection<ItineraryStage> itinerary =
                (Collection<ItineraryStage>) reservationCache.aggregate(
                        filter, ItineraryAggregator.INSTANCE);
        
        Assert.assertEquals(2, itinerary.size());
    }

}
