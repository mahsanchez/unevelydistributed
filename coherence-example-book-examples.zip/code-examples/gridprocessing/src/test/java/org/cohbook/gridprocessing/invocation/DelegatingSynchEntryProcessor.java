package org.cohbook.gridprocessing.invocation;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Semaphore;

import org.cohbook.testutils.ReflectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.InvocableMap.EntryProcessor;

public class DelegatingSynchEntryProcessor implements EntryProcessor, Serializable {

    private static final long serialVersionUID = -6752752730828219393L;
    private static final Logger LOG = LoggerFactory.getLogger(DelegatingSynchEntryProcessor.class);
    private EntryProcessor delegate;
    private int memberToBlock;
    
    @SuppressWarnings("unused")
    private static Semaphore runRelease;
    private static int invocationCount = 0;

    public static void setRunReleaseSemaphore(Semaphore semaphore) {
        runRelease = semaphore;
    }
    
    public static Semaphore getRunReleaseSemaphore() {
        return (Semaphore) ReflectionUtils.getFieldFromTopClassLoader(
                DelegatingSynchEntryProcessor.class, "runRelease");
    }
    
    public DelegatingSynchEntryProcessor(EntryProcessor delegate, int memberToBlock) {
        this.delegate = delegate;
        this.memberToBlock = memberToBlock;
    }

    @Override
    public Object process(Entry entry) {
        return delegate.process(entry);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map processAll(Set setEntries) {
        int thisMember = CacheFactory.getCluster().getLocalMember().getId();
        LOG.info("process " + setEntries.size() + " on member " + thisMember + ", block on " + memberToBlock);
        if (thisMember == memberToBlock) {
            LOG.info("this is the blocking member, invocationCount=" + invocationCount);
            if (invocationCount++ > 0) {
                LOG.info("blocking...");
                getRunReleaseSemaphore().release();
                try {
                    Thread.sleep(10000);
                    throw new RuntimeException("waited too long to be killed");
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return delegate.processAll(setEntries);
    }
}
