package org.cohbook.gridprocessing.entryprocessor;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.util.extractor.IdentityExtractor;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.EqualsFilter;

public class TestAsyncEntryProcessorException {

    private ClusterMemberGroup memberGroup;
    private NamedCache cache;
    private static final Logger LOG = LoggerFactory.getLogger(TestAsyncEntryProcessorException.class);

    @Before
    public void setup() {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(2)
                .setCacheConfiguration("org/cohbook/gridprocessing/entryprocessor/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();

        cache = CacheFactory.getCache("test");
        
        PartitionedService service = (PartitionedService) cache.getCacheService();

        int partitionCount = service.getPartitionCount();
        for (int i = 0; i < partitionCount; i++) {
            cache.put(i, "foo");
            cache.put(i + partitionCount, "foo");
            cache.put(i + partitionCount * 2, "foo");
        }
    }
    
    @After
    public void tearDown() throws InterruptedException {
        CacheFactory.getCluster().shutdown();
        memberGroup.shutdownAll();
        Thread.sleep(1000);
    }
    
    @Test
    public void testCatchOneExceptions() throws InterruptedException, ExecutionException {
        
        ExceptionCatchingAsyncProcessor asyncProcessor = new ExceptionCatchingAsyncProcessor(ArbitrarilyFailingEntryProcessor.INSTANCE);
        
        cache.invokeAll(AlwaysFilter.INSTANCE, asyncProcessor);
        
        @SuppressWarnings("rawtypes")
        Map result = (Map) asyncProcessor.get();
        Collection<Throwable> exceptions = asyncProcessor.getExceptions();
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();

        LOG.info(setSize + " entries updated");
        
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));
        
        LOG.info("exceptions returned: " + exceptions.size());
        
        Assert.assertEquals(result.size(), setSize);
    }

    @Test
    public void testCatchManyExceptions() throws InterruptedException, ExecutionException {
        
        ExceptionCatchingAsyncProcessor asyncProcessor = new ExceptionCatchingAsyncProcessor(AlwaysFailingEntryProcessor.INSTANCE);
        
       cache.invokeAll(AlwaysFilter.INSTANCE, asyncProcessor);
        
        @SuppressWarnings("rawtypes")
        Map result = (Map) asyncProcessor.get();
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();

        LOG.info(setSize + " entries updated");
        
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));
        
        LOG.info("exceptions returned: " + asyncProcessor.getExceptions().size());
        
        Assert.assertNull(result);
        Assert.assertEquals(0, setSize);
    }
}
