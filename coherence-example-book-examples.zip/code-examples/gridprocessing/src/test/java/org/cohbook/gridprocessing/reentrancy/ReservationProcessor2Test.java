package org.cohbook.gridprocessing.reentrancy;

import java.util.concurrent.atomic.AtomicInteger;

import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.InvocableMap.EntryProcessor;

public class ReservationProcessor2Test {

    private ClusterMemberGroup memberGroup;
    private AtomicInteger bookingCounter;
    private static int FLIGHTS = 10;
    
    @Before
    public void setup() {
        
        bookingCounter = new AtomicInteger(1);
        
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setCacheConfiguration("org/cohbook/gridprocessing/reentrancy/cache-config.xml")
                .setStorageEnabledCount(1)
                .buildAndConfigureForStorageDisabledClient();
        
        NamedCache flightCache = CacheFactory.getCache("flight");
        for (int flightId = 0; flightId < FLIGHTS; flightId++) {
            flightCache.put(flightId, new Flight(flightId));
        }
    }
    
    @After
    public void teardown() {
        memberGroup.stopAll();
    }
    
    @Test
    public void testBooking() {

        NamedCache flightCache = CacheFactory.getCache("flight");
        NamedCache bookingCache = CacheFactory.getCache("reservation");

        int flightId = 0;
        Flight flight0before = (Flight) flightCache.get(flightId);

        Reservation reservation = new Reservation();
        reservation.setBookingId(bookingCounter.incrementAndGet());
        reservation.setFlightId(flightId);
        reservation.setPassengerName("Wilbur Wright");
        reservation.setSeatType(SeatType.economy);
        
        EntryProcessor bookingProcessor = new ReservationProcessor2(reservation);
        
        bookingCache.invoke(new ReservationKey(reservation.getBookingId(), reservation.getPassengerName(), reservation.getFlightId()), bookingProcessor);
        Flight flight0after = (Flight) flightCache.get(flightId);
        
        Assert.assertEquals(flight0before.getAvailableEconomy() - 1, flight0after.getAvailableEconomy());
    }
    
    private class ClusterLoader implements Runnable {

        @Override
        public void run() {
            
            NamedCache bookingCache = CacheFactory.getCache("reservation");
            
            int flight = 0;
            for (flight = 0; flight < FLIGHTS; flight++) {
                Reservation reservation = new Reservation();
                reservation.setBookingId(bookingCounter.incrementAndGet());
                reservation.setFlightId(flight);
                reservation.setPassengerName("Oliver Wright");
                reservation.setSeatType(SeatType.economy);
                
                EntryProcessor reservationProcessor = new ReservationProcessor2(reservation);
                
                bookingCache.invoke(new ReservationKey(reservation), reservationProcessor);
            }
        }
    }
    
    private static final int THREADCOUNT = 2;
    
    @Test
    public void testThreadDeadlock() {
        
        Thread[] threads = new Thread[THREADCOUNT];
        
        for (int i = 0; i < THREADCOUNT; i++) {
            threads[i] = new Thread(new ClusterLoader());
            threads[i].start();
        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e1) {
            throw new RuntimeException(e1);
        }
        
        for (Thread thread: threads) {
            Assert.assertTrue("thread has deadlocked", !thread.isAlive());
        }
    }

}
