package org.cohbook.gridprocessing.entryprocessor;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.KeyPartitioningStrategy;
import com.tangosol.net.partition.PartitionSet;
import com.tangosol.util.Filter;
import com.tangosol.util.extractor.IdentityExtractor;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.EqualsFilter;
import com.tangosol.util.filter.PartitionedFilter;

public class TestEntryProcessorException {

    private ClusterMemberGroup memberGroup;
    private NamedCache cache;
    private static final Logger LOG = LoggerFactory.getLogger(TestEntryProcessorException.class);

    @Before
    public void setup() {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(2)
                .setCacheConfiguration("org/cohbook/gridprocessing/entryprocessor/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();

        cache = CacheFactory.getCache("test");
        
        PartitionedService service = (PartitionedService) cache.getCacheService();

        int partitionCount = service.getPartitionCount();
        for (int i = 0; i < partitionCount; i++) {
            cache.put(i, "foo");
            cache.put(i + partitionCount, "foo");
            cache.put(i + partitionCount * 2, "foo");
        }
    }
    
    @After
    public void tearDown() throws InterruptedException {
        CacheFactory.getCluster().shutdown();
        memberGroup.shutdownAll();
        Thread.sleep(1000);
    }
    
    @Test
    @Ignore("Works under eclipse, not under maven")
    public void testInvokeFilter() {
        
        Assert.assertEquals(39, cache.size());
        
        try {
            cache.invokeAll(AlwaysFilter.INSTANCE, ArbitrarilyFailingEntryProcessor.INSTANCE);
        } catch (RuntimeException e) {
            LOG.info("caught ", e);
        }
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();
        
        LOG.info(setSize + " entries updated");
        
        Assert.assertEquals(18, setSize);
    }
    
    @Test
    public void testInvokeKeys() {
        
        try {
            cache.invokeAll(cache.keySet(), ArbitrarilyFailingEntryProcessor.INSTANCE);
        } catch (RuntimeException e) {
            LOG.info("caught ", e);
        }
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();

        LOG.info(setSize + " entries updated");
        
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));
        
        Assert.assertEquals(36, setSize);
    }
    
    @Test
    public void testAlwaysFailKeys() {
        
        try {
            cache.invokeAll(cache.keySet(), AlwaysFailingEntryProcessor.INSTANCE);
        } catch (RuntimeException e) {
            LOG.info("caught ", e);
        }
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();
        LOG.info(setSize + " entries updated");
        Assert.assertEquals(0, setSize);
        
    }

    @Test
    public void testCatchExceptions() {
        
        @SuppressWarnings("unchecked")
        Map<Integer,Result> results = cache.invokeAll(cache.keySet(),
                new ExceptionCatchingEntryProcessor(ArbitrarilyFailingEntryProcessor.INSTANCE));
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();

        LOG.info(setSize + " entries updated");
        
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));
        
        for (Map.Entry<Integer,Result> entry : results.entrySet()) {
            if (entry.getValue().getReturnvalue() == null) {
                LOG.info("exception for key " + entry.getKey() + ": " + entry.getValue().getException().getMessage());
            }
        }
        
        Assert.assertEquals(37, setSize);
    }
    
    @Test
    public void testPartitionFilter() {
        
        PartitionedService service = (PartitionedService) cache.getCacheService();
        int partitionCount = service.getPartitionCount();
        PartitionSet partitionSet = new PartitionSet(partitionCount);
        
        for (int i = 0; i < partitionCount; i++) {
            partitionSet.clear();
            partitionSet.add(i);
            Filter filter = new PartitionedFilter(AlwaysFilter.INSTANCE, partitionSet);
            try {
                cache.invokeAll(filter, ArbitrarilyFailingEntryProcessor.INSTANCE);
            } catch(Exception e) {
                LOG.info("caught while processing partition " + i, e);
            }
        }
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();

        LOG.info(setSize + " entries updated");
        
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));

        Assert.assertEquals(36, setSize);
        
    }
    
    @Test
    public void testPartitionWithKeys() {
        
        Set<Integer> keys = new HashSet<>();
        Collections.addAll(keys, 10, 11, 13, 14, 15, 20, 21, 22, 23, 24, 25, 26 );

        PartitionedService service = (PartitionedService) cache.getCacheService();
        KeyPartitioningStrategy kps = service.getKeyPartitioningStrategy();
        Set<Integer> partitions = new HashSet<>();
        
        for (int key : keys) {
            partitions.add(kps.getKeyPartition(key));
        }

        int partitionCount = service.getPartitionCount();
        PartitionSet partitionSet = new PartitionSet(partitionCount);
        
        for (int i : partitions) {
            partitionSet.clear();
            partitionSet.add(i);
            Filter filter = new PartitionedFilter(AlwaysFilter.INSTANCE, partitionSet);
            try {
                cache.invokeAll(filter, ArbitrarilyFailingEntryProcessor.INSTANCE);
            } catch(Exception e) {
                LOG.info("caught while processing partition " + i, e);
            }
        }
        
        int setSize = cache.entrySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foobar")).size();

        LOG.info(setSize + " entries updated");
        
        LOG.info("unchanged keys: " + cache.keySet(new EqualsFilter(IdentityExtractor.INSTANCE, "foo")));
        
    }

}
