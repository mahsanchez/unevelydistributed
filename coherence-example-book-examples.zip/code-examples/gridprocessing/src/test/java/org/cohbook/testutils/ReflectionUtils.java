package org.cohbook.testutils;

import java.lang.reflect.Field;

public class ReflectionUtils {

    private ReflectionUtils() {
    }
    
    public static Object getFieldFromTopClassLoader(Class<?> clazz, String fieldName) {
        ClassLoader loader = clazz.getClassLoader();
        ClassLoader parent = loader.getParent();
        if (parent != null) {
            loader = parent;
        }
        Class<?> topClass;
        try {
            topClass = loader.loadClass(clazz.getName());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        Field resultField;
        try {
            resultField = topClass.getDeclaredField(fieldName);
        } catch (NoSuchFieldException | SecurityException e) {
            throw new RuntimeException(e);
        }
        resultField.setAccessible(true);
        try {
            return resultField.get(null);
        } catch (IllegalArgumentException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
