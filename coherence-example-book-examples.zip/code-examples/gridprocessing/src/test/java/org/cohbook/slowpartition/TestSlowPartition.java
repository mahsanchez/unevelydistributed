package org.cohbook.slowpartition;

import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.Member;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.PartitionSet;

@Ignore
public class TestSlowPartition {

    private ClusterMemberGroup memberGroup;
    private NamedCache cache;
    static final Logger LOG = LoggerFactory.getLogger(TestSlowPartition.class);
    private static final int STORAGE_MEMBER_COUNT = 4;
    
    @Before
    public void setup() {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(STORAGE_MEMBER_COUNT)
                .setCacheConfiguration("org/cohbook/slowpartition/cache-config.xml")
                .setAdditionalSystemProperty("tangosol.coherence.log.level", 6)
                .buildAndConfigureForStorageDisabledClient();

        cache = CacheFactory.getCache("test");
        
        PartitionedService service = (PartitionedService) cache.getCacheService();

        int partitionCount = service.getPartitionCount();
        for (int i = 0; i < partitionCount; i++) {
            cache.put(i, "foo");
            cache.put(i + partitionCount, "foo");
            cache.put(i + partitionCount * 2, "foo");
        }
    }
    
    @Test
    public void testParitionTime() throws InterruptedException {
        PartitionedService cacheService = (PartitionedService) cache.getCacheService();
        final PartitionSet requiredPartitions = new PartitionSet(cacheService.getPartitionCount());
        requiredPartitions.fill();
        
        int checkCount = 0;
        int members = 0;
        
        do {
            if (checkCount > 0) {
                Thread.sleep(1000);
            }
            Set<Member> memberSet = new HashSet<>();
            for (int partition : requiredPartitions.toArray()) {
                memberSet.add(cacheService.getPartitionOwner(partition));
            }
            members = memberSet.size();
            checkCount++;
        } while (members < STORAGE_MEMBER_COUNT);

        Assert.assertEquals(1, checkCount);
    }
    @After
    public void tearDown() {
        CacheFactory.shutdown();
        memberGroup.stopAll();
    }

}
