package org.cohbook.gridprocessing.reentrancy;

import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;

import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.processor.AbstractProcessor;

public class FlightUpdateProcessor extends AbstractProcessor {

    private static final long serialVersionUID = 6313995787438375368L;
    
    private int economySeats = 0;
    private int businessSeats = 0;
    
    public FlightUpdateProcessor(SeatType seatType, int seats) {
        switch (seatType) {
        case business:
            businessSeats = seats;
            break;
        case economy:
            economySeats = seats;
            break;
        }
    }
    @Override
    public Object process(Entry entry) {
        
        if (!entry.isPresent()) {
            throw new IllegalArgumentException("No such flight " + entry.getKey());
        }
        
        Flight flight = (Flight) entry.getValue();
        
        flight.setAvailableEconomy(flight.getAvailableEconomy() - economySeats);
        flight.setAvailableBusiness(flight.getAvailableBusiness() - businessSeats);
        
        if (flight.getAvailableEconomy() <= 0 || flight.getAvailableBusiness() <= 0) {
            throw new RuntimeException("insufficient availability");
        }
        
        entry.setValue(flight);
        
        return null;
    }

}
