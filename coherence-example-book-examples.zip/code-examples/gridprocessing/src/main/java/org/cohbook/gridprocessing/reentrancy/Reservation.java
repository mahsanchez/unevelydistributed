package org.cohbook.gridprocessing.reentrancy;

import java.io.Serializable;

public class Reservation implements Serializable {
    
    private static final long serialVersionUID = 1711674509012264878L;
    
    private int bookingId;
    private String passengerName;
    private int flightId;
    private boolean checkedIn = false;
    
    public enum SeatType { economy, business };

    private SeatType seatType;
    public int getBookingId() {
        return bookingId;
    }
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }
    public String getPassengerName() {
        return passengerName;
    }
    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }
    public int getFlightId() {
        return flightId;
    }
    public void setFlightId(int flightId) {
        this.flightId = flightId;
    }
    public SeatType getSeatType() {
        return seatType;
    }
    public void setSeatType(SeatType seatType) {
        this.seatType = seatType;
    }
    public boolean isCheckedIn() {
        return checkedIn;
    }
    public void setCheckedIn(boolean checkedIn) {
        this.checkedIn = checkedIn;
    }

}
