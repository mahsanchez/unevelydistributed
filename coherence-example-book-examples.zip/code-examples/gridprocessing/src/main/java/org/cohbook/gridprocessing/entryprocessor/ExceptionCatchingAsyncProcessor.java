package org.cohbook.gridprocessing.entryprocessor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import com.tangosol.util.InvocableMap.EntryProcessor;
import com.tangosol.util.processor.AsynchronousProcessor;

public class ExceptionCatchingAsyncProcessor extends AsynchronousProcessor {

    private static final long serialVersionUID = -8236230230394528276L;

    public ExceptionCatchingAsyncProcessor(EntryProcessor processor,
            boolean fFlowControl, int iUnitOrderId) {
        super(processor, fFlowControl, iUnitOrderId);
    }

    public ExceptionCatchingAsyncProcessor(EntryProcessor processor,
            boolean fFlowControl) {
        super(processor, fFlowControl);
    }

    public ExceptionCatchingAsyncProcessor(EntryProcessor processor) {
        super(processor);
    }
    
    private List<Throwable> exceptions = new ArrayList<>();

    @Override
    public void onException(Throwable eReason) {
        exceptions.add(eReason);
    }
    
    public Collection<Throwable> getExceptions() throws InterruptedException, ExecutionException {
        // get() waits for completion
        get();
        return Collections.unmodifiableCollection(exceptions);
    }
}
