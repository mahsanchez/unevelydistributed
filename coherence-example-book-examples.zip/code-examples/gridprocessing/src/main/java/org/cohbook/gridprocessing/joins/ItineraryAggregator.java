package org.cohbook.gridprocessing.joins;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.cohbook.gridprocessing.reentrancy.Flight;
import org.cohbook.gridprocessing.reentrancy.Reservation;

import com.tangosol.net.BackingMapContext;
import com.tangosol.net.BackingMapManagerContext;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.InvocableMap.EntryAggregator;
import com.tangosol.util.InvocableMap.ParallelAwareAggregator;

public class ItineraryAggregator implements ParallelAwareAggregator {
    
    private static final long serialVersionUID = -8176820068037938484L;
    
    public static final ItineraryAggregator INSTANCE = new ItineraryAggregator();

    @SuppressWarnings("unchecked")
    @Override
    public Object aggregate(@SuppressWarnings("rawtypes") Set set) {
        
        Map<Integer, ItineraryStage> flightItineraries = new HashMap<Integer, ItineraryStage>();
        
        for (BinaryEntry reservationEntry : (Set<BinaryEntry>)set) {
            Reservation reservation = (Reservation) reservationEntry.getValue();
            int flightId = reservation.getFlightId();
            if (!flightItineraries.containsKey(flightId)) {
                BackingMapManagerContext managerContext = reservationEntry.getContext();
                BackingMapContext flightContext = managerContext.getBackingMapContext("flight");
                
                Object binaryKey = managerContext.getKeyToInternalConverter().convert(flightId);
                Flight flight = (Flight) flightContext.getReadOnlyEntry(binaryKey).getValue();

                ItineraryStage stage = new ItineraryStage(flight);
                flightItineraries.put(flightId, stage);
            }
            flightItineraries.get(flightId).addPassenger(reservation.getPassengerName());
        }
        
        return new ArrayList<ItineraryStage>(flightItineraries.values());
    }

    @Override
    public EntryAggregator getParallelAggregator() {
        return this;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object aggregateResults(@SuppressWarnings("rawtypes") Collection collection) {
        Collection<ItineraryStage> result = new ArrayList<>();
        
        for (Collection<ItineraryStage> partialResult :
            (Collection<Collection<ItineraryStage>>)collection) {
            result.addAll(partialResult);
        }
        
        return result;
    }

}
