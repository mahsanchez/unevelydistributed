package org.cohbook.gridprocessing.joins;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import org.cohbook.gridprocessing.reentrancy.BinaryEntryAdapterFilter;
import org.cohbook.gridprocessing.reentrancy.Flight;
import org.cohbook.gridprocessing.reentrancy.Reservation;

import com.tangosol.net.BackingMapContext;
import com.tangosol.net.BackingMapManagerContext;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.Converter;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.InvocableMap.EntryAggregator;
import com.tangosol.util.InvocableMap.ParallelAwareAggregator;
import com.tangosol.util.InvocableMapHelper;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.EntryFilter;
import com.tangosol.util.filter.EqualsFilter;

public class PassengerManifestAggregator implements ParallelAwareAggregator {
    
    private static final long serialVersionUID = -8176820068037938484L;
    
    public static final PassengerManifestAggregator INSTANCE = new PassengerManifestAggregator();

    @SuppressWarnings("unchecked")
    @Override
    public Object aggregate(@SuppressWarnings("rawtypes") Set set) {

        Collection<PassengerManifest> manifests = new ArrayList<>();
        
        for (BinaryEntry flightEntry : (Set<BinaryEntry>)set) {
            manifests.add(
                    getManifest((Flight)flightEntry.getValue(), flightEntry.getContext()));
        }
        
        return manifests;
    }
    
    private PassengerManifest getManifest(Flight flight, BackingMapManagerContext managerContext) {

        BackingMapContext reservationContext = managerContext.getBackingMapContext("reservation");

        ValueExtractor flightIdExtractor = new ReflectionExtractor(
                "getFlightId", null, AbstractExtractor.KEY);
        EntryFilter filter = new EqualsFilter(flightIdExtractor, flight.getFlightId());
        
        Filter filterAdapter = new BinaryEntryAdapterFilter(managerContext, filter);
        
        @SuppressWarnings("unchecked")
        Collection<Entry> reservations = InvocableMapHelper.query(
                reservationContext.getBackingMap(), filterAdapter, true, false, null);
        
        PassengerManifest manifest = new PassengerManifest(flight);
        Converter reservationConverter = managerContext.getValueFromInternalConverter();
        
        for (Entry binaryReservationEntry : reservations) {
            Object binaryReservation = binaryReservationEntry.getValue();
            Reservation reservation = (Reservation) reservationConverter.convert(binaryReservation);
            manifest.addPassenger(reservation.getPassengerName(), reservation.getSeatType());
        }
        
        return manifest;
    }
    
    @Override
    public EntryAggregator getParallelAggregator() {
        return this;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object aggregateResults(@SuppressWarnings("rawtypes") Collection collection) {
        Collection<PassengerManifest> result = new ArrayList<>();
        
        for (Collection<PassengerManifest> partialResult :
            (Collection<Collection<PassengerManifest>>)collection) {
            result.addAll(partialResult);
        }
        
        return result;
    }

}
