package org.cohbook.gridprocessing.reentrancy;

import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.processor.AbstractProcessor;

public class ReservationProcessor1 extends AbstractProcessor {

    private static final long serialVersionUID = 137433267085367798L;

    private Reservation booking;
    
    public ReservationProcessor1() {
    }

    public ReservationProcessor1(Reservation booking) {
        this.booking = booking;
    }

    @Override
    public Object process(Entry entry) {
        
        if (entry.isPresent()) {
            Reservation previous = (Reservation) entry.getValue();
            updateFlight(previous.getFlightId(), previous.getSeatType(), -1);
        }

        if (booking == null) {
            entry.remove(false);
        } else {
            entry.setValue(booking);
            
            updateFlight(booking.getFlightId(), booking.getSeatType(), 1);
        }
        
        return null;
    }
    
    private void updateFlight(int flightId, SeatType seatType, int seats) {
        
        FlightUpdateProcessor processor = new FlightUpdateProcessor(seatType, seats);
        
        NamedCache flightCache = CacheFactory.getCache("flight");
        
        flightCache.invoke(flightId, processor);
    }
}