package org.cohbook.gridprocessing.reentrancy;

import com.tangosol.net.BackingMapManagerContext;
import com.tangosol.net.cache.BackingMapBinaryEntry;
import com.tangosol.util.Binary;
import com.tangosol.util.filter.EntryFilter;

public final class BinaryEntryAdapterFilter implements EntryFilter {
    private final BackingMapManagerContext mgr;
    private final EntryFilter delegate;

    public BinaryEntryAdapterFilter(BackingMapManagerContext mgr, EntryFilter filter) {
        super();
        this.mgr = mgr;
        this.delegate = filter;
    }

    @Override
    public boolean evaluate(Object obj) {
        throw new UnsupportedOperationException();
    }

    @SuppressWarnings({ "rawtypes" })
    @Override
    public boolean evaluateEntry(java.util.Map.Entry entry) {
        return delegate.evaluateEntry(new BackingMapBinaryEntry(
                (Binary)entry.getKey(),
                (Binary)entry.getValue(),
                null,
                mgr));
    }
}