package org.cohbook.gridprocessing.entryprocessor;

import java.io.Serializable;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;

@Portable
public class Result implements Serializable {
    private static final long serialVersionUID = 7982528732554157544L;
    @PortableProperty(0) private Object returnvalue;
    @PortableProperty(1) private Exception exception;
    
    public Result(Object returnvalue, Exception exception) {
        super();
        this.returnvalue = returnvalue;
        this.exception = exception;
    }
    public Object getReturnvalue() {
        return returnvalue;
    }
    public Exception getException() {
        return exception;
    }
}