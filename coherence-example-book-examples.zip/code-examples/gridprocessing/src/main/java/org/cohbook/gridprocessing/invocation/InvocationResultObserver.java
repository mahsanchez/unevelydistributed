package org.cohbook.gridprocessing.invocation;

import java.util.Map;
import java.util.concurrent.Semaphore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.InvocationObserver;
import com.tangosol.net.Member;

class InvocationResultObserver implements InvocationObserver {

    private static final Logger LOG = LoggerFactory.getLogger(InvocationResultObserver.class);
    private final InvocationResult aggregatedResult;
    private final Semaphore invocationComplete;
    private final Map<Integer, Throwable> memberExceptions;;
    
    public InvocationResultObserver(InvocationResult aggregatedResult, Semaphore invocationComplete,
            Map<Integer, Throwable> memberExceptions) {
        this.aggregatedResult = aggregatedResult;
        this.invocationComplete = invocationComplete;
        this.memberExceptions = memberExceptions;
    }

    @Override
    public void memberLeft(Member member) {
        LOG.info("member " + member.getId() + " has left");
    }
    
    @Override
    public void memberFailed(Member member, Throwable throwable) {
        LOG.error("member " + member.getId() + " has failed", throwable);
        memberExceptions.put(member.getId(), throwable);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void memberCompleted(Member member, Object obj) {
        LOG.info("member " + member.getId() + " completed");
        InvocationResult invocationResult = (InvocationResult) obj;
        aggregatedResult.getResults().putAll(
                invocationResult.getResults());
        aggregatedResult.getPartitionExceptions().putAll(
                invocationResult.getPartitionExceptions());
        aggregatedResult.getPartitionsProcessed().add(
                invocationResult.getPartitionsProcessed());
    }
    
    @Override
    public void invocationCompleted() {
        LOG.info("invocation completed");
        invocationComplete.release();
    }
}