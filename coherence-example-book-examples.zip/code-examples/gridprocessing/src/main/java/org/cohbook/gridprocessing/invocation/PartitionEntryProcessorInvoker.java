package org.cohbook.gridprocessing.invocation;
import java.util.HashMap;
import java.util.Map;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;
import com.tangosol.net.NamedCache;
import com.tangosol.net.PartitionedService;
import com.tangosol.net.partition.PartitionSet;
import com.tangosol.util.Filter;
import com.tangosol.util.InvocableMap.EntryProcessor;
import com.tangosol.util.filter.PartitionedFilter;

@Portable
public class PartitionEntryProcessorInvoker implements Invocable {

    private static final long serialVersionUID = 1418288132768859408L;
    private transient InvocationResult result = null;
    @PortableProperty(0) private EntryProcessor entryProcessor;
    @PortableProperty(1) private Filter queryFilter;
    @PortableProperty(2) private String cacheName;
    @PortableProperty(3) private PartitionSet requiredPartitions;
    
    public PartitionEntryProcessorInvoker(EntryProcessor entryProcessor,
            Filter queryFilter, String cacheName, PartitionSet requiredPartitions) {
        this.entryProcessor = entryProcessor;
        this.queryFilter = queryFilter;
        this.cacheName = cacheName;
        this.requiredPartitions = requiredPartitions;
    }

    public PartitionEntryProcessorInvoker() {
    }

    @Override
    public void init(InvocationService invocationservice) {
    }
    
    protected PartitionSet getPartitionSetToProcess(NamedCache cache) {
        PartitionedService service = (PartitionedService) cache.getCacheService();
        Member member = CacheFactory.getCluster().getLocalMember();
        PartitionSet partitionSet = service.getOwnedPartitions(member);
        partitionSet.retain(requiredPartitions);

        return partitionSet;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void run() {
        NamedCache cache = CacheFactory.getCache(cacheName);
        PartitionSet partitionSet = getPartitionSetToProcess(cache);
        
        @SuppressWarnings("rawtypes")
        Map resultMap = new HashMap<>();
        Map<Integer, Exception> exceptionMap = new HashMap<>();
        
        for (int partitionId : partitionSet.toArray()) {
            PartitionSet filterPartSet = new PartitionSet(partitionSet.getPartitionCount());
            filterPartSet.add(partitionId);
            Filter filter = new PartitionedFilter(queryFilter, filterPartSet);
            try {
                resultMap.putAll(
                        cache.invokeAll(filter, entryProcessor));
            } catch(Exception e) {
                exceptionMap.put(partitionId, e);
            }
        }
        
        result = new InvocationResult(resultMap, exceptionMap, partitionSet);
    }

    @Override
    public Object getResult() {
        return result;
    }

}
