package org.cohbook.gridprocessing.invocation;

import java.io.Serializable;
import java.util.Map;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.net.partition.PartitionSet;

@Portable
public class InvocationResult implements Serializable {

    private static final long serialVersionUID = -7857864612051781110L;
    @SuppressWarnings("rawtypes")
    @PortableProperty(0) private Map results;
    @PortableProperty(1) private Map<Integer,Exception> partitionExceptions;
    @PortableProperty(2) private PartitionSet partitionsProcessed;
    
    public InvocationResult(@SuppressWarnings("rawtypes") Map results, Map<Integer, Exception> partitionExceptions,
            PartitionSet partitionsProcessed) {
        super();
        this.results = results;
        this.partitionExceptions = partitionExceptions;
        this.partitionsProcessed = partitionsProcessed;
    }
    public InvocationResult() {
        super();
    }
    @SuppressWarnings("rawtypes")
    public Map getResults() {
        return results;
    }
    public Map<Integer, Exception> getPartitionExceptions() {
        return partitionExceptions;
    }
    public PartitionSet getPartitionsProcessed() {
        return partitionsProcessed;
    }
}