package org.cohbook.gridprocessing.joins;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.cohbook.gridprocessing.reentrancy.Flight;
import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;

public class PassengerManifest implements Serializable {

    private static final long serialVersionUID = -3316810238403001434L;
    
    private int flightId;
    private String origin;
    private String destination;
    private Date departureTime;
    private List<String> economyPassengerNames;
    private List<String> businessPassengerNames;
    
    public PassengerManifest(Flight flight) {
        flightId = flight.getFlightId();
        origin = flight.getOrigin();
        destination = flight.getDestination();
        departureTime = flight.getDepartureTime();
        economyPassengerNames = new ArrayList<>();
        businessPassengerNames = new ArrayList<>();
    }
    
    public void addPassenger(String passenger, SeatType seatType) {
        switch(seatType) {
        case business:
            businessPassengerNames.add(passenger);
            break;
        case economy:
            economyPassengerNames.add(passenger);
            break;
        }
    }

    public int getFlightId() {
        return flightId;
    }

    public String getOrigin() {
        return origin;
    }

    public String getDestination() {
        return destination;
    }

    public Date getDepartureTime() {
        return departureTime;
    }

    public List<String> getBusinessPassengerNames() {
        return businessPassengerNames;
    }

    protected List<String> getEconomyPassengerNames() {
        return economyPassengerNames;
    }
}
