package org.cohbook.gridprocessing.reentrancy;

import java.io.Serializable;
import java.util.Date;

public class Flight implements Serializable {
    
    private static final long serialVersionUID = -852271791032978387L;
    
    private int flightId;
    private String origin;
    private String destination;
    private Date departureTime;
    private int availableBusiness = 42;
    private int availableEconomy = 298;
    
    public Flight(int flightId) {
        this.flightId = flightId;
    }
    public int getFlightId() {
        return flightId;
    }
    public void setFlightId(int flightId) {
        this.flightId = flightId;
    }
    public String getOrigin() {
        return origin;
    }
    public void setOrigin(String origin) {
        this.origin = origin;
    }
    public String getDestination() {
        return destination;
    }
    public void setDestination(String destination) {
        this.destination = destination;
    }
    public Date getDepartureTime() {
        return departureTime;
    }
    public void setDepartureTime(Date departureTime) {
        this.departureTime = departureTime;
    }
    public int getAvailableBusiness() {
        return availableBusiness;
    }
    public void setAvailableBusiness(int availableBusiness) {
        this.availableBusiness = availableBusiness;
    }
    public int getAvailableEconomy() {
        return availableEconomy;
    }
    public void setAvailableEconomy(int availableEconomy) {
        this.availableEconomy = availableEconomy;
    }

    
}
