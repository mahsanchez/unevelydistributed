package org.cohbook.gridprocessing.joins;

import java.util.Collection;

import org.cohbook.gridprocessing.reentrancy.BinaryEntryAdapterFilter;
import org.cohbook.gridprocessing.reentrancy.Flight;
import org.cohbook.gridprocessing.reentrancy.Reservation;

import com.tangosol.net.BackingMapContext;
import com.tangosol.net.BackingMapManagerContext;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.Converter;
import com.tangosol.util.Filter;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.InvocableMapHelper;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.EntryExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.EntryFilter;
import com.tangosol.util.filter.EqualsFilter;

public class PassengerManifestExtractor extends EntryExtractor {
    
    private static final long serialVersionUID = -1781226430999572589L;
    
    public static final PassengerManifestExtractor INSTANCE = new PassengerManifestExtractor();

    @Override
    public Object extractFromEntry(@SuppressWarnings("rawtypes") java.util.Map.Entry entry) {
        BinaryEntry flightEntry = (BinaryEntry) entry;
        Flight flight = (Flight) flightEntry.getValue();
        BackingMapManagerContext managerContext = flightEntry.getContext();

        BackingMapContext reservationContext = managerContext.getBackingMapContext("reservation");

        ValueExtractor flightIdExtractor = new ReflectionExtractor(
                "getFlightId", null, AbstractExtractor.KEY);
        EntryFilter filter = new EqualsFilter(flightIdExtractor, flight.getFlightId());
        
        Filter filterAdapter = new BinaryEntryAdapterFilter(managerContext, filter);
        
        @SuppressWarnings("unchecked")
        Collection<Entry> reservations = InvocableMapHelper.query(
                reservationContext.getBackingMap(), filterAdapter, true, false, null);
        
        PassengerManifest manifest = new PassengerManifest(flight);
        Converter reservationConverter = managerContext.getValueFromInternalConverter();
        
        for (Entry binaryReservationEntry : reservations) {
            Object binaryReservation = binaryReservationEntry.getValue();
            Reservation reservation = (Reservation) reservationConverter.convert(binaryReservation);
            manifest.addPassenger(reservation.getPassengerName(), reservation.getSeatType());
        }
        
        return manifest;
    }
    
}
