package org.cohbook.gridprocessing.entryprocessor;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

import com.tangosol.net.GuardSupport;
import com.tangosol.net.Guardian.GuardContext;
import com.tangosol.util.InvocableMap;
import com.tangosol.util.InvocableMap.EntryProcessor;

public abstract class AbstractVoidProcessor implements EntryProcessor {

    private static final long serialVersionUID = 2116992847372294318L;

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Map processAll(Set set) {
        
        GuardContext guardContext = GuardSupport.getThreadContext();
        
        for (InvocableMap.Entry entry : (Set<InvocableMap.Entry>) set) {
            
            process(entry);
            
            if (guardContext != null) {
                guardContext.heartbeat();
            }
        }
        
        return Collections.EMPTY_MAP;
    }

}
