package org.cohbook.gridprocessing.joins;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.cohbook.gridprocessing.reentrancy.Flight;

public class ItineraryStage implements Serializable {

    private static final long serialVersionUID = -3316810238403001434L;
    
    private int flightId;
    private String origin;
    private String destination;
    private Date departureTime;
    private List<String> passengerNames;
    
    public ItineraryStage(Flight flight) {
        flightId = flight.getFlightId();
        origin = flight.getOrigin();
        destination = flight.getDestination();
        departureTime = flight.getDepartureTime();
        passengerNames = new ArrayList<>();
    }
    
    public void addPassenger(String passenger) {
        passengerNames.add(passenger);
    }

    public int getFlightId() {
        return flightId;
    }

    public String getOrigin() {
        return origin;
    }

    public String getDestination() {
        return destination;
    }

    public Date getDepartureTime() {
        return departureTime;
    }

    public List<String> getPassengerNames() {
        return passengerNames;
    }
}
