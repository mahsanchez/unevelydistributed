package org.cohbook.gridprocessing.reentrancy;

import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.net.BackingMapContext;
import com.tangosol.net.BackingMapManagerContext;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.processor.AbstractProcessor;

@Portable
public class ReservationProcessor2 extends AbstractProcessor {

    private static final long serialVersionUID = 137433267085367798L;

    @PortableProperty(0)
    private Reservation reservation;
    
    public ReservationProcessor2() {
    }

    public ReservationProcessor2(Reservation reservation) {
        this.reservation = reservation;
    }

    @Override
    public Object process(Entry entry) {

        BackingMapManagerContext bmc = ((BinaryEntry)entry).getContext();
        BackingMapContext flightContext = bmc.getBackingMapContext("flight");

        int flightId = ((ReservationKey)entry.getKey()).getFlightId();
        Binary serFlightId = (Binary) bmc.getKeyToInternalConverter().convert(flightId);
        BinaryEntry flightEentry = (BinaryEntry) flightContext.getBackingMapEntry(serFlightId);
        
        if (!flightEentry.isPresent()) {
            throw new IllegalArgumentException("No such flight " + entry.getKey());
        }
        
        Flight flight = (Flight) flightEentry.getValue();

        if (entry.isPresent()) {
            Reservation previous = (Reservation) entry.getValue();
            updateFlight(flight, previous.getSeatType(), -1);
        }
        
        entry.setValue(reservation);
        
        if (reservation != null) {
            updateFlight(flight, reservation.getSeatType(), 1);
            entry.setValue(reservation);
        } else {
            entry.remove(false);
        }
        
        flightEentry.setValue(flight);
        
        return null;
    }
    
    private void updateFlight(Flight flight, SeatType seatType, int seats) {
       
        switch (seatType) {
        case business:
            flight.setAvailableBusiness(flight.getAvailableBusiness() - seats);
            break;
        case economy:
            flight.setAvailableEconomy(flight.getAvailableEconomy() - seats);
            break;
        }
        
        if (flight.getAvailableEconomy() < 0 || flight.getAvailableBusiness() < 0) {
            throw new IllegalStateException("insufficient seat availability");
        }
    }
}