package org.cohbook.gridprocessing.reentrancy;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;

import com.tangosol.net.BackingMapContext;
import com.tangosol.net.BackingMapManagerContext;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.Converter;
import com.tangosol.util.Filter;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.InvocableMapHelper;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.AndFilter;
import com.tangosol.util.filter.EntryFilter;
import com.tangosol.util.filter.EqualsFilter;
import com.tangosol.util.processor.AbstractProcessor;

public class FlightReservationProcessor extends AbstractProcessor {

    private static final long serialVersionUID = 892271987553691051L;
    
    private List<Reservation> reservations;
    private int bookingRef;
    
    public FlightReservationProcessor(List<Reservation> reservations, int bookingRef) {
        this.reservations = reservations;
        this.bookingRef = bookingRef;
    }

    @Override
    public Object process(Entry entry) {
        
        Flight flight = (Flight) entry.getValue();
        BackingMapManagerContext bmc = ((BinaryEntry)entry).getContext();
        BackingMapContext reservationContext = bmc.getBackingMapContext("reservation");
        Converter keyToInternalConverter = bmc.getKeyToInternalConverter();
        
//        Map<Binary, Reservation> reservationMap = new HashMap<>();
        Map<Binary, Reservation> reservationMap = new TreeMap<>();
        for (Reservation reservation : reservations) {
            Binary binKey = (Binary) keyToInternalConverter.convert(new ReservationKey(reservation));
            reservationMap.put(binKey, reservation);
        }
        
        for(Binary key : findReservations(reservationContext, (Integer)entry.getKey(), bookingRef)) {
            if (!reservationMap.containsKey(key)) {
                reservationMap.put(key, null);
            }
        }
        
        for (Map.Entry<Binary, Reservation> mapEntry : reservationMap.entrySet()) {
            Entry reservationsEntry = reservationContext.getBackingMapEntry(mapEntry.getKey());
            
            if (reservationsEntry.isPresent()) {
                Reservation previous = (Reservation) reservationsEntry.getValue();
                updateFlight(flight, previous.getFlightId(), previous.getSeatType(), -1);
            }
            
            Reservation reservation = mapEntry.getValue();
            
            if (reservation == null) {
                reservationsEntry.remove(false);
            } else {
                updateFlight(flight, reservation.getFlightId(), reservation.getSeatType(), 1);
                reservationsEntry.setValue(reservation);
            }
        }
        
        if (flight.getAvailableEconomy() < 0 || flight.getAvailableBusiness() < 0) {
            throw new IllegalStateException("Insufficient availability");
        }
        
        entry.setValue(flight);
        
        return null;
    }
    
    @SuppressWarnings("unchecked")
    private Collection<Binary> findReservations(
            BackingMapContext context, final int flightId, final int bookingRef) {
        
        final BackingMapManagerContext mgr = context.getManagerContext();
        
        ValueExtractor bookingExtractor = new ReflectionExtractor(
                "getBookingId", null, AbstractExtractor.KEY);
        ValueExtractor flightIdExtractor = new ReflectionExtractor(
                "getFlightId", null, AbstractExtractor.KEY);
        
        EntryFilter filter = new AndFilter(
                new EqualsFilter(bookingExtractor, bookingRef),
                new EqualsFilter(flightIdExtractor, flightId));
        
        Filter filterAdapter = new BinaryEntryAdapterFilter(mgr, filter);
        
        return InvocableMapHelper.query(context.getBackingMap(), filterAdapter, false, false, null);
    }
    
    private void updateFlight(Flight flight, int flightId, SeatType seatType, int seats) {
        
        if (flight.getFlightId() != flightId) {
            return;
        }
        
        switch (seatType) {
        case business:
            flight.setAvailableBusiness(flight.getAvailableBusiness() - seats);
            break;
        case economy:
            flight.setAvailableEconomy(flight.getAvailableEconomy() - seats);
            break;
        }
    }
}
