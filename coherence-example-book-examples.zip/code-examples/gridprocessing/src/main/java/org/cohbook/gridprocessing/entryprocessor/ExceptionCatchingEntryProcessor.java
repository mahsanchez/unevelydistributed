package org.cohbook.gridprocessing.entryprocessor;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.InvocableMap.EntryProcessor;
import com.tangosol.util.processor.AbstractProcessor;

@Portable
public class ExceptionCatchingEntryProcessor extends AbstractProcessor {
    
    private static final long serialVersionUID = -2383002822630376579L;

    @PortableProperty(0) private EntryProcessor delegate;
    
    public ExceptionCatchingEntryProcessor() {
    }

    public ExceptionCatchingEntryProcessor(EntryProcessor delegate) {
        super();
        this.delegate = delegate;
    }

    @Override
    public Object process(Entry entry) {
        
        try {
            Object resultObject = delegate.process(entry);
            return new Result(resultObject, null);
        } catch (Exception e) {
            return new Result(null, e);
        }
    }
}
