package org.cohbook.gridprocessing.reentrancy;

import java.io.Serializable;

import com.tangosol.net.cache.KeyAssociation;

public class ReservationKey implements KeyAssociation, Serializable {

    private static final long serialVersionUID = 5024823526308408901L;
    
    private int bookingId;
    private String passengerName;
    private int flightId;
    
    public ReservationKey() {
    }

    public ReservationKey(int bookingId, String passengerName, int flightId) {
        this.bookingId = bookingId;
        this.passengerName = passengerName;
        this.flightId = flightId;
    }
    
    public ReservationKey(Reservation booking) {
        this.bookingId = booking.getBookingId();
        this.passengerName = booking.getPassengerName();
        this.flightId = booking.getFlightId();
    }

    public int getBookingId() {
        return bookingId;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public int getFlightId() {
        return flightId;
    }

    @Override
    public Object getAssociatedKey() {
        return flightId;
    }
}
