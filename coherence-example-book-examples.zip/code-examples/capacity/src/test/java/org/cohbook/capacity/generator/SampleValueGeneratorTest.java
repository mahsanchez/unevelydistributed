package org.cohbook.capacity.generator;

import org.cohbook.capacity.domain.SampleValue;
import org.junit.Before;
import org.junit.Test;


public class SampleValueGeneratorTest {

    private SampleValueGenerator generator;
    @Before
    public void setup() {
        generator = new SampleValueGenerator();
    }
    
    @Test
    public void testGenerate() {
        for (int i = 0 ; i < 10; i++) {
            SampleValue value = generator.generate();
            System.out.println(value);
        }
        
    }
}
