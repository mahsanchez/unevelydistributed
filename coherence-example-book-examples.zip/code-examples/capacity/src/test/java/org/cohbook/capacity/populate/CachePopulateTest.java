package org.cohbook.capacity.populate;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;

public class CachePopulateTest {
    
    private ClusterMemberGroup memberGroup;
    static final Logger LOG = LoggerFactory.getLogger(CachePopulateTest.class);
    private static final int STORAGE_MEMBER_COUNT = 1;
    
    @Before
    public void setup() {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setAdditionalSystemProperty("tangosol.coherence.log.level", 6)
                .setAdditionalSystemProperty("tangosol.pof.enabled", "true")
                .setAdditionalSystemProperty("tangosol.pof.config", "org/cohbook/capacity/pof-config.xml")
                .setStorageEnabledCount(STORAGE_MEMBER_COUNT)
                .setCacheConfiguration("org/cohbook/capacity/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();

    }
    
    @After
    public void tearDown() {
        CacheFactory.shutdown();
        memberGroup.stopAll();
    }
    
    @Test
    public void testPopulate() {
        
        CachePopulate.populateCache(1000);
        assertEquals(1000, CacheFactory.getCache("test").size());
    }
}
