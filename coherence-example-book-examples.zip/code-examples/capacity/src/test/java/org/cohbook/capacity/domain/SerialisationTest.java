package org.cohbook.capacity.domain;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.junit.Assert;
import org.junit.Test;

import com.tangosol.io.Serializer;
import com.tangosol.io.pof.ConfigurablePofContext;
import com.tangosol.util.Binary;
import com.tangosol.util.ExternalizableHelper;

public class SerialisationTest {
    private final Serializer serialiser;
    
    public SerialisationTest() {
        this.serialiser = new ConfigurablePofContext("org/cohbook/capacity/pof-config.xml");
    }

    @Test
    public void equalsCheckSerialisation() {
        
        SampleValue sv = new SampleValue("abc", "def", 99);
        
        Binary binaryObject = ExternalizableHelper.toBinary(sv, serialiser);
        
        Object objectAgain = ExternalizableHelper.fromBinary(binaryObject, serialiser);
        
        Assert.assertTrue(EqualsBuilder.reflectionEquals(sv, objectAgain));
    }
}
