package org.cohbook.capacity.domain;

import com.tangosol.io.pof.annotation.Portable;
import com.tangosol.io.pof.annotation.PortableProperty;

@Portable
public class SampleValue {

    @PortableProperty(0) private String name;
    @PortableProperty(1) private String address;
    @PortableProperty(2) private int count;
    
    public SampleValue() {
    }

    public SampleValue(String name, String address, int count) {
        super();
        this.name = name;
        this.address = address;
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public int getCount() {
        return count;
    }

    @Override
    public String toString() {
        return "SampleValue [name=" + name + ", address=" + address
                + ", count=" + count + "]";
    }
    
}
