package org.cohbook.capacity.populate;

import org.cohbook.capacity.generator.SampleValueGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

public class CachePopulate {

    private static final Logger LOG = LoggerFactory.getLogger(CachePopulate.class);
    /**
     * @param args
     */
    public static void main(String[] args) {
        int entryCount = Integer.parseInt(System.getProperty("cohbook.capacity.entries"));
        System.setProperty("tangosol.coherence.distributed.localstorage", "false");
        System.setProperty("tangosol.pof.enabled", "true");
        System.setProperty("tangosol.pof.config", "org/cohbook/capacity/pof-config.xml");
        System.setProperty("tangosol.coherence.cacheconfig", "org/cohbook/capacity/cache-config.xml");
        populateCache(entryCount);
    }
    
    public static void populateCache(int entryCount) {
        
        NamedCache cache = CacheFactory.getCache("test");
        SampleValueGenerator generator = new SampleValueGenerator();
        
        for (int i = 0; i < entryCount; i++) {
            cache.put(i, generator.generate());
        }
        
        LOG.info("stored " + entryCount + "objects");
    }
}
