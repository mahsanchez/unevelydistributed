package org.cohbook.capacity.generator;

import java.util.Locale;

import org.cohbook.capacity.domain.SampleValue;
import org.databene.benerator.distribution.sequence.RandomIntegerGenerator;
import org.databene.benerator.engine.DefaultBeneratorContext;
import org.databene.domain.address.AddressGenerator;
import org.databene.domain.person.PersonGenerator;

public class SampleValueGenerator {
    
    private PersonGenerator personGenerator;
    private AddressGenerator addressGenerator;
    private RandomIntegerGenerator integerGenerator;
    
    public SampleValueGenerator() {
        DefaultBeneratorContext context = new DefaultBeneratorContext();
        context.setDefaultLocale(Locale.UK);
        personGenerator = new PersonGenerator();
        personGenerator.init(context);
//        personGenerator.setLocale(Locale.UK);
        addressGenerator = new AddressGenerator();
        addressGenerator.init(context);
//        addressGenerator.setCountry(Country.UNITED_KINGDOM);
        integerGenerator = new RandomIntegerGenerator(1, 999);
        integerGenerator.init(context);
    }

    public SampleValue generate() {
        
        return new SampleValue(personGenerator.generateForDataset("test").toString(),
                addressGenerator.generate().toString(),
                integerGenerator.generate());
    }
}
