package org.cohbook.configuration.spring;

import java.util.Collection;
import java.util.Map;

import javax.sql.DataSource;

import com.tangosol.net.cache.CacheLoader;

public class DynamicCacheLoader implements CacheLoader {

    @SuppressWarnings("unused")
    private DataSource dataSource;
    private String cacheName;
    
    public DynamicCacheLoader(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public void setCacheName(String cacheName) {
        this.cacheName = cacheName;
    }

    @Override
    public Object load(Object obj) {
        return cacheName + "-" + obj;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map loadAll(Collection collection) {
        throw new UnsupportedOperationException("not yet implemented");
    }

}
