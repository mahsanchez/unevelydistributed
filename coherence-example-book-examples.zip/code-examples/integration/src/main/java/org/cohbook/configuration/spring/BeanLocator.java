package org.cohbook.configuration.spring;

import org.springframework.beans.PropertyAccessor;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tangosol.config.expression.Value;
import com.tangosol.io.Serializer;
import com.tangosol.net.cache.CacheStore;

public class BeanLocator {
    
    private static ApplicationContext applicationContexts = new ClassPathXmlApplicationContext("classpath:beanRefFactory.xml");
    
    public static BeanFactory getContext(String contextName) {
        return (BeanFactory) applicationContexts.getBean(contextName);
    }
    
    public static Object getBean(String contextName, String beanName) {
        return getContext(contextName).getBean(beanName);
    }

    public static CacheStore getCacheStoreBean(String contextName, String beanName) {
        return getContext(contextName).getBean(beanName, CacheStore.class);
    }
    
    public static Object getBean(String contextName, String beanName, String propertyName, Object propertyValue) {
        if (propertyValue instanceof Value) {
            propertyValue = ((Value)propertyValue).get();
        }
        Object bean = getContext(contextName).getBean(beanName);
        PropertyAccessor accessor = PropertyAccessorFactory.forBeanPropertyAccess(bean);
        accessor.setPropertyValue(propertyName, propertyValue);
        return bean;
    }

    public static Serializer getSerializerBean(String contextName, String beanName) {
        return getContext(contextName).getBean(beanName, Serializer.class);
    }
}
