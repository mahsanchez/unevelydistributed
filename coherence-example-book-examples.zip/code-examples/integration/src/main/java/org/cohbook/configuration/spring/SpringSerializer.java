package org.cohbook.configuration.spring;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;

import com.tangosol.io.DefaultSerializer;
import com.tangosol.io.ReadBuffer.BufferInput;
import com.tangosol.io.Serializer;
import com.tangosol.io.WriteBuffer.BufferOutput;

public class SpringSerializer implements Serializer {

    private final Serializer delegate;
    private final String applicationContextName;

    public SpringSerializer(String applicationContextName) {
        this(applicationContextName, null);
    }

    public SpringSerializer(String applicationContextName, Serializer delegate) {
        this.applicationContextName = applicationContextName;
        if (delegate == null) {
            this.delegate = new DefaultSerializer();
        } else {
            this.delegate = delegate;
        }
    }

    private AutowireCapableBeanFactory getBeanFactory() {

        BeanFactory bf = BeanLocator.getContext(applicationContextName);

        if (bf instanceof ApplicationContext) {
            return ((ApplicationContext)bf).getAutowireCapableBeanFactory();
        } else {
            return null;
        }
    }

    @Override
    public Object deserialize(BufferInput in) throws IOException {
        Object result = delegate.deserialize(in);
        
        if (result != null && result.getClass().isAnnotationPresent(DeserialiseAutowire.class)) {
            getBeanFactory().autowireBeanProperties(
                    result, AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, false);
            try {
                autowireObject(result);
            } catch (IllegalAccessException | IllegalArgumentException
                    | InvocationTargetException e) {
                throw new IOException("failed to inject properties", e);
            }
        }
        
        return result;
    }

    public void autowireObject(Object bean) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {

        Class<?> clazz = bean.getClass();
        BeanWrapper beanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(bean);
        
        for (Method method : clazz.getMethods()) {
            DynamicAutowire dynwire = method.getAnnotation(DynamicAutowire.class);
            if (dynwire != null) {
                method.invoke(getBeanToInject(dynwire, beanWrapper));
            }
        }
        for (Field field : clazz.getFields()) {
            DynamicAutowire dynwire = field.getAnnotation(DynamicAutowire.class);
            if (dynwire != null) {
                field.setAccessible(true);
                field.set(bean, getBeanToInject(dynwire, beanWrapper));
            }
        }
    }
    
    private Object getBeanToInject(DynamicAutowire dynwire, BeanWrapper beanWrapper) {
        String beanName = (String) beanWrapper.getPropertyValue(dynwire.beanNameProperty());
        String contextName = dynwire.contextName().equals(DynamicAutowire.DEFAULT_CONTEXT)
                ? applicationContextName : dynwire.contextName();
        return BeanLocator.getBean(contextName, beanName);
    }
    
    @Override
    public void serialize(BufferOutput bufferoutput, Object obj)
            throws IOException {
        delegate.serialize(bufferoutput, obj);
    }
}
