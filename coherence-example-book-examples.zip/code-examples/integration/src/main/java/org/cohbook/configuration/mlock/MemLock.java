package org.cohbook.configuration.mlock;

import org.apache.commons.lang3.SystemUtils;

import com.sun.jna.Library;
import com.sun.jna.Native;

public class MemLock {

    public static final int MCL_CURRENT = 1;
    public static final int MCL_FUTURE = 2;
    private interface CLibrary extends Library {
        int mlockall(int flags);
    }
    
    public synchronized static void mlockall () {
        if (!SystemUtils.IS_OS_LINUX) {
            return;
        }
        CLibrary instance = (CLibrary) Native.loadLibrary("c", CLibrary.class);
        int errno = instance.mlockall(MCL_CURRENT | MCL_FUTURE);
        if (errno != 0) {
            throw new RuntimeException("mlockall failed with errno=" + errno);
        }
        
    }
}
