package org.cohbook.configuration.spring;

import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.DefaultCacheServer;

public class ExampleStorageMain {

    private static final Logger LOG = LoggerFactory.getLogger(ExampleStorageMain.class);
    /**
     * @param args
     * @throws IOException 
     */
    public static void main(String[] args) {
        
        initialise();

        new DefaultCacheServer(CacheFactory.getConfigurableCacheFactory()).startAndMonitor(5000);
        
    }
    
    public static void initialise() {
        
        loadCoherenceProperties();
        
        BeanLocator.getContext("coherenceBeansContext");
        
    }
    
    private static void loadCoherenceProperties() {
        
        Properties newSystemProperties = System.getProperties();
        
        ResourceLoader resourceLoader = new DefaultResourceLoader();

        try {
            PropertiesLoaderUtils.fillProperties(newSystemProperties,
                    resourceLoader.getResource("classpath:/cluster.properties"));

            PropertiesLoaderUtils.fillProperties(newSystemProperties,
                    resourceLoader.getResource("classpath:/storagenode.properties"));
        } catch (IOException e) {
            LOG.error("failed to load properties");
            throw new RuntimeException(e);
        }

        System.setProperties(newSystemProperties);
    }

}
