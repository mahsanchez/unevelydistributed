package org.cohbook.configuration.spring;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;

public class ServiceInvokingBean {
    
    private static final Logger LOG = LoggerFactory.getLogger(ServiceInvokingBean.class);
    private InvocationService invocationService;

    public void setInvocationService(InvocationService invocationService) {
        this.invocationService = invocationService;
    }


    public void doInvocation() {
        
        ExampleSpringInvocable invocable = new ExampleSpringInvocable();
        invocable.setCluster(invocationService.getCluster());
        
        @SuppressWarnings("unchecked")
        Set<Member> members = invocationService.getInfo().getServiceMembers();
        LOG.info("invoking for members: " + members);
        @SuppressWarnings("unchecked")
        Map<Member,Long> roles = invocationService.query(
                invocable,
                members);
        
        for (Map.Entry<Member, Long> entry : roles.entrySet()) {
            LOG.info("member " + entry.getKey().getId() + " has time offset from cluster time of " + entry.getValue() + "ms");
        }
    }
}
