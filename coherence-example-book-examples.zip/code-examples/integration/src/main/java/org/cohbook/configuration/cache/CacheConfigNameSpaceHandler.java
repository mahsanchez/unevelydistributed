package org.cohbook.configuration.cache;

import java.net.URI;

import com.tangosol.config.xml.AbstractNamespaceHandler;
import com.tangosol.config.xml.ProcessingContext;
import com.tangosol.run.xml.XmlElement;

public class CacheConfigNameSpaceHandler extends AbstractNamespaceHandler {
    
    @Override
    public void onStartNamespace(ProcessingContext processingcontext,
            XmlElement element, String prefix, URI uri) {
        setDocumentPreprocessor(new ServiceSchemePreprocessor(prefix));
    }
}
