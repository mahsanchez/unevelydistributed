package org.cohbook.configuration.bang;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

public class BangMain {
    
    public static ApplicationContext ctx;

    public static void main(String[] args) {
        
        System.setProperty("tangosol.coherence.cacheconfig", "org/cohbook/configuration/bang/cache-config.xml");
        
        NamedCache test = CacheFactory.getCache("test");
        
    }
    
    public static Object getBean(String bean) {
        if (ctx == null) {
            ctx = new ClassPathXmlApplicationContext("org/cohbook/configuration/bang/context.xml");
        }
        return ctx.getBean(bean);
    }

}
