package org.cohbook.configuration.spring;

import java.util.Collection;
import java.util.Map;

import javax.sql.DataSource;

import com.tangosol.net.cache.CacheLoader;

public class ExampleCacheLoader implements CacheLoader {

    @SuppressWarnings("unused")
    private DataSource dataSource;
    
    protected ExampleCacheLoader(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public Object load(Object obj) {
        throw new UnsupportedOperationException("not yet implemented");
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Map loadAll(Collection collection) {
        throw new UnsupportedOperationException("not yet implemented");
    }

}
