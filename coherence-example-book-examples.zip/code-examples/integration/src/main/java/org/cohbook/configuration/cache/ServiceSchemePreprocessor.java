package org.cohbook.configuration.cache;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.tangosol.config.ConfigurationException;
import com.tangosol.config.xml.DocumentPreprocessor;
import com.tangosol.config.xml.ProcessingContext;
import com.tangosol.run.xml.QualifiedName;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.run.xml.XmlValue;

public class ServiceSchemePreprocessor implements DocumentPreprocessor {

    private final QualifiedName schemeType;
    
    public ServiceSchemePreprocessor(String prefix) {
        schemeType = new QualifiedName(prefix, "scheme-type");
    }

    private static final String ALREADYPROCESSEDCOOKIE = ServiceSchemePreprocessor.class.getName();
    
    private Map<String, String> schemeParentMap;
    private Map<String, String> schemeTypeMap;
    private Set<String> definedServiceNames;

    @SuppressWarnings("unchecked")
    @Override
    public boolean preprocess(ProcessingContext context,
            XmlElement xmlelement) throws ConfigurationException {
        
        if (Boolean.TRUE.equals(context.getCookie(Boolean.class, ALREADYPROCESSEDCOOKIE))) {
            return false;
        }
        
        schemeParentMap = new HashMap<>();
        schemeTypeMap = new HashMap<>();
        definedServiceNames = new HashSet<>();
        
        XmlElement schemes = xmlelement.getElement("caching-schemes");
        
        for (XmlElement schemeElement : (List<XmlElement>) schemes.getElementList()) {
            if (schemeElement.getName().equals("distributed-scheme")) {
                validateSchemeElement(schemeElement);
            }
        }
        
        for (Map.Entry<String, String> entry : schemeParentMap.entrySet()) {
            String parent = entry.getValue();
            String child = entry.getKey();
            validateHeirarchy(parent, child);
        }
        
        context.addCookie(Boolean.class, ALREADYPROCESSEDCOOKIE, Boolean.TRUE);
        
        return false;
        
    }
    
    private void validateHeirarchy(String parent, String child) {
        String parentType = schemeTypeMap.get(parent);
        if (parentType == null) {
            throw new ConfigurationException("scheme " + child + " references non-existent scheme " + parent, "");
        }
        String childType = schemeTypeMap.get(child);
        switch (childType) {
        case "cache":
            if (parentType.equals("abstract-service")) {
                throw new ConfigurationException("cache scheme " + child + " references abstract service scheme " + parent,
                        "scheme type \"cache\" may reference only schemes of scheme type \"cache\" or \"service\"");
            }
            break;
        case "service":
        case "abstract-service":
            if (!parentType.equals("abstract-service")) {
                throw new ConfigurationException("cache scheme " + child + " references scheme " + parent + "of scheme type \"" + childType + "\"",
                        "scheme type \"" + childType + "\" may reference only schemes of scheme type \"abstract-service\"");
                
            }
        }
    }
    
    private static final Set<String> CACHE_SCHEME_ELEMENTS = new HashSet<String>(Arrays.asList(new String[] {
            "backing-map-scheme",
            "listener"
            }));
    
    private static final Set<String> ALL_SCHEME_ELEMENTS = new HashSet<String>(Arrays.asList(new String[] {
            "scheme-name",
            "scheme-ref",
            }));

    @SuppressWarnings("unchecked")
    private void validateSchemeElement(XmlElement xmlelement) {

        String schemeTypeName = schemeType.getName();
        XmlValue attribute = xmlelement.getAttribute(schemeTypeName);
        
        if (attribute == null) {
            raiseError("no scheme-type attribute", xmlelement);
        }
        
        String type = attribute.getString();
        
        switch(type) {
        case "cache":
            for (XmlElement subelement : (List<XmlElement>)xmlelement.getElementList()) {
                if (!CACHE_SCHEME_ELEMENTS.contains(subelement.getName())
                        && !ALL_SCHEME_ELEMENTS.contains(subelement.getName())) {
                    raiseError("cache scheme contains invalid element" + subelement, xmlelement);
                }
            }
            break;
        case "service":
            String serviceName = getChildElementValue(xmlelement, "service-name");
            if (serviceName == null) {
                serviceName = "DefaultDistributedService";
            }
            if (definedServiceNames.contains(serviceName)) {
                raiseError("duplicate service name " + serviceName, xmlelement);
            }
            definedServiceNames.add(serviceName);
            for (XmlElement subelement : (List<XmlElement>)xmlelement.getElementList()) {
                if (CACHE_SCHEME_ELEMENTS.contains(subelement.getName())) {
                    raiseError("service scheme contains invalid element" + subelement, xmlelement);
                }
            }
            break;
        case "abstract-service":
            for (XmlElement subelement : (List<XmlElement>)xmlelement.getElementList()) {
                String elementName = subelement.getName();
                if (elementName.equals("service-name") || CACHE_SCHEME_ELEMENTS.contains(elementName)) {
                    raiseError("service scheme contains invalid element" + subelement, xmlelement);
                }
            }
            break;
        default:
            raiseError("invalid scheme-type " + type, xmlelement);    
        }
        
        String schemeName = getChildElementValue(xmlelement, "scheme-name");
        schemeTypeMap.put(schemeName, type);

        String schemeRef = getChildElementValue(xmlelement, "scheme-ref");
        if (schemeRef != null) {
            schemeParentMap.put(schemeName, schemeRef);
        }
    }
    
    private String getChildElementValue(XmlElement element, String childElementName) {
        String result = null;
        XmlElement childElement = element.getElement(childElementName);
        if (childElement != null) {
            result = childElement.getString();
        }
        return result;
    }

    public void raiseError(String problem, XmlElement xmlelement) {
        String context = xmlelement.toString();
        XmlElement schemeElement = xmlelement.getElement("scheme-name");
        if (schemeElement != null) {
            context = "scheme " + schemeElement.getString();
        }
        throw new ConfigurationException(problem + " in " + context, "");
    }
}