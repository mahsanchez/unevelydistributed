package org.cohbook.configuration.spring;

import org.springframework.context.SmartLifecycle;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.ConfigurableCacheFactory;
import com.tangosol.net.DefaultCacheFactoryBuilder;

public class LifecycleValidatingCacheFactoryBuilder extends
        DefaultCacheFactoryBuilder {
    
    private static volatile boolean buildOk = false;

    @Override
    public ConfigurableCacheFactory getConfigurableCacheFactory(
            ClassLoader loader) {
        if (!buildOk) {
            throw new IllegalStateException("Attempt to build a cache factory too early");
        }
        ConfigurableCacheFactory factory = super.getConfigurableCacheFactory(loader);
        return factory;
    }

    @Override
    public ConfigurableCacheFactory getConfigurableCacheFactory(
            String sConfigURI, ClassLoader loader) {
        if (!buildOk) {
            throw new IllegalStateException("Attempt to build a cache factory too early");
        }
        ConfigurableCacheFactory factory = super.getConfigurableCacheFactory(sConfigURI, loader);
        return factory;
    }
    
    static void enableBuild() {
        buildOk = true;
    }
    
    public static final int BEFORE_CLUSTER_PHASE = 100;
    public static final int ClUSTER_PHASE = 200;
    public static final int AFTER_CLUSTER_PHASE = 300;
    
    public static class BuilderLifeCycle implements SmartLifecycle {

        @Override
        public void start() {
            enableBuild();
            CacheFactory.ensureCluster();
        }

        @Override
        public void stop() {
        }

        @Override
        public boolean isRunning() {
            return buildOk;
        }

        @Override
        public int getPhase() {
            return ClUSTER_PHASE;
        }

        @Override
        public boolean isAutoStartup() {
            return true;
        }

        @Override
        public void stop(Runnable callback) {
        }
    }
}
