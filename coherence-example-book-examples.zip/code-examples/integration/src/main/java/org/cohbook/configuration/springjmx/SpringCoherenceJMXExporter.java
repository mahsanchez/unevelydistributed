package org.cohbook.configuration.springjmx;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.management.JMException;
import javax.management.ObjectName;

import org.springframework.jmx.export.MBeanExporter;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.management.Registry;

public class SpringCoherenceJMXExporter extends MBeanExporter {
    
    private Registry cachedRegistry = null;
    private final Map<ObjectName, String> registeredBeans = new ConcurrentHashMap<>();
    
    protected synchronized Registry getRegistry() {
        if (cachedRegistry == null) {
            cachedRegistry = CacheFactory.ensureCluster().getManagement();
        }
        return cachedRegistry;
    }

    @Override
    protected void doRegister(Object mbean, ObjectName objectName)
            throws JMException {

        Registry registry = getRegistry();
        
        String sname = registry.ensureGlobalName(objectName.getKeyPropertyListString());
        if (registry.isRegistered(sname)) {
            registry.unregister(sname);
        }
        
        registry.register(sname, mbean);
        registeredBeans.put(objectName, sname);
    }

    @Override
    protected void doUnregister(ObjectName objectName) {

        Registry registry = getRegistry();
        
        String sname = registeredBeans.get(objectName);
        if (sname != null) {
            registry.unregister(sname);
        }
    }

    @Override
    protected void unregisterBeans() {
        for (ObjectName objectName : registeredBeans.keySet()) {
            doUnregister(objectName);
        }
        registeredBeans.clear();
    }
}
