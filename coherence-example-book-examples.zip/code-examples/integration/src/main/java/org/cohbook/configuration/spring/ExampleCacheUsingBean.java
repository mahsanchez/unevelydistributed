package org.cohbook.configuration.spring;

import com.tangosol.net.NamedCache;

public class ExampleCacheUsingBean {
    
    private NamedCache cache;
    
    public void setCache(NamedCache cache) {
        this.cache = cache;
    }

    public void populateCache() {
        for (int i = 0; i < 100; i++) {
            cache.put(i, Integer.toString(i));
        }

    }
    
    public void readCache() {
        for (int i = 0; i < 100; i++) {
            System.out.println(cache.get(i));
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
