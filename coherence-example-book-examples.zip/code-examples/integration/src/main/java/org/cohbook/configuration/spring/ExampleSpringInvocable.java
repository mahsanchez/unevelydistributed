package org.cohbook.configuration.spring;

import java.io.Serializable;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.tangosol.net.Cluster;
import com.tangosol.net.Invocable;
import com.tangosol.net.InvocationService;

@DeserialiseAutowire
public class ExampleSpringInvocable implements Invocable, Serializable {

    private static final long serialVersionUID = -41997101706674258L;
    private transient Cluster cluster;
    private transient long result;
    
    public ExampleSpringInvocable() {
    }
    
    @Autowired
    public void setCluster(Cluster cluster) {
        this.cluster = cluster;
    }

    @Override
    public void init(InvocationService invocationservice) {
    }

    @Override
    public void run() {
        result = cluster.getTimeMillis() - new Date().getTime();
    }

    @Override
    public Object getResult() {
        return result;
    }
}
