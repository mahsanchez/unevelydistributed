package org.cohbook.configuration.spring;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.Semaphore;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.access.BeanFactoryLocator;
import org.springframework.beans.factory.access.BeanFactoryReference;
import org.springframework.beans.factory.access.SingletonBeanFactoryLocator;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.ConfigurableCacheFactory;
import com.tangosol.net.DefaultCacheServer;
import com.tangosol.net.events.EventInterceptor;
import com.tangosol.net.events.annotation.Interceptor;
import com.tangosol.net.events.application.LifecycleEvent;
import com.tangosol.util.RegistrationBehavior;

public class ExampleStorageDisabledMain {

    private static Semaphore startupComplete = new Semaphore(0);
    /**
     * @param args
     * @throws InterruptedException 
     * @throws IOException 
     */
    public static void main(String[] args) throws InterruptedException, IOException {
        
        initialise();
        
        BeanFactoryLocator bfl = SingletonBeanFactoryLocator.getInstance();
        
        BeanFactoryReference bfr = bfl.useBeanFactory("applicationBeansContext");
        BeanFactory bf = bfr.getFactory();
        
        ExampleCacheUsingBean cub = bf.getBean("exampleCacheUsingBean", ExampleCacheUsingBean.class);
        cub.populateCache();
        cub.readCache();
        
        ServiceInvokingBean sib = bf.getBean("exampleServiceInvokingBean", ServiceInvokingBean.class);
        
        sib.doInvocation();
    }
    
    @Interceptor(identifier="ClusterStarted")
    public static class ClusterStarted implements EventInterceptor<LifecycleEvent> {
        @Override
        public void onEvent(LifecycleEvent event) {
            if (event.getType() == LifecycleEvent.Type.ACTIVATED) {
                startupComplete.release();
            }
        }
    }
    
    private static ClusterStarted CLUSTERSTARTED = new ClusterStarted();
    
    private static void registerLifecycleListener(ConfigurableCacheFactory factory) {
        factory.getInterceptorRegistry().registerEventInterceptor(
                CLUSTERSTARTED, RegistrationBehavior.IGNORE);
    }
    
    public static void initialise() throws IOException {
        loadCoherenceProperties();
        
        BeanLocator.getContext("coherenceBeansContext");
        
        registerLifecycleListener(CacheFactory.getConfigurableCacheFactory());
        
        DefaultCacheServer.start();
        
        try {
            startupComplete.acquire();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
    private static void loadCoherenceProperties() throws IOException {
        
        Properties newSystemProperties = System.getProperties();
        
        ResourceLoader resourceLoader = new DefaultResourceLoader();

        PropertiesLoaderUtils.fillProperties(newSystemProperties,
                resourceLoader.getResource("classpath:/cluster.properties"));

        PropertiesLoaderUtils.fillProperties(newSystemProperties,
                resourceLoader.getResource("classpath:/storagedisablednode.properties"));

        System.setProperties(newSystemProperties);
    }
}
