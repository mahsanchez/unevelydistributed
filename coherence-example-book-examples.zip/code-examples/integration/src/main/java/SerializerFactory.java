import com.tangosol.io.pof.ConfigurablePofContext;


public class SerializerFactory {
    
    public static Object getSerializer() {
        return new ConfigurablePofContext();
    }

}
