package org.cohbook.configuration.spring;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

public class TestDynamicCacheLoader {

    private ClusterMemberGroup memberGroup;

    @Test
    public void testMainCluster() throws InterruptedException, IOException {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setClusterMemberInstanceClassName("org.cohbook.configuration.spring.LittleGridClusterMember")
                .setStorageEnabledCount(2)
                .buildAndConfigureForStorageDisabledClient();
        
        ExampleStorageDisabledMain.initialise();
        
        NamedCache cache1 = CacheFactory.getCache("dyn-one");
        
        NamedCache cache2 = CacheFactory.getCache("dyn-two");
        
        Assert.assertEquals("dyn-one-two", cache1.get("two"));
        Assert.assertEquals("dyn-two-three", cache2.get("three"));
        
        memberGroup.stopAll();
        
    }

}
