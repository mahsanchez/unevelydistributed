package org.cohbook.configuration.springjmx;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

public class TestMBeanExporter {

    private ClusterMemberGroup memberGroup;

    @Ignore
    @Test
    public void testJMXMbean() throws InterruptedException, IOException {
        
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setClusterMemberInstanceClassName("org.cohbook.configuration.spring.LittleGridClusterMember")
                .setStorageEnabledCount(2)
                .setJmxMonitorCount(1)
                .buildAndConfigureForNoClient();
        
        NamedCache cache1 = CacheFactory.getCache("dyn-one");
        
        NamedCache cache2 = CacheFactory.getCache("dyn-two");
        
        Assert.assertEquals("dyn-one-two", cache1.get("two"));
        Assert.assertEquals("dyn-two-three", cache2.get("three"));
        
        memberGroup.stopAll();
        
    }

}
