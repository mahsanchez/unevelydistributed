package org.cohbook.configuration.spring;

import java.io.IOException;

import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

public class TestSpringMains {

    private ClusterMemberGroup memberGroup;

    @Test
    public void testMainCluster() throws InterruptedException, IOException {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setClusterMemberInstanceClassName("org.cohbook.configuration.spring.LittleGridClusterMember")
                .setAdditionalSystemProperty(
                        "tangosol.coherence.cachefactorybuilder",
                        "org.cohbook.configuration.spring.LifecycleValidatingCacheFactoryBuilder")
                .setStorageEnabledCount(2)
                .buildAndConfigureForStorageDisabledClient();
        
        ExampleStorageDisabledMain.main(null);
        
        memberGroup.stopAll();
        
    }

}
