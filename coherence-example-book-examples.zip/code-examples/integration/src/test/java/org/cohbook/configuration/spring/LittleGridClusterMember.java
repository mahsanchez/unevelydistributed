package org.cohbook.configuration.spring;

import org.littlegrid.impl.DefaultClusterMember;

public class LittleGridClusterMember extends DefaultClusterMember {

    @Override
    public void doBeforeStart() {
        ExampleStorageMain.initialise();
    }
}
