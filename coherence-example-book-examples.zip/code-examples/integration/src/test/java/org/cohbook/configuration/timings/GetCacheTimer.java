package org.cohbook.configuration.timings;

import org.apache.commons.lang3.time.StopWatch;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

public class GetCacheTimer {
    
    private static final int PUTCOUNT = 100000;
    private static final Logger LOG = LoggerFactory.getLogger(GetCacheTimer.class);
    
    @Ignore
    @Test
    public void runTest() {
        NamedCache cache = CacheFactory.getCache("test");
        for (int i = 0; i < 10; i++) {
            singleCacheTimeLocalNode(cache);
            onDemandCacheTimeLocalNode();
        }
    }
    
    public void singleCacheTimeLocalNode(NamedCache cache) {
        
        cache.put(-1, Integer.toHexString(-1));

        StopWatch sw = new StopWatch();
        
        sw.start();
        for(int i = 0; i < PUTCOUNT; i++) {
            cache.put(i, Integer.toHexString(i));
        }
        sw.stop();
        
        LOG.info(PUTCOUNT + " single cache puts in " + sw.toString());
        
    }

    public void onDemandCacheTimeLocalNode() {
        
        StopWatch sw = new StopWatch();

        CacheFactory.getCache("test").put(-1, Integer.toHexString(-1));
        
        sw.start();
        for(int i = 0; i < PUTCOUNT; i++) {
            CacheFactory.getCache("test").put(i, Integer.toHexString(i));
        }
        sw.stop();
        
        LOG.info(PUTCOUNT + " on demand cache puts in " + sw.toString());
        
    }
    
    @Test
    public void concurrencyTest() {
        for (int j = 0; j < 10; j++) {
            threadTestCommonCache();
            threadTestOwnCache();
        }
    }

    public void threadTestCommonCache() {
        
        final NamedCache cache = CacheFactory.getCache("test");
        
        Runnable r = new Runnable() {

            @Override
            public void run() {
                singleCacheTimeLocalNode(cache);            }
        };
        
        Thread t1 = new Thread(r);
        Thread t2 = new Thread(r);
        
        StopWatch s = new StopWatch();
        
        s.start();
        
        t1.start();
        t2.start();
        
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        
        s.stop();
        LOG.info("shared instance " + s);
        
    }
    
    public void threadTestOwnCache() {
        
        final NamedCache c1 = CacheFactory.getCache("test");
        final NamedCache c2 = CacheFactory.getCache("test");
        
        Runnable r1 = new Runnable() {

            @Override
            public void run() {
                singleCacheTimeLocalNode(c1);            }
        };
        Runnable r2 = new Runnable() {

            @Override
            public void run() {
                singleCacheTimeLocalNode(c2);            }
        };
        
        Thread t1 = new Thread(r1);
        Thread t2 = new Thread(r2);
        
        StopWatch s = new StopWatch();
        
        s.start();

        t1.start();
        t2.start();
        
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        
        s.stop();
        LOG.info("own instances " + s);
        
    }
    

}
