package org.cohbook.configuration.cache;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.CacheFactoryBuilder;
import com.tangosol.net.ConfigurableCacheFactory;
import com.tangosol.util.WrapperException;

public class CacheConfigNameSpaceHandlerTest {

    private CacheFactoryBuilder builder;
    private ClassLoader loader;
    private static final Logger LOG = LoggerFactory.getLogger(CacheConfigNameSpaceHandlerTest.class);
    
    @Before
    public void setup() {
        builder = CacheFactory.getCacheFactoryBuilder();
        loader = this.getClass().getClassLoader();
    }
    @Test
    public void testGoodConfig() {
        loadFactory(
                "org/cohbook/configuration/cache/validated-cache-config.xml");
    }
    
    @Test(expected=WrapperException.class)
    public void testDuplicateService() {
        loadFactory(
                "org/cohbook/configuration/cache/duplicate-service-cache-config.xml");
    }
    
    @Test(expected=WrapperException.class)
    public void testDuplicateDefault() {
        loadFactory(
                "org/cohbook/configuration/cache/duplicate-default-cache-config.xml");
    }

    @Test(expected=WrapperException.class)
    public void testServiceService() {
        loadFactory(
                "org/cohbook/configuration/cache/service-service-cache-config.xml");
    }
    
    @Test(expected=WrapperException.class)
    public void testInvalidService() {
        loadFactory(
                "org/cohbook/configuration/cache/invalid-service-cache-config.xml");
    }
    
    @Test(expected=WrapperException.class)
    public void testInvalidAbstractService() {
        loadFactory(
                "org/cohbook/configuration/cache/invalid-abstract-service-cache-config.xml");
    }
    
    @Test(expected=WrapperException.class)
    public void testInvalidCache() {
        loadFactory(
                "org/cohbook/configuration/cache/invalid-cache-cache-config.xml");
    }
    
    private ConfigurableCacheFactory loadFactory(String uri) {
        LOG.info("loading " + uri);
        try {
        return builder.getConfigurableCacheFactory(
                uri, loader);
        } catch (WrapperException ex) {
            LOG.info("caught " + ex.getMessage());
            throw ex;
        }
    }

    @After
    public void tearDown() {
        CacheFactory.shutdown();
    }
}
