package org.cohbook.events.partitionloss;

import java.lang.management.ManagementFactory;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

public class LostPartitionListenerTest {

    private ClusterMemberGroup memberGroup;

    @Before
    public void setUp() throws Exception {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setCacheConfiguration("org/cohbook/events/partitionloss/cache-config.xml")
                .setStorageEnabledCount(2)
                .setJmxMonitorCount(1)
                .buildAndConfigureForStorageDisabledClient();
    }

    @Test
    public void testPartitionListener() throws MalformedObjectNameException, AttributeNotFoundException, 
            InstanceNotFoundException, MBeanException, ReflectionException, InterruptedException {
        
        NamedCache cache = CacheFactory.getCache("test");
        cache.put(1, "A");
        
        memberGroup.stopMember(memberGroup.getStartedMemberIds()[0]);
        
        Thread.sleep(3000);
        
        ObjectName name = new ObjectName(
                "Coherence:type=LostPartitionListener,service=exampleDistributedService,*");
        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
        
        Integer plc = 0;
        for (ObjectName mbean : mbs.queryNames(name, null)) {
            plc += (Integer) mbs.getAttribute(mbean, "PartitionsLostCount");
        }
        
        Assert.assertTrue(plc == 6 || plc == 7);
    }

}
