package org.cohbook.events.singletonService;

import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;

public class SingletonServiceTest {

    private ClusterMemberGroup memberGroup;

    @Before
    public void setUp() throws Exception {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setCacheConfiguration("org/cohbook/events/singletonservice/cache-config.xml")
                .setStorageEnabledCount(4)
                .buildAndConfigureForNoClient();
    }
    
    @Test
    public void testSingletonService() throws InterruptedException {
        
        for (int member : memberGroup.getStartedMemberIds()) {
            Thread.sleep(3000);
            memberGroup.stopMember(member);
        }
    }
}
