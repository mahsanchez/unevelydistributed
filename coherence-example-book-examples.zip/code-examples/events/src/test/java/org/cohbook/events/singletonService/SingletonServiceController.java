package org.cohbook.events.singletonService;

import com.tangosol.net.Service;
import com.tangosol.net.events.EventInterceptor;
import com.tangosol.net.events.application.LifecycleEvent;

public class SingletonServiceController implements EventInterceptor<LifecycleEvent> {

    @SuppressWarnings("unused")
    private SingletonService singletonService = null;

    @Override
    public void onEvent(LifecycleEvent event) {
        
        switch(event.getType()) {
        case ACTIVATED:
            Service service = event.getConfigurableCacheFactory().ensureService(getServiceName());
            singletonService = new SingletonService(service, getRunnable());
            break;
        default:
        }
    }
    
    protected String getServiceName() {
        return "exampleDistributedService";
    }
    
    protected Runnable getRunnable() {
        return new TestRunnable();
    }
}
