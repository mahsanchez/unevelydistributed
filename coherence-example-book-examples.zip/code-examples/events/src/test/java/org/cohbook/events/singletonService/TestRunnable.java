package org.cohbook.events.singletonService;

import com.tangosol.net.CacheFactory;

public class TestRunnable implements Runnable {
    @Override
    public void run() {
        int member = CacheFactory.getCluster().getLocalMember().getId();
        for (;;) {
            
            if (!CacheFactory.getCluster().isRunning()) {
                System.out.println("Goodbye from member " + member);
                return;
            }
            System.out.println("Hello from member " + member);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println("member " + member + " interrupted");
                return;
            }
        }
    }
}