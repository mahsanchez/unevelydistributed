package org.cohbook.events;

import java.util.Arrays;
import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.net.events.EventDispatcher;
import com.tangosol.net.events.EventDispatcherAwareInterceptor;
import com.tangosol.net.events.EventInterceptor;
import com.tangosol.net.events.partition.cache.EntryEvent;

public class EntryEventTest {

    @SuppressWarnings("unused")
    private ClusterMemberGroup memberGroup;
    private NamedCache cache;
    private static final Logger LOG = LoggerFactory.getLogger(EntryEventTest.class);

    @Before
    public void setup() {
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setStorageEnabledCount(2)
                .setCacheConfiguration("org/cohbook/events/cache-config.xml")
                .buildAndConfigureForStorageDisabledClient();

        cache = CacheFactory.getCache("configuration");

    }

    public static class TestInterceptor implements EventInterceptor<EntryEvent>, EventDispatcherAwareInterceptor<EntryEvent> {

        @Override
        public void onEvent(EntryEvent event) {
            LOG.info("got event " + event.toString());
        }

        @Override
        public void introduceEventDispatcher(String sIdentifier, EventDispatcher
                dispatcher)
        {
            dispatcher.addEventInterceptor(sIdentifier, this,
                    new HashSet<>(Arrays.asList(EntryEvent.Type.INSERTING)), true);
        }        
    }

    @Test
    public void testActiveChange() {

        TestInterceptor interceptor = new TestInterceptor();

        CacheFactory.getConfigurableCacheFactory().getInterceptorRegistry()
        .registerEventInterceptor(interceptor);

        cache.put(1, "a");
    }

}
