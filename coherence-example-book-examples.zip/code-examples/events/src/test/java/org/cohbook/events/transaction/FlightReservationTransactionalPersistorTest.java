package org.cohbook.events.transaction;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.cohbook.gridprocessing.reentrancy.Flight;
import org.cohbook.gridprocessing.reentrancy.FlightReservationProcessor;
import org.cohbook.gridprocessing.reentrancy.Reservation;
import org.cohbook.gridprocessing.reentrancy.Reservation.SeatType;
import org.h2.tools.Server;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.littlegrid.ClusterMemberGroup;
import org.littlegrid.ClusterMemberGroupUtils;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;
import com.tangosol.util.InvocableMap.EntryProcessor;

public class FlightReservationTransactionalPersistorTest {

    private static final String DBURL = "jdbc:h2:tcp://localhost/mem:test;DB_CLOSE_DELAY=-1";
    private static final String FLIGHTTABLESQL = "CREATE TABLE FLIGHT ("
            + "FLIGHTID INTEGER NOT NULL PRIMARY KEY,"
            + "ORIGIN VARCHAR(100) NOT NULL,"
            + "DESTINATION VARCHAR(100) NOT NULL,"
            + "DEPARTURETIME DATETIME NOT NULL,"
            + "AVAILABLEBUSINESS INTEGER NOT NULL,"
            + "AVAILABLEECONOMY INTEGER NOT NULL"
            + ");";
    private static final String CLEANFLIGHTSQL = "DELETE FROM FLIGHT";
    private static final String RESERVATIONTABLESQL = "CREATE TABLE RESERVATION ("
            + "FLIGHTID INTEGER NOT NULL,"
            + "BOOKINGID VARCHAR(100) NOT NULL,"
            + "PASSENGERNAME VARCHAR(100) NOT NULL,"
            + "SEATTYPE VARCHAR(20) NOT NULL,"
            + "CHECKEDIN BOOLEAN NOT NULL,"
            + "PRIMARY KEY(FLIGHTID, BOOKINGID, PASSENGERNAME)"
            + ");";
    private static final String CLEANRESERVATIONSQL = "DELETE FROM RESERVATION";
    
    private JdbcOperations jdbcop;
    
    @SuppressWarnings("unused")
    private static Server h2Server;

    @SuppressWarnings("unused")
    private ClusterMemberGroup memberGroup;

    private static int FLIGHTID = 23;
    private static int BOOKINGID = 42;
    private static Date DEPARTURETIME = new Date();
    private static final String[] PASSENGERS = { "Louis Bleriot", "Amelia Earhart", "Chuck Yeager", "Charles Lindbergh", "Per Lindstrand",
        "Wop May", "Joseph-Michel Montgolfier", "Jacques-Étienne Montgolfier", "Beryl Markham", "Sheila Scott"};

    private int rowsread;

    @BeforeClass
    public static void setupTable() throws SQLException {
        
        h2Server = Server.createTcpServer().start();
        
        DataSource dataSource = new DriverManagerDataSource(DBURL);
        
        JdbcOperations jdbcop = new JdbcTemplate(dataSource);
        jdbcop.execute(FLIGHTTABLESQL);
        jdbcop.execute(RESERVATIONTABLESQL);
    }

    @Before
    public void setUp() throws SQLException {
        DataSource dataSource = new DriverManagerDataSource(DBURL);
        
        jdbcop = new JdbcTemplate(dataSource);
        jdbcop.execute(CLEANFLIGHTSQL);
        jdbcop.execute(CLEANRESERVATIONSQL);
        
        memberGroup = ClusterMemberGroupUtils.newBuilder()
                .setCacheConfiguration("org/cohbook/events/transaction/cache-config.xml")
                .setAdditionalSystemProperty("jdbc.url", DBURL)
                .setStorageEnabledCount(2)
                .setJmxMonitorCount(1)
                .setJarsToExcludeFromClassPath("h2-1.3.172.jar")
                .buildAndConfigureForStorageDisabledClient();
        
        NamedCache flightCache = CacheFactory.getCache("flight");
        CacheFactory.getCache("reservation");
        Flight flight = new Flight(FLIGHTID);
        flight.setAvailableBusiness(10);
        flight.setAvailableEconomy(100);
        flight.setDepartureTime(DEPARTURETIME);
        flight.setOrigin("Shoreham");
        flight.setDestination("Dieppe");
        flightCache.put(FLIGHTID, flight);

    }

    @Test
    public void testRemove() {

        NamedCache flightCache = CacheFactory.getCache("flight");
        
        flightCache.remove(FLIGHTID);

        rowsread = 0;
        jdbcop.query("SELECT * FROM FLIGHT", new RowCallbackHandler() {
            
            @Override
            public void processRow(ResultSet rs) throws SQLException {
                rowsread++;
                Assert.assertEquals(FLIGHTID, rs.getInt(1));
                Assert.assertEquals(10, rs.getInt(5));
                Assert.assertEquals(90, rs.getInt(6));
            }
        });
        
        Assert.assertEquals(0, rowsread);
    }

    @Test
    public void testBooking() {

        NamedCache flightCache = CacheFactory.getCache("flight");

        List<Reservation> reservations = new ArrayList<>(PASSENGERS.length);
        for (String passenger : PASSENGERS) {
            Reservation reservation = new Reservation();
            reservation.setBookingId(BOOKINGID);
            reservation.setFlightId(FLIGHTID);
            reservation.setPassengerName(passenger);
            reservation.setSeatType(SeatType.economy);
            reservations.add(reservation);
        }
        
        EntryProcessor reservationProcessor = new FlightReservationProcessor(
                reservations, BOOKINGID);
        
        flightCache.invoke(FLIGHTID, reservationProcessor);

        DataSource dataSource = new DriverManagerDataSource(DBURL);
        JdbcOperations jdbcop = new JdbcTemplate(dataSource);
        
        rowsread = 0;
        jdbcop.query("SELECT * FROM FLIGHT", new RowCallbackHandler() {
            
            @Override
            public void processRow(ResultSet rs) throws SQLException {
                rowsread++;
                Assert.assertEquals(FLIGHTID, rs.getInt(1));
                Assert.assertEquals(10, rs.getInt(5));
                Assert.assertEquals(90, rs.getInt(6));
            }
        });
        
        Assert.assertEquals(1, rowsread);
        
        final Set<String> passengersRead = new HashSet<>();
        
        jdbcop.query("SELECT * FROM RESERVATION", new RowCallbackHandler() {
            
            @Override
            public void processRow(ResultSet rs) throws SQLException {
                Assert.assertEquals(FLIGHTID, rs.getInt(1));
                Assert.assertEquals(BOOKINGID, rs.getInt(2));
                passengersRead.add(rs.getString(3));
            }
        });
        
        Assert.assertEquals(new HashSet<String>(Arrays.asList(PASSENGERS)), passengersRead);
    }
}
