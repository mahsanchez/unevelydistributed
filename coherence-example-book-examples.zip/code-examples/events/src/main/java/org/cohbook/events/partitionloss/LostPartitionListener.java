package org.cohbook.events.partitionloss;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.management.Registry;
import com.tangosol.net.partition.PartitionEvent;
import com.tangosol.net.partition.PartitionListener;

public class LostPartitionListener implements PartitionListener, LostPartitionListenerMBean {
    
    private int partitionsLostCount;
    private boolean registered = false;
    
    @Override
    public int getPartitionsLostCount() {
        return partitionsLostCount;
    }

    @Override
    public void onPartitionEvent(PartitionEvent partitionevent) {
        
        if (partitionevent.getId() == PartitionEvent.PARTITION_LOST) {
            
            ensureRegistered(partitionevent.getService().getInfo().getServiceName());
            
            partitionsLostCount += partitionevent.getPartitionSet().cardinality();
            
        }
    }

    private synchronized void ensureRegistered(String servicename) {
        
        if (registered) {
            return;
        }
        registered = true;
        
        Registry registry = CacheFactory.getCluster().getManagement();
        String name = "Coherence:type=LostPartitionListener,service=" + servicename;
        registry.register(registry.ensureGlobalName(name), this);
    }
}
