package org.cohbook.events.transaction;

import java.util.HashMap;
import java.util.Map;

import org.cohbook.events.domain.CachePersistor;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.tangosol.net.events.EventInterceptor;
import com.tangosol.net.events.partition.TransactionEvent;
import com.tangosol.util.BinaryEntry;

public class TransactionalCachePersistor implements EventInterceptor<TransactionEvent> {

    protected TransactionTemplate transactionTemplate;
    @SuppressWarnings("rawtypes")
    protected Map<String,CachePersistor> cachePersistorMap = new HashMap<>();

    public final void setTransactionTemplate(TransactionTemplate transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    public final void setCachePersistorMap(@SuppressWarnings("rawtypes") Map<String, CachePersistor> persistorMap) {
        this.cachePersistorMap = persistorMap;
    }

    @Override
    public void onEvent(final TransactionEvent event) {
        
        event.nextInterceptor();
        
        final Map<String,Map<Object, Object>> updatesByCache = new HashMap<>();

        for (BinaryEntry entry : event.getEntrySet()) {
            
            String cacheName = entry.getBackingMapContext().getCacheName();
            if (cachePersistorMap.containsKey(cacheName)) {
                Map<Object, Object> updateMap = updatesByCache.get(cacheName);
                if (updateMap == null) {
                    updateMap = new HashMap<>();
                    updatesByCache.put(cacheName, updateMap);
                }
                updateMap.put(entry.getKey(), entry.getValue());
            }
        }
        
        if (updatesByCache.size() > 0) {
        
            transactionTemplate.execute(new TransactionCallback<Object>() {
                @SuppressWarnings("unchecked")
                @Override
                public Object doInTransaction(TransactionStatus status) {
                    for (Map.Entry<String, Map<Object, Object>> entry : updatesByCache.entrySet()) {
                        cachePersistorMap.get(entry.getKey()).persistAll(entry.getValue());
                    }
                    return null;
                }
            });
        }
    }
}
