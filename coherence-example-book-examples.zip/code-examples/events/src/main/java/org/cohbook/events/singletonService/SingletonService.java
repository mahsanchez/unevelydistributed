package org.cohbook.events.singletonService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tangosol.net.Member;
import com.tangosol.net.MemberEvent;
import com.tangosol.net.MemberListener;
import com.tangosol.net.Service;

public class SingletonService implements MemberListener {
    
    private static final Logger LOG = LoggerFactory.getLogger(SingletonService.class);
    
    private final Runnable runnable;
    private Thread thread = null;
    
    public SingletonService(Service service, Runnable runnable) {
        
        this.runnable = runnable;
        service.addMemberListener(this);

        startIfThisIsOldest(service);
        
    }

    @Override
    public void memberJoined(MemberEvent memberevent) {
    }

    @Override
    public void memberLeaving(MemberEvent memberevent) {
    }

    @Override
    public void memberLeft(MemberEvent memberevent) {
        startIfThisIsOldest(memberevent.getService());
    }
    
    private synchronized void startIfThisIsOldest(Service service) {
        
        Member oldestMember = service.getInfo().getOldestMember();
        Member localMember = service.getCluster().getLocalMember();
        
        LOG.info("member " + localMember.getId() + ": " + oldestMember.getId() + " is now oldest");
        
        if (oldestMember.equals(localMember) && thread == null) {
            thread = new Thread(runnable);
            thread.start();
        }
    }
}
