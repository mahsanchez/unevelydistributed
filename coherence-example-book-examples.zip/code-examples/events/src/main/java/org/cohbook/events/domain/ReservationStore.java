package org.cohbook.events.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.cohbook.gridprocessing.reentrancy.Reservation;
import org.cohbook.gridprocessing.reentrancy.ReservationKey;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;

public class ReservationStore implements CachePersistor<ReservationKey, Reservation> {
    
    private static final String MERGE_SQL = "MERGE INTO RESERVATION VALUES(?, ?, ?, ?, ?);";
    private static final String DELETE_SQL = "DELETE FROM RESERVATION WHERE FLIGHTID = ? AND BOOKINGID = ? AND PASSENGERNAME = ?;";

    private final JdbcOperations jdbcTemplate;
    
    public ReservationStore(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void persistAll(Map<ReservationKey, Reservation> map) {
        
        List<Object[]> updateBatchValues = new ArrayList<>(map.size());
        List<Object[]> removeBatchValues = new ArrayList<>(map.size());
        
        for (Map.Entry<ReservationKey, Reservation> entry : map.entrySet()) {

            ReservationKey key = entry.getKey();
            Reservation reservation = entry.getValue();

            if (reservation != null) {

                Object[] row = new Object[5];
                row[0] = key.getFlightId();
                row[1] = key.getBookingId();
                row[2] = key.getPassengerName();
                row[3] = reservation.getSeatType().name();
                row[4] = reservation.isCheckedIn();
                updateBatchValues.add(row);
            } else {
                Object[] row = new Object[3];
                row[0] = key.getFlightId();
                row[1] = key.getBookingId();
                row[2] = key.getPassengerName();
                removeBatchValues.add(row);
            }

        }
        
        if (updateBatchValues.size() > 0) {
            jdbcTemplate.batchUpdate(MERGE_SQL, updateBatchValues);
        }
        
        if (removeBatchValues.size() > 0) {
            jdbcTemplate.batchUpdate(DELETE_SQL, removeBatchValues);
        }
    }
}
