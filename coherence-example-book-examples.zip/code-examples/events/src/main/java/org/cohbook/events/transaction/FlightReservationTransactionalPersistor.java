package org.cohbook.events.transaction;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.cohbook.events.domain.CachePersistor;
import org.cohbook.events.domain.FlightStore;
import org.cohbook.events.domain.ReservationStore;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.tangosol.net.events.annotation.Interceptor;
import com.tangosol.net.events.partition.TransactionEvent;

@Interceptor(transactionEvents=TransactionEvent.Type.COMMITTING)
public class FlightReservationTransactionalPersistor extends
        TransactionalCachePersistor {

    public FlightReservationTransactionalPersistor(String dburl) {
        
        DataSource dataSource = new DriverManagerDataSource(dburl);
        
        @SuppressWarnings("rawtypes")
        Map<String,CachePersistor> storeMap = new HashMap<>();
        
        storeMap.put("flight", new FlightStore(dataSource));
        storeMap.put("reservation", new ReservationStore(dataSource));
        
        cachePersistorMap = storeMap;
        
        PlatformTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
        transactionTemplate = new TransactionTemplate(transactionManager);
        
    }
}
