package org.cohbook.events.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.cohbook.gridprocessing.reentrancy.Flight;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class FlightStore implements CachePersistor<Integer, Flight> {
    
    private static final String MERGE_SQL = "MERGE INTO FLIGHT VALUES(?, ?, ?, ?, ?, ?);";
    private static final String DELETE_MANY_SQL = "DELETE FROM FLIGHT WHERE FLIGHTID IN (:FLIGHTIDS);";

    private final NamedParameterJdbcOperations jdbcTemplate;
    
    public FlightStore(DataSource dataSource) {
        jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    @Override
    public void persistAll(Map<Integer, Flight> map) {
        
        List<Object[]> updateBatchValues = new ArrayList<>(map.size());
        Collection<Integer> removeKeys = new ArrayList<>(map.size());
        
        for (Map.Entry<Integer, Flight> entry : map.entrySet()) {
            
            Flight flight = entry.getValue();
            if (flight == null) {
                removeKeys.add(entry.getKey());
            } else {
                Object[] row = new Object[6];

                row[0] = entry.getKey();
                row[1] = flight.getOrigin();
                row[2] = flight.getDestination();
                row[3] = flight.getDepartureTime();
                row[4] = flight.getAvailableBusiness();
                row[5] = flight.getAvailableEconomy();
                updateBatchValues.add(row);
            }
        }
        
        if (updateBatchValues.size() > 0) {
            jdbcTemplate.getJdbcOperations().batchUpdate(MERGE_SQL, updateBatchValues);
        }
        
        if (removeKeys.size() > 0) {
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("FLIGHTIDS", removeKeys);
            jdbcTemplate.update(DELETE_MANY_SQL, parameters);
        }
    }
}
