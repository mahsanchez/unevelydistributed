package org.cohbook.events.partitionloss;

public interface LostPartitionListenerMBean {

    int getPartitionsLostCount();

}