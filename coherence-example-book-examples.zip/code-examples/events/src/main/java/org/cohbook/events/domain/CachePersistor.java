package org.cohbook.events.domain;

import java.util.Map;

public interface CachePersistor<K, V> {

    void persistAll(Map<K, V> map);

}
