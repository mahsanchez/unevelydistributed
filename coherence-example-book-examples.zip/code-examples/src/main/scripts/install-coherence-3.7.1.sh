mvn install:install-file -DgroupId=com.oracle -DartifactId=coherence -Dversion=3.7.1.3 -Dpackaging=jar -Dfile=$1
