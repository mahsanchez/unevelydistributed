mvn install:install-file -DgroupId=com.oracle -DartifactId=coherence -Dversion=12.1.2 -Dfile=$1 -Dpackaging=jar
