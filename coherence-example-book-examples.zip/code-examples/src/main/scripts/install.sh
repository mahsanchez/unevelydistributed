#!/bin/bash

mvn install:install-file -DpomFile=evolvableCurrent-1.0.0.pom  -Dfile=evolvableCurrent-1.0.0.jar 
mvn install:install-file -DpomFile=evolvableCurrent-1.0.0.pom  -Dclassifier=tests -Dpackaging=test-jar -Dfile=evolvableCurrent-1.0.0-tests.jar 
 
