package org.cohbook.evolvabletest;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class TestFruitySerialisation2Way {

    private Serialisation2WayTestHelper serialisation2WayTestHelper;
    public TestFruitySerialisation2Way() throws MalformedURLException, ClassNotFoundException, NoSuchMethodException,
        SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        serialisation2WayTestHelper = new Serialisation2WayTestHelper("fruity-pof-config.xml");
    }

    @Test
    public void testFruitySerialisation()
            throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException,
            NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        
        Map<String, Object> props = new HashMap<String, Object>();
        props.put("setName", "Mark");
        props.put("setFavouriteFruit", "Grapes");
        
        Object currentObject = serialisation2WayTestHelper.getCurrentPofTestSupport().createBeanInClassLoader("org.cohbook.evolvable.Fruity", props);
        Object legacyObject = serialisation2WayTestHelper.getLegacyPofTestSupport().createBeanInClassLoader("org.cohbook.evolvable.Fruity", props);
        
        serialisation2WayTestHelper.roundTripCheck(legacyObject, currentObject);
        serialisation2WayTestHelper.currentToLegacyCheck(legacyObject, currentObject);
        serialisation2WayTestHelper.legacyToCurrentCheck(legacyObject, currentObject);
        
    }

    @Test
    public void testCheesySerialisation()
            throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException,
            NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        
        Map<String, Object> props = new HashMap<String, Object>();
        props.put("setName", "Elizabeth");
        props.put("setFavouriteFruit", "Banana");

        Object legacyObject = serialisation2WayTestHelper.getLegacyPofTestSupport().createBeanInClassLoader("org.cohbook.evolvable.Fruity", props);
        
        props.put("setFavouriteCheese", "Wensleydale");
        
        Object currentObject = serialisation2WayTestHelper.getCurrentPofTestSupport().createBeanInClassLoader("org.cohbook.evolvable.Fruity", props);
        
        serialisation2WayTestHelper.roundTripCheck(legacyObject, currentObject);
        serialisation2WayTestHelper.currentToLegacyCheck(legacyObject, currentObject);
        
    }
    
}
