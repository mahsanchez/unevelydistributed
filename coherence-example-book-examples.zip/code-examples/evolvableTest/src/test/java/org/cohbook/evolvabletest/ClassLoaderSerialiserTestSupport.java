package org.cohbook.evolvabletest;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;

public interface ClassLoaderSerialiserTestSupport {

    public abstract Object createBeanInClassLoader(String className,
            Map<String, Object> properties) throws InstantiationException,
            IllegalAccessException, ClassNotFoundException,
            NoSuchMethodException, SecurityException, IllegalArgumentException,
            InvocationTargetException;

    public abstract byte[] serialise(Object object)
            throws IllegalAccessException, IllegalArgumentException,
            InvocationTargetException;

    public abstract Object deserialise(byte[] bytearray)
            throws IllegalAccessException, IllegalArgumentException,
            InvocationTargetException, InstantiationException;

}