package org.cohbook.evolvabletest;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Map;

public class ReflectionClassLoaderSerialiserTestSupport implements ClassLoaderSerialiserTestSupport {
    
    private static final String POFCONTEXTCLASSNAME = "com.tangosol.io.pof.ConfigurablePofContext";
    private static final String SERIALISERCLASSNAME = "com.tangosol.io.Serializer";
    private final ClassLoader classLoader;
    private final Object pofContext;
    private final Method toBinary;
    private final Method fromBinary;
    private final Constructor<?> binaryConstructor;
    private final Method toByteArray;
    
    public ReflectionClassLoaderSerialiserTestSupport(String jarPaths[], String pofConfigName)
            throws MalformedURLException, ClassNotFoundException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        
        URL jarUrls[] = new URL[jarPaths.length];
        int i = 0;
        for (String jarPath : jarPaths) {
            jarUrls[i++] = new File(jarPath).toURI().toURL();
        }
        classLoader = new URLClassLoader(jarUrls, Thread.currentThread().getContextClassLoader());

        Class<?> pofContextClass = classLoader.loadClass(POFCONTEXTCLASSNAME);
        
        Constructor<?> constructor = pofContextClass.getConstructor(String.class);
        
        pofContext = constructor.newInstance(pofConfigName);
        
        Class<?> externalizableHelperClass = classLoader.loadClass("com.tangosol.util.ExternalizableHelper");
        Class<?> serialiserClass = classLoader.loadClass(SERIALISERCLASSNAME);
        Class<?> binaryClass = classLoader.loadClass("com.tangosol.util.Binary");
        
        toBinary = externalizableHelperClass.getMethod("toBinary", Object.class, serialiserClass);
        fromBinary = externalizableHelperClass.getMethod("fromBinary", binaryClass, serialiserClass);

        binaryConstructor = binaryClass.getConstructor(byte[].class);
        toByteArray = binaryClass.getMethod("toByteArray");
    }

    @Override
    public Object createBeanInClassLoader(String className, Map<String,Object> properties)
            throws InstantiationException, IllegalAccessException, ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        
        Class<?> beanClass = classLoader.loadClass(className);
        Object bean = beanClass.newInstance();
        
        for (Map.Entry<String, Object> propEntry : properties.entrySet()) {
            Method setter = beanClass.getMethod(propEntry.getKey(), propEntry.getValue().getClass());
            setter.invoke(bean, propEntry.getValue());
        }
        
        return bean;
        
    }
    
    @Override
    public byte[] serialise(Object object) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        return (byte[]) toByteArray.invoke(toBinary.invoke(null, object, pofContext));
    }
    
    @Override
    public Object deserialise(byte[] bytearray)
               throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
        return fromBinary.invoke(null, binaryConstructor.newInstance(bytearray), pofContext);
    }
}
