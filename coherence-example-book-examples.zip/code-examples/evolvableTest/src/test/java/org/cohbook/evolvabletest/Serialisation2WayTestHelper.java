package org.cohbook.evolvabletest;

import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;

import org.junit.Assert;

public class Serialisation2WayTestHelper {

    private final ClassLoaderSerialiserTestSupport currentPofTestSupport;
    private final ClassLoaderSerialiserTestSupport legacyPofTestSupport;
    
    private final String JAR2TEST =
        "/org/cohbook/evolvableCurrent/2.0.0/" + 
        "evolvableCurrent-2.0.0-tests.jar";
    private final String JAR2 =
        "/org/cohbook/evolvableCurrent/2.0.0/" + 
        "evolvableCurrent-2.0.0.jar";
    private final String JAR1TEST =
        "/org/cohbook/evolvableCurrent/1.0.0/" + 
        "evolvableCurrent-1.0.0-tests.jar";
    private final String JAR1 =
        "/org/cohbook/evolvableCurrent/1.0.0/" + 
        "evolvableCurrent-1.0.0.jar";
    private final String COHJAR =
        "/com/oracle/coherence/3.7.1.3/" + 
        "coherence-3.7.1.3.jar";

    public Serialisation2WayTestHelper(String configFileName)
        throws MalformedURLException, ClassNotFoundException,
        NoSuchMethodException, SecurityException, InstantiationException,
        IllegalAccessException, IllegalArgumentException, InvocationTargetException {

        String rootDirectory = System.getProperty("jarRootDir");
        if (rootDirectory == null) {
            rootDirectory = System.getProperty("user.home") + "/.m2/repository";
        }

        currentPofTestSupport = new DelegatingClassLoaderSerialiserTestSupport(
                new String[] { rootDirectory + JAR2TEST,
                        rootDirectory + JAR2,
                        rootDirectory + COHJAR},
                        configFileName);

        legacyPofTestSupport = new DelegatingClassLoaderSerialiserTestSupport(
                new String[] { rootDirectory + JAR1TEST,
                        rootDirectory + JAR1,
                        rootDirectory + COHJAR},
                        configFileName);
    }

    public ClassLoaderSerialiserTestSupport getCurrentPofTestSupport() {
        return currentPofTestSupport;
    }

    public ClassLoaderSerialiserTestSupport getLegacyPofTestSupport() {
        return legacyPofTestSupport;
    }

    public Object currentToLegacy(Object currentObject)
            throws IllegalAccessException, IllegalArgumentException,
            InvocationTargetException, InstantiationException {

        byte[] binaryObject = currentPofTestSupport.serialise(currentObject);
        return legacyPofTestSupport.deserialise(binaryObject);

    }

    public Object legacyToCurrent(Object legacyObject)
            throws IllegalAccessException, IllegalArgumentException,
            InvocationTargetException, InstantiationException {

        byte[] binaryObject = legacyPofTestSupport.serialise(legacyObject);
        return currentPofTestSupport.deserialise(binaryObject);

    }

    public void currentToLegacyCheck(Object legacyObject, Object currentObject)
            throws IllegalAccessException, IllegalArgumentException,
            InvocationTargetException, InstantiationException {

        Assert.assertEquals(legacyObject, currentToLegacy(legacyToCurrent(legacyObject)));

    }

    public void legacyToCurrentCheck(Object legacyObject, Object currentObject)
            throws IllegalAccessException, IllegalArgumentException,
            InvocationTargetException, InstantiationException {

        Assert.assertEquals(currentObject, legacyToCurrent(currentToLegacy(currentObject)));

    }

    public void roundTripCheck(Object legacyObject, Object currentObject)
            throws IllegalAccessException, IllegalArgumentException,
            InvocationTargetException, InstantiationException {

        Assert.assertEquals(currentObject, legacyToCurrent(currentToLegacy(currentObject)));
        Assert.assertEquals(legacyObject, currentToLegacy(legacyToCurrent(legacyObject)));

    }
}
