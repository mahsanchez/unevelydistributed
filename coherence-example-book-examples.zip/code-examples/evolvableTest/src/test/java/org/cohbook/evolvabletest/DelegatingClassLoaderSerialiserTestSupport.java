package org.cohbook.evolvabletest;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Map;

public class DelegatingClassLoaderSerialiserTestSupport implements ClassLoaderSerialiserTestSupport {
    
    private final Object delegate;
    private final ClassLoader classLoader;
    private final Method createBean;
    private final Method serialise;
    private final Method deserialise;

    private static final String DELEGATECLASSNAME = "org.cohbook.evolvable.SerialiserTestSupport";
    
    public DelegatingClassLoaderSerialiserTestSupport(String jarPaths[], String pofConfigName)
            throws MalformedURLException, ClassNotFoundException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        
        URL jarUrls[] = new URL[jarPaths.length];
        int i = 0;
        for (String jarPath : jarPaths) {
            jarUrls[i++] = new File(jarPath).toURI().toURL();
        }
        classLoader = new URLClassLoader(jarUrls, Thread.currentThread().getContextClassLoader());

        Class<?> delegateClass = classLoader.loadClass(DELEGATECLASSNAME);
        
        Constructor<?> constructor = delegateClass.getConstructor(String.class);
        
        delegate = constructor.newInstance(pofConfigName);
        
        createBean = delegateClass.getMethod("createBean", String.class, Map.class);
        serialise = delegateClass.getMethod("serialise", Object.class);
        deserialise = delegateClass.getMethod("deserialise", byte[].class);
        
    }

    @Override
    public Object createBeanInClassLoader(String className, Map<String,Object> properties)
            throws InstantiationException, IllegalAccessException, ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        
        return createBean.invoke(delegate, className, properties);
        
    }
    
    @Override
    public byte[] serialise(Object object) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        
        return (byte[]) serialise.invoke(delegate, object);
        
    }
    
    @Override
    public Object deserialise(byte[] bytearray)
               throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
        
        return deserialise.invoke(delegate, bytearray);
        
    }
}
