package org.cohbook.evolvabletest;

import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ClassLoaderPofTestSupportTest {
    
    private ClassLoaderSerialiserTestSupport pofTestSupport;

    @Before
    public void setup() throws MalformedURLException, ClassNotFoundException, NoSuchMethodException,
            SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        String rootDirectory = System.getProperty("jarRootDir");
        if (rootDirectory == null) {
            rootDirectory = System.getProperty("user.home") + "/.m2/repository";
        }
        pofTestSupport = new DelegatingClassLoaderSerialiserTestSupport(
                new String[] { rootDirectory + "/org/cohbook/evolvableCurrent/1.0.0/evolvableCurrent-1.0.0-tests.jar",
                        rootDirectory + "/org/cohbook/evolvableCurrent/1.0.0/evolvableCurrent-1.0.0.jar",
                        rootDirectory + "/com/oracle/coherence/3.7.1.3/coherence-3.7.1.3.jar"},
                "fruity-pof-config.xml");
    }
    
    @Test
    public void test() throws InstantiationException, IllegalAccessException, ClassNotFoundException, NoSuchMethodException,
            SecurityException, IllegalArgumentException, InvocationTargetException {
        Map<String, Object> properties = new HashMap<>();
        properties.put("setName", "Kieran");
        properties.put("setFavouriteFruit", "Kumquat");
        Object object = pofTestSupport.createBeanInClassLoader("org.cohbook.evolvable.Fruity", properties);
        
        byte[] serialsed = pofTestSupport.serialise(object);
        
        Assert.assertNotNull(serialsed);
    }

}
